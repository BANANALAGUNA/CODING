﻿<#
  Patch-SourceLinkStyle.ps1   (second patch, applied AFTER Patch-AddSourceLink.ps1)
  Source link: top-LEFT corner, text "ORIGINAL LINK" (uppercase, bold Arial 15px),
  white on red (#c92323). The full URL stays only in the tooltip (title).

  Put this file into the extension folder (next to manifest.json).
  Apply:     powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-SourceLinkStyle.ps1
  Roll back: powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-SourceLinkStyle.ps1 -Rollback

  Files changed: src\worker.ts, dist\worker.js
  Backups:       <file>.bak_<yyyyMMdd_HHmmss> next to each changed file
#>
param(
    [string]$Root = $PSScriptRoot,
    [switch]$Rollback
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($Root)) { $Root = (Get-Location).Path }
$Root = (Resolve-Path -LiteralPath $Root).Path
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$targets = @('src\worker.ts', 'dist\worker.js')

function Read-TextFile([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $start = 0
    if ($hasBom) { $start = 3 }
    $enc = New-Object System.Text.UTF8Encoding($false)
    return [pscustomobject]@{ Text = $enc.GetString($bytes, $start, $bytes.Length - $start); HasBom = $hasBom }
}

function Write-TextFile([string]$path, [string]$text, [bool]$hasBom) {
    $enc = New-Object System.Text.UTF8Encoding($hasBom)
    [System.IO.File]::WriteAllText($path, $text, $enc)
}

# Text without any whitespace + map: squashed index -> original index
function Get-Squash([string]$text) {
    $sb = New-Object System.Text.StringBuilder
    $map = New-Object 'System.Collections.Generic.List[int]'
    for ($i = 0; $i -lt $text.Length; $i++) {
        if (-not [char]::IsWhiteSpace($text[$i])) {
            [void]$sb.Append($text[$i])
            [void]$map.Add($i)
        }
    }
    return [pscustomobject]@{ Text = $sb.ToString(); Map = $map }
}

# Replace exactly one occurrence of $anchor (whitespace-insensitive) with $replacement
function Invoke-AnchorReplace([string]$text, [string]$anchor, [string]$replacement, [string]$eol) {
    $sq = Get-Squash $text
    $a = (Get-Squash $anchor).Text
    $first = $sq.Text.IndexOf($a, [System.StringComparison]::Ordinal)
    if ($first -lt 0) { throw "Anchor not found: $anchor" }
    $second = $sq.Text.IndexOf($a, $first + 1, [System.StringComparison]::Ordinal)
    if ($second -ge 0) { throw "Anchor is not unique: $anchor" }
    $origStart = $sq.Map[$first]
    $origEnd = $sq.Map[$first + $a.Length - 1] + 1
    $rep = $replacement -replace "`r?`n", $eol
    return $text.Substring(0, $origStart) + $rep + $text.Substring($origEnd)
}

# ---------------------------------------------------------------- rollback
if ($Rollback) {
    foreach ($rel in $targets) {
        $full = Join-Path $Root $rel
        $dir = Split-Path -Parent $full
        $leaf = Split-Path -Leaf $full
        $bak = Get-ChildItem -LiteralPath $dir -Filter "$leaf.bak_*" -File -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending | Select-Object -First 1
        if ($null -eq $bak) { Write-Host "No backup for $rel - skipped"; continue }
        Copy-Item -LiteralPath $bak.FullName -Destination $full -Force
        Write-Host "Restored $rel from $($bak.Name)"
    }
    Write-Host 'Rollback done. Reload the extension in chrome://extensions.'
    return
}

# anchor -> replacement (each anchor is a short unique token inside the injected style list)
$edits = @(
    @("a.textContent=url", "a.textContent = 'ORIGINAL LINK'"),
    @("'right:8px!important'", "'left:8px!important'"),
    @("'background:#fffbe6!important'", "'background:#c92323!important'"),
    @("'color:#0b3d91!important'", "'color:#ffffff!important'"),
    @("'border:2px solid #b38f00!important'", "'border:0!important'"),
    @("'font:600 13px/1.4 Arial,Helvetica,sans-serif!important'", "'font:700 15px/1.4 Arial,Helvetica,sans-serif!important'"),
    @("'text-decoration:underline!important'", "'text-decoration:none!important'"),
    @("'word-break:break-all!important'", "'white-space:nowrap!important', 'text-transform:uppercase!important'")
)

# ---------------------------------------------------------------- plan (in memory, nothing written yet)
$plan = @()
try {
    foreach ($rel in $targets) {
        $full = Join-Path $Root $rel
        if (-not (Test-Path -LiteralPath $full)) { throw "File not found: $full" }
        $f = Read-TextFile $full
        $text = $f.Text
        $eol = "`n"
        if ($text.Contains("`r`n")) { $eol = "`r`n" }
        $sqText = (Get-Squash $text).Text

        if ($sqText.Contains("'left:8px!important'")) { Write-Host "$rel : already patched - skipped"; continue }
        if (-not $sqText.Contains('functioninjectSourceLink(')) { throw "$rel : Patch-AddSourceLink.ps1 must be applied first" }

        $new = $text
        foreach ($e in $edits) { $new = Invoke-AnchorReplace $new $e[0] $e[1] $eol }
        $plan += [pscustomobject]@{ Rel = $rel; Full = $full; Text = $new; HasBom = $f.HasBom }
    }
}
catch {
    Write-Host "PATCH ABORTED, no files were changed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------- apply (backup first)
foreach ($p in $plan) {
    $bakPath = "$($p.Full).bak_$stamp"
    Copy-Item -LiteralPath $p.Full -Destination $bakPath -Force
    Write-TextFile $p.Full $p.Text $p.HasBom
    Write-Host "Patched $($p.Rel)  (backup: $(Split-Path -Leaf $bakPath))"
}
Write-Host 'Done. Reload the extension in chrome://extensions (the reload icon).'