﻿<#
  Patch-MhtSessionCookies.ps1   (apply AFTER Patch-AddSourceLink.ps1; SourceLinkStyle is optional)
  Save As MHT 0.2.0: embeds the site cookies into the saved .mht (extra MIME part
  "Content-Location: urn:saveasmht:cookies", base64 JSON) and restores them when
  ORIGINAL LINK is clicked from a local .mht, then reloads the tab with the session.

  Put this file into the extension folder (next to manifest.json).
  Apply:     powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-MhtSessionCookies.ps1
  Roll back: powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-MhtSessionCookies.ps1 -Rollback

  Files changed: manifest.json, src/worker.ts, dist/worker.js
  Backups:       <file>.bak_<yyyyMMdd_HHmmss> next to each changed file
  NOTE: adds permissions "cookies","storage" and host permissions http/https.
        Keep "Allow access to file URLs" enabled. Reload the extension afterwards.
#>
param(
    [string]$Root = $PSScriptRoot,
    [switch]$Rollback
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($Root)) { $Root = (Get-Location).Path }
$Root = (Resolve-Path -LiteralPath $Root).Path
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$targets = @('manifest.json', 'src/worker.ts', 'dist/worker.js')

function Read-TextFile([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $start = 0
    if ($hasBom) { $start = 3 }
    $enc = New-Object System.Text.UTF8Encoding($false)
    return [pscustomobject]@{ Text = $enc.GetString($bytes, $start, $bytes.Length - $start); HasBom = $hasBom }
}

function Write-TextFile([string]$path, [string]$text, [bool]$hasBom) {
    $enc = New-Object System.Text.UTF8Encoding($hasBom)
    [System.IO.File]::WriteAllText($path, $text, $enc)
}

# Text without any whitespace + map: squashed index -> original index
function Get-Squash([string]$text) {
    $sb = New-Object System.Text.StringBuilder
    $map = New-Object 'System.Collections.Generic.List[int]'
    for ($i = 0; $i -lt $text.Length; $i++) {
        if (-not [char]::IsWhiteSpace($text[$i])) {
            [void]$sb.Append($text[$i])
            [void]$map.Add($i)
        }
    }
    return [pscustomobject]@{ Text = $sb.ToString(); Map = $map }
}

# Replace exactly one occurrence of $anchor (whitespace-insensitive) with $replacement
function Invoke-AnchorReplace([string]$text, [string]$anchor, [string]$replacement, [string]$eol) {
    $sq = Get-Squash $text
    $a = (Get-Squash $anchor).Text
    $first = $sq.Text.IndexOf($a, [System.StringComparison]::Ordinal)
    if ($first -lt 0) { throw "Anchor not found: $anchor" }
    $second = $sq.Text.IndexOf($a, $first + 1, [System.StringComparison]::Ordinal)
    if ($second -ge 0) { throw "Anchor is not unique: $anchor" }
    $origStart = $sq.Map[$first]
    $origEnd = $sq.Map[$first + $a.Length - 1] + 1
    $rep = $replacement -replace "`r?`n", $eol
    return $text.Substring(0, $origStart) + $rep + $text.Substring($origEnd)
}

# ---------------------------------------------------------------- rollback
if ($Rollback) {
    foreach ($rel in $targets) {
        $full = Join-Path $Root $rel
        $dir = Split-Path -Parent $full
        $leaf = Split-Path -Leaf $full
        $bak = Get-ChildItem -LiteralPath $dir -Filter "$leaf.bak_*" -File -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending | Select-Object -First 1
        if ($null -eq $bak) { Write-Host "No backup for $rel - skipped"; continue }
        Copy-Item -LiteralPath $bak.FullName -Destination $full -Force
        Write-Host "Restored $rel from $($bak.Name)"
    }
    Write-Host 'Rollback done. Reload the extension in chrome://extensions.'
    return
}

# ---------------------------------------------------------------- new worker code (JS for dist, TS derived for src)
$JsBlock = @'
// === MHT session cookies (patch MhtSessionCookies) ===
const MHT_COOKIES_LOCATION = 'urn:saveasmht:cookies';
function mhtUtf8ToB64(str) {
    const bytes = new TextEncoder().encode(str);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
}
function mhtB64ToUtf8(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
}
async function appendCookiesPart(mhtmlText, pageUrl) {
    try {
        if (!/^https?:/i.test(pageUrl || '')) return mhtmlText;
        const cookies = await chrome.cookies.getAll({ url: pageUrl });
        const payload = JSON.stringify({ url: pageUrl, savedAt: new Date().toISOString(), cookies: cookies });
        try { await chrome.storage.local.set({ ['mhtCookies:' + pageUrl]: payload }); } catch (e) { }
        const bm = mhtmlText.slice(0, 4096).match(/boundary="([^"]+)"/);
        if (!bm) return mhtmlText;
        const pos = mhtmlText.lastIndexOf('--' + bm[1] + '--');
        if (pos < 0) return mhtmlText;
        const b64 = mhtUtf8ToB64(payload).replace(/(.{76})/g, '$1\r\n');
        const part = '--' + bm[1] + '\r\n' +
            'Content-Type: application/json\r\n' +
            'Content-Transfer-Encoding: base64\r\n' +
            'Content-Location: ' + MHT_COOKIES_LOCATION + '\r\n\r\n' +
            b64 + '\r\n';
        return mhtmlText.slice(0, pos) + part + mhtmlText.slice(pos);
    } catch (e) {
        console.warn('SaveAsMHT: cookie capture failed', e);
        return mhtmlText;
    }
}
function extractSavedCookies(mhtText) {
    const m = mhtText.match(/Content-Location: urn:saveasmht:cookies\r?\n\r?\n([A-Za-z0-9+/=\r\n]+)/);
    if (!m) return null;
    try { return JSON.parse(mhtB64ToUtf8(m[1].replace(/\s+/g, ''))); } catch (e) { return null; }
}
async function restoreSavedCookies(list) {
    let ok = 0, fail = 0;
    const now = Date.now() / 1000;
    for (const c of list || []) {
        try {
            if (c.expirationDate && c.expirationDate < now) continue;
            const host = (c.domain || '').replace(/^\./, '');
            if (!host || !c.name) { fail++; continue; }
            const details = {
                url: (c.secure ? 'https://' : 'http://') + host + (c.path || '/'),
                name: c.name,
                value: c.value || '',
                path: c.path || '/',
                secure: !!c.secure,
                httpOnly: !!c.httpOnly,
            };
            if (!c.hostOnly && c.domain) details.domain = c.domain;
            if (c.sameSite) details.sameSite = c.sameSite;
            if (c.expirationDate) details.expirationDate = c.expirationDate;
            if (c.partitionKey) details.partitionKey = c.partitionKey;
            const r = await chrome.cookies.set(details);
            if (r) ok++; else fail++;
        } catch (e) { fail++; }
    }
    console.log('SaveAsMHT: session cookies restored:', ok, 'failed:', fail);
    return ok;
}
function mhtSameOrigin(a, b) {
    try { return new URL(a).origin === new URL(b).origin; } catch (e) { return false; }
}
function waitTabHttpUrl(tabId) {
    return new Promise(function (resolve) {
        const timer = setTimeout(function () { cleanup(); resolve(''); }, 15000);
        function onUpd(id, info, t) {
            const u = (t && t.url) || info.url || '';
            if (id === tabId && /^https?:/i.test(u)) { cleanup(); resolve(u); }
        }
        function cleanup() { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(onUpd); }
        chrome.tabs.onUpdated.addListener(onUpd);
    });
}
const mhtRestoreBusy = new Set();
async function handleMhtLinkTab(tab) {
    if (!tab || tab.id == null || mhtRestoreBusy.has(tab.id)) return;
    let url = tab.pendingUrl || tab.url || '';
    let opener = null;
    try {
        if (tab.openerTabId != null) opener = await chrome.tabs.get(tab.openerTabId).catch(function () { return null; });
        if (!opener && tab.windowId != null) {
            const act = await chrome.tabs.query({ windowId: tab.windowId, active: true });
            if (act && act[0] && act[0].id !== tab.id) opener = act[0];
        }
        if (!opener || !/^file:\/\/\/.*\.mht(ml)?$/i.test(opener.url || '')) return;
        mhtRestoreBusy.add(tab.id);
        if (!/^https?:/i.test(url)) url = await waitTabHttpUrl(tab.id);
        if (!/^https?:/i.test(url)) return;
        let saved = null;
        try {
            const res = await fetch(opener.url);
            saved = extractSavedCookies(await res.text());
        } catch (e) { }
        if (saved && saved.url && !mhtSameOrigin(url, saved.url)) saved = null;
        if (!saved) {
            try {
                const key = 'mhtCookies:' + url;
                const obj = await chrome.storage.local.get(key);
                if (obj && obj[key]) saved = JSON.parse(obj[key]);
            } catch (e) { }
        }
        if (saved && saved.cookies && saved.cookies.length) {
            const ok = await restoreSavedCookies(saved.cookies);
            if (ok > 0) chrome.tabs.reload(tab.id);
        }
    } catch (e) {
        console.warn('SaveAsMHT: session restore failed', e);
    } finally {
        if (mhtRestoreBusy.has(tab.id)) setTimeout(function () { mhtRestoreBusy.delete(tab.id); }, 5000);
    }
}
chrome.tabs.onCreated.addListener(handleMhtLinkTab);
'@

$TsBlock = $JsBlock
$TsBlock = $TsBlock.Replace('function mhtUtf8ToB64(str) {', 'function mhtUtf8ToB64(str: string): string {')
$TsBlock = $TsBlock.Replace('function mhtB64ToUtf8(b64) {', 'function mhtB64ToUtf8(b64: string): string {')
$TsBlock = $TsBlock.Replace('async function appendCookiesPart(mhtmlText, pageUrl) {', 'async function appendCookiesPart(mhtmlText: string, pageUrl: string): Promise<string> {')
$TsBlock = $TsBlock.Replace('function extractSavedCookies(mhtText) {', 'function extractSavedCookies(mhtText: string): any {')
$TsBlock = $TsBlock.Replace('async function restoreSavedCookies(list) {', 'async function restoreSavedCookies(list: any[]): Promise<number> {')
$TsBlock = $TsBlock.Replace('function mhtSameOrigin(a, b) {', 'function mhtSameOrigin(a: string, b: string): boolean {')
$TsBlock = $TsBlock.Replace('function waitTabHttpUrl(tabId) {', 'function waitTabHttpUrl(tabId: number): Promise<string> {')
$TsBlock = $TsBlock.Replace('return new Promise(function (resolve) {', 'return new Promise<string>(function (resolve) {')
$TsBlock = $TsBlock.Replace('function onUpd(id, info, t) {', 'function onUpd(id: number, info: chrome.tabs.TabChangeInfo, t: chrome.tabs.Tab) {')
$TsBlock = $TsBlock.Replace('const mhtRestoreBusy = new Set();', 'const mhtRestoreBusy = new Set<number>();')
$TsBlock = $TsBlock.Replace('async function handleMhtLinkTab(tab) {', 'async function handleMhtLinkTab(tab: chrome.tabs.Tab) {')
$TsBlock = $TsBlock.Replace('let opener = null;', 'let opener: chrome.tabs.Tab | null = null;')
$TsBlock = $TsBlock.Replace('const details = {', 'const details: any = {')
$TsBlock = $TsBlock.Replace('let saved = null;', 'let saved: any = null;')

# ---------------------------------------------------------------- edits
$editsManifest = @(
    @('"activeTab" ]', '"activeTab", "cookies", "storage" ]'),
    @('"host_permissions": [ "file:///*" ]', '"host_permissions": [ "file:///*", "http://*/*", "https://*/*" ]')
)
$editsSrc = @(
    @("a.rel = 'noopener noreferrer'", "a.rel = 'opener'"),
    @('return await captureTabToDataUrl(tab.id)', 'return await captureTabToDataUrl(tab.id, tab.url)'),
    @('async function captureTabToDataUrl(tabId: number) {', 'async function captureTabToDataUrl(tabId: number, pageUrl: string) {'),
    @('return `data:multipart/related;base64,${btoa(tabText)}`', ('const withCookies = await appendCookiesPart(tabText, pageUrl)' + "`n" + '  return `data:multipart/related;base64,${btoa(withCookies)}`')),
    @(('chrome.action.setPopup({ tabId, popup })' + "`n" + '}'), ('chrome.action.setPopup({ tabId, popup })' + "`n" + '}' + "`n`n" + $TsBlock))
)
$editsDist = @(
    @("a.rel = 'noopener noreferrer';", "a.rel = 'opener';"),
    @('return await captureTabToDataUrl(tab.id);', 'return await captureTabToDataUrl(tab.id, tab.url);'),
    @('async function captureTabToDataUrl(tabId) {', 'async function captureTabToDataUrl(tabId, pageUrl) {'),
    @('return `data:multipart/related;base64,${btoa(tabText)}`;', ('const withCookies = await appendCookiesPart(tabText, pageUrl);' + "`n" + '    return `data:multipart/related;base64,${btoa(withCookies)}`;')),
    @(('chrome.action.setPopup({ tabId, popup });' + "`n" + '}'), ('chrome.action.setPopup({ tabId, popup });' + "`n" + '}' + "`n`n" + $JsBlock))
)

$jobs = @(
    @{ Rel = 'manifest.json'; Edits = $editsManifest; Guard = '"cookies","storage"' },
    @{ Rel = 'src/worker.ts'; Edits = $editsSrc;      Guard = 'urn:saveasmht:cookies' },
    @{ Rel = 'dist/worker.js'; Edits = $editsDist;    Guard = 'urn:saveasmht:cookies' }
)

# ---------------------------------------------------------------- plan (in memory, nothing written yet)
$plan = @()
try {
    foreach ($j in $jobs) {
        $full = Join-Path $Root $j.Rel
        if (-not (Test-Path -LiteralPath $full)) { throw "File not found: $full" }
        $f = Read-TextFile $full
        $text = $f.Text
        $eol = "`n"
        if ($text.Contains("`r`n")) { $eol = "`r`n" }
        $sqText = (Get-Squash $text).Text

        if ($sqText.Contains($j.Guard)) { Write-Host "$($j.Rel) : already patched - skipped"; continue }

        $new = $text
        foreach ($e in $j.Edits) { $new = Invoke-AnchorReplace $new $e[0] $e[1] $eol }
        $plan += [pscustomobject]@{ Rel = $j.Rel; Full = $full; Text = $new; HasBom = $f.HasBom }
    }
}
catch {
    Write-Host "PATCH ABORTED, no files were changed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------- apply (backup first)
if ($plan.Count -eq 0) { Write-Host 'Nothing to do.'; return }
foreach ($p in $plan) {
    $bakPath = "$($p.Full).bak_$stamp"
    Copy-Item -LiteralPath $p.Full -Destination $bakPath -Force
    Write-TextFile $p.Full $p.Text $p.HasBom
    Write-Host "Patched $($p.Rel)  (backup: $(Split-Path -Leaf $bakPath))"
}
Write-Host 'Done. Reload the extension in chrome://extensions (the reload icon).'