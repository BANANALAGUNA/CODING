chrome.action.onClicked.addListener(function (tab) {
  saveTab(tab)
})

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.create({
    id: 'save-mht',
    title: 'Save as .mht...',
    contexts: ['all'],
  })
})

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId == 'save-mht') {
    saveTab(tab)
  }
})

async function saveTab(tab: chrome.tabs.Tab) {
  chrome.downloads.download({
    conflictAction: 'prompt',
    filename: `${sanitizeFilename(tab.title)}.mht`,
    saveAs: true,
    url: await captureTabWithLink(tab),
  })
}

// --- Source URL link: added to the page only for the capture (patch AddSourceLink) ---
async function captureTabWithLink(tab: chrome.tabs.Tab) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: injectSourceLink,
      args: [tab.url],
    })
  } catch (e) {
    console.warn('SaveAsMHT: could not add source link to this page', e)
  }

  try {
    return await captureTabToDataUrl(tab.id, tab.url)
  } finally {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: removeSourceLink,
      })
    } catch (e) {}
  }
}

// Runs inside the page
function injectSourceLink(url: string) {
  const id = '__save_as_mht_source_link__'
  document.getElementById(id)?.remove()
  const a = document.createElement('a')
  a.id = id
  a.href = url
  a.target = '_blank'
  a.rel = 'opener'
  a.title = url
  a.textContent = 'ORIGINAL LINK'
  a.style.cssText = [
    'all:initial!important',
    'display:block!important',
    'position:fixed!important',
    'top:8px!important',
    'left:8px!important',
    'z-index:2147483647!important',
    'box-sizing:border-box!important',
    'max-width:min(60vw,640px)!important',
    'padding:6px 10px!important',
    'background:#c92323!important',
    'color:#ffffff!important',
    'border:0!important',
    'border-radius:6px!important',
    'box-shadow:0 2px 10px rgba(0,0,0,.4)!important',
    'font:700 15px/1.4 Arial,Helvetica,sans-serif!important',
    'text-decoration:none!important',
    'white-space:nowrap!important', 'text-transform:uppercase!important',
    'cursor:pointer!important',
    'pointer-events:auto!important',
    'opacity:1!important',
    'visibility:visible!important',
  ].join(';')
  document.documentElement.appendChild(a)
}

// Runs inside the page
function removeSourceLink() {
  document.getElementById('__save_as_mht_source_link__')?.remove()
}
function sanitizeFilename(filename: string) {
  return filename.replace(/[<>:"/\\|?*\x00-\x1F~]/g, '_')
}

async function captureTabToDataUrl(tabId: number, pageUrl: string) {
  const tabText = await new Promise<string>(function (resolve, reject) {
    chrome.pageCapture.saveAsMHTML({ tabId }, function (mhtmlData) {
      return mhtmlData
        ? resolve(mhtmlData.text())
        : reject(new Error(chrome.runtime.lastError.message))
    })
  })

  const withCookies = await appendCookiesPart(tabText, pageUrl)
  return `data:multipart/related;base64,${btoa(withCookies)}`
}

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.status != 'loading') {
    return
  }

  setPopup(tabId, tab.url)
})

chrome.tabs.query({}).then(function (tabs) {
  tabs.forEach(function (tab) {
    setPopup(tab.id, tab.url)
  })
})

async function setPopup(tabId: number, url: string) {
  if (!/^file:\/\/\/.*\.mht(ml)?$/i.test(url)) {
    return
  }

  const { text, popup }: { text: string; popup: string } =
    (await chrome.permissions.contains({ origins: ['file:///*'] }))
      ? { text: '🛈', popup: 'mht-info.html' }
      : { text: '⚠', popup: 'file-permission.html' }
  chrome.action.setBadgeText({ tabId, text })
  chrome.action.setPopup({ tabId, popup })
}

// === MHT session cookies (patch MhtSessionCookies) ===
const MHT_COOKIES_LOCATION = 'urn:saveasmht:cookies';
function mhtUtf8ToB64(str: string): string {
    const bytes = new TextEncoder().encode(str);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
}
function mhtB64ToUtf8(b64: string): string {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
}
async function appendCookiesPart(mhtmlText: string, pageUrl: string): Promise<string> {
    try {
        if (!/^https?:/i.test(pageUrl || '')) return mhtmlText;
        const cookies = await chrome.cookies.getAll({ url: pageUrl });
        const payload = JSON.stringify({ url: pageUrl, savedAt: new Date().toISOString(), cookies: cookies });
        try { await chrome.storage.local.set({ ['mhtCookies:' + pageUrl]: payload }); } catch (e) { }
        const bm = mhtmlText.slice(0, 4096).match(/boundary="([^"]+)"/);
        if (!bm) return mhtmlText;
        const pos = mhtmlText.lastIndexOf('--' + bm[1] + '--');
        if (pos < 0) return mhtmlText;
        const b64 = mhtUtf8ToB64(payload).replace(/(.{76})/g, '$1\r\n');
        const part = '--' + bm[1] + '\r\n' +
            'Content-Type: application/json\r\n' +
            'Content-Transfer-Encoding: base64\r\n' +
            'Content-Location: ' + MHT_COOKIES_LOCATION + '\r\n\r\n' +
            b64 + '\r\n';
        return mhtmlText.slice(0, pos) + part + mhtmlText.slice(pos);
    } catch (e) {
        console.warn('SaveAsMHT: cookie capture failed', e);
        return mhtmlText;
    }
}
function extractSavedCookies(mhtText: string): any {
    const m = mhtText.match(/Content-Location: urn:saveasmht:cookies\r?\n\r?\n([A-Za-z0-9+/=\r\n]+)/);
    if (!m) return null;
    try { return JSON.parse(mhtB64ToUtf8(m[1].replace(/\s+/g, ''))); } catch (e) { return null; }
}
async function restoreSavedCookies(list: any[]): Promise<number> {
    let ok = 0, fail = 0;
    const now = Date.now() / 1000;
    for (const c of list || []) {
        try {
            if (c.expirationDate && c.expirationDate < now) continue;
            const host = (c.domain || '').replace(/^\./, '');
            if (!host || !c.name) { fail++; continue; }
            const details: any = {
                url: (c.secure ? 'https://' : 'http://') + host + (c.path || '/'),
                name: c.name,
                value: c.value || '',
                path: c.path || '/',
                secure: !!c.secure,
                httpOnly: !!c.httpOnly,
            };
            if (!c.hostOnly && c.domain) details.domain = c.domain;
            if (c.sameSite) details.sameSite = c.sameSite;
            if (c.expirationDate) details.expirationDate = c.expirationDate;
            if (c.partitionKey) details.partitionKey = c.partitionKey;
            const r = await chrome.cookies.set(details);
            if (r) ok++; else fail++;
        } catch (e) { fail++; }
    }
    console.log('SaveAsMHT: session cookies restored:', ok, 'failed:', fail);
    return ok;
}
function mhtSameOrigin(a: string, b: string): boolean {
    try { return new URL(a).origin === new URL(b).origin; } catch (e) { return false; }
}
function waitTabHttpUrl(tabId: number): Promise<string> {
    return new Promise<string>(function (resolve) {
        const timer = setTimeout(function () { cleanup(); resolve(''); }, 15000);
        function onUpd(id: number, info: chrome.tabs.TabChangeInfo, t: chrome.tabs.Tab) {
            const u = (t && t.url) || info.url || '';
            if (id === tabId && /^https?:/i.test(u)) { cleanup(); resolve(u); }
        }
        function cleanup() { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(onUpd); }
        chrome.tabs.onUpdated.addListener(onUpd);
    });
}
const mhtRestoreBusy = new Set<number>();
async function handleMhtLinkTab(tab: chrome.tabs.Tab) {
    if (!tab || tab.id == null || mhtRestoreBusy.has(tab.id)) return;
    let url = tab.pendingUrl || tab.url || '';
    let opener: chrome.tabs.Tab | null = null;
    try {
        if (tab.openerTabId != null) opener = await chrome.tabs.get(tab.openerTabId).catch(function () { return null; });
        if (!opener && tab.windowId != null) {
            const act = await chrome.tabs.query({ windowId: tab.windowId, active: true });
            if (act && act[0] && act[0].id !== tab.id) opener = act[0];
        }
        if (!opener || !/^file:\/\/\/.*\.mht(ml)?$/i.test(opener.url || '')) return;
        mhtRestoreBusy.add(tab.id);
        if (!/^https?:/i.test(url)) url = await waitTabHttpUrl(tab.id);
        if (!/^https?:/i.test(url)) return;
        let saved: any = null;
        try {
            const res = await fetch(opener.url);
            saved = extractSavedCookies(await res.text());
        } catch (e) { }
        if (saved && saved.url && !mhtSameOrigin(url, saved.url)) saved = null;
        if (!saved) {
            try {
                const key = 'mhtCookies:' + url;
                const obj = await chrome.storage.local.get(key);
                if (obj && obj[key]) saved = JSON.parse(obj[key]);
            } catch (e) { }
        }
        if (saved && saved.cookies && saved.cookies.length) {
            const ok = await restoreSavedCookies(saved.cookies);
            if (ok > 0) chrome.tabs.reload(tab.id);
        }
    } catch (e) {
        console.warn('SaveAsMHT: session restore failed', e);
    } finally {
        if (mhtRestoreBusy.has(tab.id)) setTimeout(function () { mhtRestoreBusy.delete(tab.id); }, 5000);
    }
}
chrome.tabs.onCreated.addListener(handleMhtLinkTab);
