#!/system/bin/sh
# shellcheck disable=SC2034,SC2154
SKIPUNZIP=1

DEBUG=false
SONAME=cleverestricky
SUPPORTED_ABIS="arm64 x64"
MIN_SDK=29
MAX_SDK=37

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "- Installing from KernelSU app"
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
elif [ "$BOOTMODE" ] && [ "$APATCH" ]; then
  ui_print "- Installing from APatch app"
  ui_print "- APatch version: $APATCH_VER_CODE"
elif [ "$MAGISK_VER_CODE" ] || { [ "$BOOTMODE" ] && [ -d /data/adb/magisk ]; }; then
  ui_print "- Installing from Magisk app"
  ui_print "- Magisk version: ${MAGISK_VER:-unknown} (${MAGISK_VER_CODE:-unknown})"
  ui_print "- Magisk is supported. KernelSU and APatch are supported as well."
  ui_print "- WebUI works on all three: on Magisk press Action to open it"
  ui_print "  via a standalone WebUI host app (a WebView container,"
  ui_print "  container, not a root manager). It installs on first use."
else
  ui_print "*********************************************************"
  ui_print "! Install from recovery or unsupported root is not supported"
  ui_print "! Please install from KernelSU, APatch, or Magisk app"
  abort    "*********************************************************"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- Installing $SONAME $VERSION"

case " $SUPPORTED_ABIS " in
  *" $ARCH "*) support=true ;;
  *) support=false ;;
esac
if [ "$support" != "true" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH (Supported)"
fi

case "$API" in
  ''|*[!0-9]*) abort "! Invalid Android SDK value: $API" ;;
esac
if [ "$API" -lt "$MIN_SDK" ]; then
  ui_print "! Unsupported sdk: $API"
  abort "! Minimal supported sdk is $MIN_SDK"
fi
if [ "$API" -gt "$MAX_SDK" ]; then
  ui_print "! Unsupported sdk: $API"
  abort "! Maximum validated sdk is $MAX_SDK"
fi
ui_print "- Device sdk: $API (Supported)"

# Minimum kernel: Linux 5.3. Use only the release number here; no native probe.
kernel_release=$(uname -r 2>/dev/null) || abort "! Could not detect Linux kernel version"
case "$kernel_release" in *.*) ;; *) abort "! Invalid Linux kernel version: $kernel_release" ;; esac
kernel_major=${kernel_release%%.*}
kernel_minor=${kernel_release#*.}
kernel_minor=${kernel_minor%%[!0-9]*}
case "$kernel_major:$kernel_minor" in
  *[!0-9:]*|:*|*:) abort "! Invalid Linux kernel version: $kernel_release" ;;
esac
if [ "$kernel_major" -lt 5 ] || { [ "$kernel_major" -eq 5 ] && [ "$kernel_minor" -lt 3 ]; }; then
  ui_print "! Unsupported kernel: $kernel_release (minimum Linux 5.3)"
fi
ui_print "- Linux kernel: $kernel_release (Supported)"

ui_print "- Extracting verify.sh"
for bootstrap_target in "$TMPDIR/verify.sh" "$TMPDIR/verify.sh.sha256"; do
  if [ -L "$bootstrap_target" ] || { [ -e "$bootstrap_target" ] && [ ! -f "$bootstrap_target" ]; }; then
    abort "! Existing installer verification target is unsafe"
  fi
  rm -f "$bootstrap_target" || abort "! Could not prepare installer verification target"
done
unzip -o "$ZIPFILE" 'verify.sh' 'verify.sh.sha256' -d "$TMPDIR" >&2 \
  || abort "! Unable to extract installer verification files"
if [ -L "$TMPDIR/verify.sh" ] || [ ! -f "$TMPDIR/verify.sh" ] || \
  [ -L "$TMPDIR/verify.sh.sha256" ] || [ ! -f "$TMPDIR/verify.sh.sha256" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh safely!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
bootstrap_hash=$(tr -d '[:space:]' < "$TMPDIR/verify.sh.sha256")
case "$bootstrap_hash" in
  ''|*[!0-9A-Fa-f]*) abort "! Invalid verify.sh checksum" ;;
esac
[ "${#bootstrap_hash}" -eq 64 ] || abort "! Invalid verify.sh checksum length"
printf '%s  %s\n' "$bootstrap_hash" "$TMPDIR/verify.sh" | sha256sum -c - >/dev/null 2>&1 \
  || abort "! Failed to verify verify.sh before execution"
bootstrap_hash=
# shellcheck disable=SC1091
. "$TMPDIR/verify.sh"
extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"

if ! command -v busybox >/dev/null 2>&1; then
  abort "! busybox is required for installation"
fi

ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'identity-companion.prop' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'identity-zygisk.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh' "$MODPATH"
extract "$ZIPFILE" 'action.sh' "$MODPATH"
extract "$ZIPFILE" 'emergency-report.sh' "$MODPATH"
# Install the English licensing documents; extract() verifies each SHA-256 sidecar.
extract "$ZIPFILE" 'LICENSE' "$MODPATH"
extract "$ZIPFILE" 'LICENSING.md' "$MODPATH"
extract "$ZIPFILE" 'NOTICE' "$MODPATH"
extract "$ZIPFILE" 'GPL-3.0-only.txt' "$MODPATH"
chmod 644 "$MODPATH/LICENSE" "$MODPATH/LICENSING.md" "$MODPATH/NOTICE" "$MODPATH/GPL-3.0-only.txt" ||
  abort "! Could not set legal notice permissions"

host_pin_target="$MODPATH/webui-host.sha256"
prepare_extract_target "$host_pin_target"
unzip -o "$ZIPFILE" 'webui-host.sha256' -d "$MODPATH" >&2   || abort "! Could not extract WebUI host pin"
if [ -L "$host_pin_target" ] || [ ! -f "$host_pin_target" ]; then
  abort "! WebUI host pin does not exist safely"
fi

extract "$ZIPFILE" 'service.apk'     "$MODPATH"
extract "$ZIPFILE" 'webui-auth.apk'  "$MODPATH"
extract "$ZIPFILE" 'ai-guides.zip'   "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule'   "$MODPATH"
extract "$ZIPFILE" 'daemon'          "$MODPATH"
chmod 755 "$MODPATH/daemon" || abort "! Could not make daemon executable"
if [ -L "$MODPATH/webroot" ] || { [ -e "$MODPATH/webroot" ] && [ ! -d "$MODPATH/webroot" ]; }; then
  abort "! Existing native WebUI path is unsafe"
fi
if [ -d "$MODPATH/webroot" ]; then
  rm -rf "${MODPATH:?}/webroot" || abort "! Could not replace the native WebUI"
fi
extract "$ZIPFILE" 'webroot/index.html' "$MODPATH"
extract "$ZIPFILE" 'webroot/bridge.js'  "$MODPATH"
extract "$ZIPFILE" 'webroot/policy.js'  "$MODPATH"
extract "$ZIPFILE" 'webroot/ux.js'      "$MODPATH"
if [ -L "$MODPATH/webroot" ] || [ ! -d "$MODPATH/webroot" ] || \
  [ -L "$MODPATH/webroot/index.html" ] || [ ! -f "$MODPATH/webroot/index.html" ] || \
  [ -L "$MODPATH/webroot/bridge.js" ] || [ ! -f "$MODPATH/webroot/bridge.js" ] || \
  [ -L "$MODPATH/webroot/policy.js" ] || [ ! -f "$MODPATH/webroot/policy.js" ] || \
  [ -L "$MODPATH/webroot/ux.js" ] || [ ! -f "$MODPATH/webroot/ux.js" ]; then
  abort "! Native WebUI files are unsafe"
fi

ui_print "- Zygisk is optional; recommended for per-app Identity overrides"

case "$ARCH" in
  "x64")
    ui_print "- Extracting x64 libraries"
    extract "$ZIPFILE" "lib/x86_64/lib$SONAME.so" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/inject" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/webui_bridge" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/cleverestrickyd" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/cleverestricky_backend" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/integrity_manifest.json" "$MODPATH" true
    extract "$ZIPFILE" "lib/x86_64/identity_zygisk.so" "$MODPATH" true
    ;;
  "arm64")
    ui_print "- Extracting arm64 libraries"
    extract "$ZIPFILE" "lib/arm64-v8a/lib$SONAME.so" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/inject" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/webui_bridge" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/cleverestrickyd" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/cleverestricky_backend" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/integrity_manifest.json" "$MODPATH" true
    extract "$ZIPFILE" "lib/arm64-v8a/identity_zygisk.so" "$MODPATH" true
    ;;
  *)
    abort "! Unsupported ARCH: $ARCH"
    ;;
esac

for module_payload in LICENSE LICENSING.md NOTICE GPL-3.0-only.txt module.prop identity-companion.prop uninstall.sh post-fs-data.sh identity-zygisk.sh service.sh action.sh emergency-report.sh webui-host.sha256 service.apk webui-auth.apk ai-guides.zip sepolicy.rule daemon \
  "lib$SONAME.so" identity_zygisk.so inject webui_bridge cleverestrickyd cleverestricky_backend integrity_manifest.json; do
  payload_path="$MODPATH/$module_payload"
  if [ -L "$payload_path" ] || [ ! -f "$payload_path" ]; then
    abort "! Extracted module payload is unsafe: $module_payload"
  fi
done

if [ -L "$MODPATH/zygisk" ] || { [ -e "$MODPATH/zygisk" ] && [ ! -d "$MODPATH/zygisk" ]; }; then
  abort "! Existing optional Zygisk path is unsafe"
fi
if [ -d "$MODPATH/zygisk" ]; then
  rm -rf "$MODPATH/zygisk" || abort "! Could not remove stale optional Zygisk files"
fi
# Activation follows configuration migration below. Keeping the provider-facing
# directory absent here also prevents an off/default install from being loaded.
chmod 644 "$MODPATH/identity_zygisk.so" || abort "! Could not secure inert Identity payload"

chmod 755 "$MODPATH/inject" "$MODPATH/webui_bridge" "$MODPATH/cleverestrickyd" \
  "$MODPATH/cleverestricky_backend" "$MODPATH/daemon" "$MODPATH/service.sh" "$MODPATH/action.sh" "$MODPATH/emergency-report.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/identity-zygisk.sh" "$MODPATH/uninstall.sh" \
  || abort "! Could not set module executable permissions"
chmod 644 "$MODPATH/integrity_manifest.json" || abort "! Could not set integrity manifest permissions"
chmod 644 "$MODPATH/ai-guides.zip" || abort "! Could not set guide archive permissions"
chmod 644 "$MODPATH/webui-host.sha256" || abort "! Could not set host pin permissions"
chown 0:0 "$MODPATH/webui-host.sha256" || abort "! Could not set host pin ownership"

CONFIG_DIR=/data/adb/cleverestricky
if [ -L "$CONFIG_DIR" ]; then
  abort "! Refusing symlinked configuration directory: $CONFIG_DIR"
fi
if [ -e "$CONFIG_DIR" ] && [ ! -d "$CONFIG_DIR" ]; then
  abort "! Configuration path is not a directory: $CONFIG_DIR"
fi
if [ ! -d "$CONFIG_DIR" ]; then
  ui_print "- Creating configuration directory"
  mkdir -p "$CONFIG_DIR" || abort "! Could not create configuration directory"
fi
chmod 700 "$CONFIG_DIR" || abort "! Could not secure configuration directory"
chown 0:0 "$CONFIG_DIR" || abort "! Could not set configuration directory ownership"

for legacy_webui_file in web_port web_token.txt; do
  if [ -e "$CONFIG_DIR/$legacy_webui_file" ] || [ -L "$CONFIG_DIR/$legacy_webui_file" ]; then
    rm -f "$CONFIG_DIR/$legacy_webui_file" || abort "! Could not remove legacy WebUI metadata"
  fi
done

for config_file in spoof_build_vars custom_props target.txt identity_target.txt drm_packages.txt boot_props_mode \
  spoof_enabled spoof_switch_initialized spoof_build_identity spoof_custom_props global_mode global_identity_mode global_build_identity global_telephony_mode global_attestation_mode tee_broken_mode \
  auto_keybox_check block_invalid_keyboxes random_on_boot rkp_passthrough drm_passthrough hide_sensitive_props \
  spoof_region_cn telephony privacy_seed boot_key boot_hash app_config templates.json custom_templates module_hash \
  servers.json keybox.xml lang.json spoof_build_vars.next apply_profile policy_state_v2.json \
  policy_state_v2.last_good.json debug_logging settings_schema_v3 settings_schema_v4 attestation_status_cache.json; do
  config_path="$CONFIG_DIR/$config_file"
  if [ -e "$config_path" ] || [ -L "$config_path" ]; then
    if [ -L "$config_path" ] || [ ! -f "$config_path" ]; then
      abort "! Refusing unsafe configuration file: $config_file"
    fi
    chmod 600 "$config_path" || abort "! Could not secure configuration file: $config_file"
    chown 0:0 "$config_path" || abort "! Could not set configuration ownership: $config_file"
  fi
done

if [ -e "$CONFIG_DIR/keyboxes" ] || [ -L "$CONFIG_DIR/keyboxes" ]; then
  if [ -L "$CONFIG_DIR/keyboxes" ] || [ ! -d "$CONFIG_DIR/keyboxes" ]; then
    abort "! Refusing unsafe keybox directory"
  fi
  chmod 700 "$CONFIG_DIR/keyboxes" || abort "! Could not secure keybox directory"
  chown 0:0 "$CONFIG_DIR/keyboxes" || abort "! Could not set keybox directory ownership"
fi

for marker_file in settings_schema_v3 settings_schema_v4 global_mode auto_keybox_check block_invalid_keyboxes recommended_defaults_pending spoof_switch_initialized; do
  if [ -L "$CONFIG_DIR/$marker_file" ]; then
    abort "! Refusing symlinked configuration marker: $marker_file"
  fi
done

if [ ! -e "$CONFIG_DIR/settings_schema_v3" ]; then
  ui_print "- Migrating persisted settings to schema v3"
  if [ -e "$CONFIG_DIR/rkp_passthrough" ]; then
    rm -f "$CONFIG_DIR/rkp_passthrough" || abort "! Could not retire the old RKP setting"
  fi
  if [ -d "$CONFIG_DIR/keyboxes" ]; then
    for stale_cache in "$CONFIG_DIR"/keyboxes/*.cbox.cache; do
      [ -e "$stale_cache" ] || continue
      if [ -L "$stale_cache" ] || [ ! -f "$stale_cache" ]; then
        abort "! Refusing unsafe CBOX cache during migration"
      fi
      rm -f "$stale_cache" || abort "! Could not invalidate stale CBOX cache"
    done
  fi
  : > "$CONFIG_DIR/settings_schema_v3" || abort "! Could not write settings migration marker"
  chmod 600 "$CONFIG_DIR/settings_schema_v3" || abort "! Could not secure settings migration marker"
  chown 0:0 "$CONFIG_DIR/settings_schema_v3" || abort "! Could not set settings migration marker ownership"
fi

if [ ! -e "$CONFIG_DIR/settings_schema_v4" ]; then
  ui_print "- Migrating identity scope to per-domain global switches"
  if [ -L "$CONFIG_DIR/global_identity_mode" ]; then
    abort "! Refusing symlinked legacy global identity marker"
  fi
  if [ -f "$CONFIG_DIR/global_identity_mode" ]; then
    for scope_marker in global_telephony_mode global_attestation_mode; do
      if [ ! -e "$CONFIG_DIR/$scope_marker" ] && [ ! -L "$CONFIG_DIR/$scope_marker" ]; then
        : > "$CONFIG_DIR/$scope_marker" || abort "! Could not preserve global identity scope: $scope_marker"
        chmod 600 "$CONFIG_DIR/$scope_marker" || abort "! Could not secure global identity scope: $scope_marker"
        chown 0:0 "$CONFIG_DIR/$scope_marker" || abort "! Could not set global identity scope ownership: $scope_marker"
      fi
    done
    rm -f "$CONFIG_DIR/global_identity_mode" || abort "! Could not retire the legacy global identity marker"
  fi
  : > "$CONFIG_DIR/settings_schema_v4" || abort "! Could not write settings migration marker"
  chmod 600 "$CONFIG_DIR/settings_schema_v4" || abort "! Could not secure settings migration marker"
  chown 0:0 "$CONFIG_DIR/settings_schema_v4" || abort "! Could not set settings migration marker ownership"
fi

if [ ! -e "$CONFIG_DIR/spoof_switch_initialized" ]; then
  ui_print "- Applying recommended default settings"
  [ -e "$CONFIG_DIR/global_mode" ] || : > "$CONFIG_DIR/global_mode" \
    || abort "! Could not enable Global Mode"
  [ -e "$CONFIG_DIR/auto_keybox_check" ] || : > "$CONFIG_DIR/auto_keybox_check" \
    || abort "! Could not enable automatic keybox checking"
  [ -e "$CONFIG_DIR/block_invalid_keyboxes" ] || : > "$CONFIG_DIR/block_invalid_keyboxes" \
    || abort "! Could not enable blocking invalid keyboxes"
  if [ ! -e "$CONFIG_DIR/policy_state_v2.json" ]; then
    extract "$ZIPFILE" 'policy_state_v2.json' "$TMPDIR"
    mv "$TMPDIR/policy_state_v2.json" "$CONFIG_DIR/policy_state_v2.json" \
      || abort "! Could not install the default policy state"
  fi
  : > "$CONFIG_DIR/recommended_defaults_pending" \
    || abort "! Could not schedule device-aware default evaluation"
  chmod 600 "$CONFIG_DIR/recommended_defaults_pending" \
    || abort "! Could not secure device-aware default marker"
  chown 0:0 "$CONFIG_DIR/recommended_defaults_pending" \
    || abort "! Could not set device-aware default marker ownership"
  : > "$CONFIG_DIR/spoof_switch_initialized" \
    || abort "! Could not write the default-settings migration marker"
fi
chmod 600 "$CONFIG_DIR/spoof_switch_initialized" || abort "! Could not secure migration marker"
[ ! -e "$CONFIG_DIR/global_mode" ] || chmod 600 "$CONFIG_DIR/global_mode" \
  || abort "! Could not secure Global Mode switch"
[ ! -e "$CONFIG_DIR/global_telephony_mode" ] || chmod 600 "$CONFIG_DIR/global_telephony_mode" \
  || abort "! Could not secure global telephony scope switch"
[ ! -e "$CONFIG_DIR/global_attestation_mode" ] || chmod 600 "$CONFIG_DIR/global_attestation_mode" \
  || abort "! Could not secure global attestation scope switch"
[ ! -e "$CONFIG_DIR/auto_keybox_check" ] || chmod 600 "$CONFIG_DIR/auto_keybox_check" \
  || abort "! Could not secure automatic keybox checking"
[ ! -e "$CONFIG_DIR/block_invalid_keyboxes" ] || chmod 600 "$CONFIG_DIR/block_invalid_keyboxes" \
  || abort "! Could not secure blocking invalid keyboxes switch"
[ ! -e "$CONFIG_DIR/policy_state_v2.json" ] || chmod 600 "$CONFIG_DIR/policy_state_v2.json" \
  || abort "! Could not secure default policy state"
[ ! -e "$CONFIG_DIR/spoof_enabled" ] || chmod 600 "$CONFIG_DIR/spoof_enabled" \
  || abort "! Could not secure identity Spoof Engine switch"

if [ ! -f "$CONFIG_DIR/spoof_build_vars" ]; then
  ui_print "- Adding default spoof_build_vars"
  extract "$ZIPFILE" 'spoof_build_vars' "$TMPDIR"
  mv "$TMPDIR/spoof_build_vars" "$CONFIG_DIR/spoof_build_vars" \
    || abort "! Could not install spoof_build_vars"
fi
chmod 600 "$CONFIG_DIR/spoof_build_vars" || abort "! Could not secure spoof_build_vars"

# Security patch settings now belong to the canonical Identity policy.
rm -f "$CONFIG_DIR/security_patch.txt" || abort "! Could not retire legacy patch configuration"

if [ ! -f "$CONFIG_DIR/target.txt" ]; then
  ui_print "- Adding default target scope"
  extract "$ZIPFILE" 'target.txt' "$TMPDIR"
  mv "$TMPDIR/target.txt" "$CONFIG_DIR/target.txt" \
    || abort "! Could not install target.txt"
fi
chmod 600 "$CONFIG_DIR/target.txt" || abort "! Could not secure target.txt"

if [ ! -f "$CONFIG_DIR/identity_target.txt" ]; then
  ui_print "- Adding default identity target scope"
  extract "$ZIPFILE" 'identity_target.txt' "$TMPDIR"
  mv "$TMPDIR/identity_target.txt" "$CONFIG_DIR/identity_target.txt" \
    || abort "! Could not install identity_target.txt"
fi
chmod 600 "$CONFIG_DIR/identity_target.txt" || abort "! Could not secure identity_target.txt"

if [ ! -f "$CONFIG_DIR/drm_packages.txt" ]; then
  ui_print "- Adding default DRM passthrough scope"
  extract "$ZIPFILE" 'drm_packages.txt' "$TMPDIR"
  mv "$TMPDIR/drm_packages.txt" "$CONFIG_DIR/drm_packages.txt" \
    || abort "! Could not install drm_packages.txt"
fi
chmod 600 "$CONFIG_DIR/drm_packages.txt" || abort "! Could not secure drm_packages.txt"

if [ ! -f "$CONFIG_DIR/boot_props_mode" ]; then
  ui_print "- Adding automatic identity-build compatibility policy"
  extract "$ZIPFILE" 'boot_props_mode' "$TMPDIR"
  mv "$TMPDIR/boot_props_mode" "$CONFIG_DIR/boot_props_mode" \
    || abort "! Could not install boot_props_mode"
fi
chmod 600 "$CONFIG_DIR/boot_props_mode" || abort "! Could not secure boot_props_mode"

for optional_flag in auto_keybox_check block_invalid_keyboxes drm_passthrough hide_sensitive_props debug_logging; do
  [ ! -e "$CONFIG_DIR/$optional_flag" ] || chmod 600 "$CONFIG_DIR/$optional_flag" \
    || abort "! Could not secure $optional_flag"
done

chown 0:0 "$CONFIG_DIR/spoof_build_vars" \
  "$CONFIG_DIR/target.txt" "$CONFIG_DIR/identity_target.txt" "$CONFIG_DIR/drm_packages.txt" \
  "$CONFIG_DIR/boot_props_mode" "$CONFIG_DIR/spoof_switch_initialized" \
  || abort "! Could not set configuration file ownership"
[ ! -e "$CONFIG_DIR/global_mode" ] || chown 0:0 "$CONFIG_DIR/global_mode" \
  || abort "! Could not set Global Mode switch ownership"
[ ! -e "$CONFIG_DIR/global_telephony_mode" ] || chown 0:0 "$CONFIG_DIR/global_telephony_mode" \
  || abort "! Could not set global telephony scope ownership"
[ ! -e "$CONFIG_DIR/global_attestation_mode" ] || chown 0:0 "$CONFIG_DIR/global_attestation_mode" \
  || abort "! Could not set global attestation scope ownership"
[ ! -e "$CONFIG_DIR/auto_keybox_check" ] || chown 0:0 "$CONFIG_DIR/auto_keybox_check" \
  || abort "! Could not set keybox revocation switch ownership"
[ ! -e "$CONFIG_DIR/block_invalid_keyboxes" ] || chown 0:0 "$CONFIG_DIR/block_invalid_keyboxes" \
  || abort "! Could not set block invalid keyboxes switch ownership"
[ ! -e "$CONFIG_DIR/policy_state_v2.json" ] || chown 0:0 "$CONFIG_DIR/policy_state_v2.json" \
  || abort "! Could not set policy state ownership"
[ ! -e "$CONFIG_DIR/spoof_enabled" ] || chown 0:0 "$CONFIG_DIR/spoof_enabled" \
  || abort "! Could not set identity Spoof Engine switch ownership"
[ ! -e "$CONFIG_DIR/spoof_build_identity" ] || chown 0:0 "$CONFIG_DIR/spoof_build_identity" \
  || abort "! Could not set identity build switch ownership"
[ ! -e "$CONFIG_DIR/drm_passthrough" ] || chown 0:0 "$CONFIG_DIR/drm_passthrough" \
  || abort "! Could not set DRM passthrough ownership"
[ ! -e "$CONFIG_DIR/hide_sensitive_props" ] || chown 0:0 "$CONFIG_DIR/hide_sensitive_props" \
  || abort "! Could not set sensitive-property switch ownership"
[ ! -e "$CONFIG_DIR/debug_logging" ] || chown 0:0 "$CONFIG_DIR/debug_logging" \
  || abort "! Could not set debug logging switch ownership"

normalize_conflicting_module_name() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]_.-'
}

is_conflicting_attestation_module() {
  conflict_id=$1
  conflict_name=$2

  case "$conflict_id" in
    tricky_store|teesim|playintegrityfix|play_integrity_fix|playintegrity|pif|playcurl|safetynet-fix|safetynet_fix|ih8sn) return 0 ;;
  esac

  normalized_conflict_name=$(normalize_conflicting_module_name "$conflict_name")
  case "$normalized_conflict_name" in
    trickystore*|teesimulator*|playintegrityfix*|playintegrity*|playcurl*|safetynetfix*|universalsafetynetfix*|ih8sn*) return 0 ;;
  esac

  return 1
}

inspect_conflicting_modules_from_root() {
  modules_root=$1
  [ -e "$modules_root" ] || return 0
  [ -L "$modules_root" ] && abort "! Refusing symlinked modules root: $modules_root"
  [ -d "$modules_root" ] || abort "! Modules root is not a directory: $modules_root"
  inspected=0
  for candidate in "$modules_root"/*; do
    inspected=$((inspected + 1))
    [ "$inspected" -le 4096 ] || abort "! Too many installed modules to inspect safely"
    [ -d "$candidate" ] && [ ! -L "$candidate" ] || continue
    [ ! -e "$candidate/disable" ] && [ ! -L "$candidate/disable" ] || continue
    [ ! -e "$candidate/remove" ] && [ ! -L "$candidate/remove" ] || continue
    candidate_dir=${candidate##*/}
    [ "$candidate_dir" != cleverestricky ] || continue
    conflict_id=$candidate_dir
    conflict_name=$candidate_dir
    prop_file="$candidate/module.prop"
    if [ -f "$prop_file" ] && [ ! -L "$prop_file" ]; then
      prop_size=$(wc -c < "$prop_file") || abort "! Could not inspect module metadata"
      case "$prop_size" in ''|*[!0-9]*) abort "! Invalid module metadata size" ;; esac
      [ "$prop_size" -le 4096 ] || abort "! Module metadata exceeds the inspection limit"
      conflict_id=$(grep_prop id "$prop_file" 2>/dev/null || true)
      conflict_name=$(grep_prop name "$prop_file" 2>/dev/null || true)
    fi
    normalized_conflict_name=$(normalize_conflicting_module_name "$conflict_name")
    case "$conflict_id:$normalized_conflict_name" in
      tricky_store:*|teesim:*|*:trickystore*|*:teesimulator*)
        abort "! Another Keystore interceptor is active: $candidate_dir. Disable it before installing CleveresTricky; no modules were removed."
        ;;
    esac
    if is_conflicting_attestation_module "$conflict_id" "$conflict_name"; then
      ui_print "- Identity provider preserved: $candidate_dir. CleveresTricky Build Identity will pause while a fingerprint provider is active."
    fi
  done
}

for modules_root in /data/adb/modules /data/adb/modules_update /data/adb/ksu/modules /data/adb/ksu/modules_update /data/adb/ap/modules /data/adb/ap/modules_update; do
  inspect_conflicting_modules_from_root "$modules_root"
done

remove_legacy_identity_companion() {
  legacy_parent=${MODPATH%/*}
  [ -d "$legacy_parent" ] && [ ! -L "$legacy_parent" ] \
    || abort "! Module update directory is unsafe"
  case "${legacy_parent##*/}" in
    modules_update) legacy_other_parent=${legacy_parent%_update} ;;
    modules) legacy_other_parent=${legacy_parent}_update ;;
    *) legacy_other_parent=$legacy_parent ;;
  esac
  for legacy_root in "$legacy_parent" "$legacy_other_parent"; do
    [ ! -L "$legacy_root" ] || abort "! Legacy module directory is unsafe"
    legacy_module="$legacy_root/cleverestricky_identity_zygisk"
    [ -e "$legacy_module" ] || [ -L "$legacy_module" ] || continue
    [ -d "$legacy_module" ] && [ ! -L "$legacy_module" ] \
      || abort "! Legacy Identity module is unsafe"
    legacy_metadata="$legacy_module/module.prop"
    [ -f "$legacy_metadata" ] && [ ! -L "$legacy_metadata" ] \
      || abort "! Legacy Identity metadata is unsafe"
    legacy_size=$(wc -c < "$legacy_metadata") || abort "! Could not read legacy Identity metadata"
    case "$legacy_size" in ''|*[!0-9]*) abort "! Invalid legacy Identity metadata size" ;; esac
    if ! { [ "$legacy_size" -le 4096 ] && [ "$(grep -c '^id=' "$legacy_metadata")" = 1 ] &&
      grep -qx 'id=cleverestricky_identity_zygisk' "$legacy_metadata"; }; then
      abort "! Refusing to remove an unrelated module"
    fi
  done
  for legacy_root in "$legacy_parent" "$legacy_other_parent"; do
    legacy_module="$legacy_root/cleverestricky_identity_zygisk"
    [ -e "$legacy_module" ] || continue
    rm -rf "$legacy_module" || abort "! Could not remove the retired Identity module"
  done
}

remove_legacy_identity_companion
# shellcheck disable=SC1091
. "$MODPATH/identity-zygisk.sh"
has_zygisk=false
if ct_zygisk_provider_available "$MODPATH" "$CONFIG_DIR"; then has_zygisk=true; fi
ct_zygisk_reconcile "$MODPATH" "$CONFIG_DIR" auto || abort "! Could not reconcile optional Identity payload"
if [ "$has_zygisk" = true ]; then
  ui_print "- Optional Zygisk Identity loads only while Identity is enabled"
else
  ui_print "- Identity payload is dormant; enable a Zygisk provider and reboot when needed"
fi
