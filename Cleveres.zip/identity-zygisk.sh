#!/system/bin/sh
# The signed source is inert. Only zygisk/<abi>.so is visible to providers.
# Reconcile on install, boot and setting changes; never start a worker or poll.

ct_zygisk_safe_directory() {
  case "$1" in /*) ;; *) return 1 ;; esac
  ct_dir=$1
  while [ "$ct_dir" != / ] && [ -n "$ct_dir" ]; do
    [ -d "$ct_dir" ] && [ ! -L "$ct_dir" ] || return 1
    ct_dir=${ct_dir%/*}
  done
}

ct_zygisk_provider_available() {
  if [ -e "$2/disable_zygisk" ] || [ -L "$2/disable_zygisk" ]; then return 1; fi
  if [ -f "$2/force_zygisk" ] && [ ! -L "$2/force_zygisk" ]; then return 0; fi
  ct_search_root=${1%/*}
  for ct_root in "$ct_search_root" "${ct_search_root%_update}" /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules; do
    ct_zygisk_safe_directory "$ct_root" || continue
    for ct_id in zygisksu zygisk_next zygisknext re_zygisk rezygisk neozygisk neo_zygisk; do
      ct_provider="$ct_root/$ct_id"
      if [ -d "$ct_provider" ] && [ ! -L "$ct_provider" ] &&
         [ ! -e "$ct_provider/disable" ] && [ ! -L "$ct_provider/disable" ] &&
         [ ! -e "$ct_provider/remove" ] && [ ! -L "$ct_provider/remove" ]; then return 0; fi
    done
  done
  if command -v magisk >/dev/null 2>&1; then
    ct_setting=$(timeout -k 1 2 magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null) || ct_setting=
    case "$ct_setting" in 1|value=1) return 0 ;; esac
  fi
  return 1
}

# Re-check all local disable markers before and after publishing a payload.
ct_zygisk_flags_enabled() {
  [ -f "$1/spoof_enabled" ] && [ ! -L "$1/spoof_enabled" ] &&
  [ ! -e "$1/disable" ] && [ ! -L "$1/disable" ] &&
  [ ! -e "$1/disable_zygisk" ] && [ ! -L "$1/disable_zygisk" ]
}

ct_zygisk_reconcile() (
  ct_module=$1
  ct_config=$2
  ct_requested=${3:-auto}
  case "$ct_requested" in auto|on|off) ;; *) return 1 ;; esac
  ct_zygisk_safe_directory "$ct_module" && ct_zygisk_safe_directory "$ct_config" || return 1
  ct_active="$ct_module/zygisk"
  # Staging stays outside the signed module tree. A killed writer leaves no
  # partial executable in a provider's discovery path or unexpected module file.
  [ ! -L "$ct_active" ] || return 1
  [ ! -e "$ct_active" ] || [ -d "$ct_active" ] || return 1

  ct_enabled=false
  if [ "$ct_requested" != off ] &&
     ct_zygisk_flags_enabled "$ct_config" &&
     ct_zygisk_provider_available "$ct_module" "$ct_config"; then
    ct_enabled=true
  fi
  if [ "$ct_enabled" = false ]; then
    # Removing the whole directory also removes stale provider status files.
    # It does not unload hooks from already running apps: that needs a reboot.
    rm -rf "$ct_active" || return 1
    return 0
  fi

  ct_payload="$ct_module/identity_zygisk.so"
  [ -f "$ct_payload" ] && [ ! -L "$ct_payload" ] || return 1
  ct_checksum="$ct_payload.sha256"
  [ -f "$ct_checksum" ] && [ ! -L "$ct_checksum" ] || return 1
  ct_checksum_size=$(wc -c < "$ct_checksum") || return 1
  case "$ct_checksum_size" in ''|*[!0-9]*) return 1 ;; esac
  [ "$ct_checksum_size" -ge 64 ] && [ "$ct_checksum_size" -le 1024 ] || return 1
  ct_size=$(wc -c < "$ct_payload") || return 1
  case "$ct_size" in ''|*[!0-9]*) return 1 ;; esac
  [ "$ct_size" -ge 20 ] && [ "$ct_size" -le 8388608 ] || return 1
  ct_magic=$(od -An -tx1 -N7 "$ct_payload" | tr -d ' \n') || return 1
  [ "$ct_magic" = 7f454c46020101 ] || return 1
  ct_machine=$(od -An -tx1 -j18 -N2 "$ct_payload" | tr -d ' \n') || return 1
  case "$ct_machine" in b700) ct_abi=arm64-v8a ;; 3e00) ct_abi=x86_64 ;; *) return 1 ;; esac
  case "$ct_abi" in arm64-v8a) ct_stale_abi=x86_64 ;; x86_64) ct_stale_abi=arm64-v8a ;; esac
  if [ -f "$ct_active/$ct_abi.so" ] && [ ! -L "$ct_active/$ct_abi.so" ] &&
     cmp -s "$ct_payload" "$ct_active/$ct_abi.so" &&
     [ -f "$ct_active/$ct_abi.so.sha256" ] && [ ! -L "$ct_active/$ct_abi.so.sha256" ] &&
     cmp -s "$ct_checksum" "$ct_active/$ct_abi.so.sha256"; then
    # The payload is already current; still purge any obsolete opposite ABI.
    rm -f "$ct_active/$ct_stale_abi.so" "$ct_active/$ct_stale_abi.so.sha256" || return 1
    if ! ct_zygisk_flags_enabled "$ct_config"; then
      rm -rf "$ct_active" || return 1
    fi
    return 0
  fi

  # Atomic publication requires the configuration and module to share a device.
  [ "$(stat -c %d "$ct_config")" = "$(stat -c %d "$ct_module")" ] || return 1
  ct_stage=$(umask 077; mktemp -d "$ct_config/.zygisk-stage.XXXXXX") || return 1
  trap 'rm -rf "$ct_stage"' EXIT
  trap 'exit 1' HUP INT TERM
  # Bound the copy even if a root-owned payload changes unexpectedly during I/O.
  dd if="$ct_payload" of="$ct_stage/$ct_abi.so" bs=8192 count=1025 2>/dev/null || return 1
  [ "$(wc -c < "$ct_stage/$ct_abi.so")" = "$ct_size" ] &&
    cmp -s "$ct_payload" "$ct_stage/$ct_abi.so" || return 1
  # The adapter's startup gate requires a checksum for every discovered payload,
  # including this derived copy of the signed inert library.
  dd if="$ct_checksum" of="$ct_stage/$ct_abi.so.sha256" bs=1025 count=1 2>/dev/null || return 1
  [ "$(wc -c < "$ct_stage/$ct_abi.so.sha256")" = "$ct_checksum_size" ] &&
    cmp -s "$ct_checksum" "$ct_stage/$ct_abi.so.sha256" || return 1
  chown 0:0 "$ct_stage" "$ct_stage/$ct_abi.so" "$ct_stage/$ct_abi.so.sha256" &&
    chmod 755 "$ct_stage" && chmod 644 "$ct_stage/$ct_abi.so" "$ct_stage/$ct_abi.so.sha256" || return 1
  chcon u:object_r:system_file:s0 "$ct_stage" "$ct_stage/$ct_abi.so" "$ct_stage/$ct_abi.so.sha256" 2>/dev/null || true
  # Both copies are covered by the signed manifest. The inert source is required,
  # while zygisk/ remains optional under the existing verifier contract.
  # An explicit disable during staging must win, without publishing a new payload.
  if ! ct_zygisk_flags_enabled "$ct_config"; then
    rm -rf "$ct_active" || return 1
    return 0
  fi
  # Preserve the previous working ABI file until the new one is fully copied,
  # verified and ready for an atomic rename on the same filesystem.
  if [ -d "$ct_active" ]; then
    [ ! -L "$ct_active" ] || return 1
    ct_active_checksum="$ct_active/$ct_abi.so.sha256"
    if [ -e "$ct_active_checksum" ] || [ -L "$ct_active_checksum" ]; then
      [ -f "$ct_active_checksum" ] && [ ! -L "$ct_active_checksum" ] || return 1
      ln "$ct_active_checksum" "$ct_stage/previous.sha256" || return 1
    fi
    mv -fT "$ct_stage/$ct_abi.so.sha256" "$ct_active_checksum" || return 1
    # -T refuses a directory in place of the expected .so file.
    if ! mv -fT "$ct_stage/$ct_abi.so" "$ct_active/$ct_abi.so"; then
      if [ -f "$ct_stage/previous.sha256" ]; then
        mv -fT "$ct_stage/previous.sha256" "$ct_active_checksum" || return 1
      else
        rm -f "$ct_active_checksum" || return 1
      fi
      return 1
    fi
  else
    # First activation: publish the complete staged directory in one rename.
    # If another writer won the race with identical content, it is also success.
    if ! mv -T "$ct_stage" "$ct_active"; then
      [ -d "$ct_active" ] && [ ! -L "$ct_active" ] &&
        [ -f "$ct_active/$ct_abi.so" ] && [ ! -L "$ct_active/$ct_abi.so" ] &&
        cmp -s "$ct_payload" "$ct_active/$ct_abi.so" &&
        [ -f "$ct_active/$ct_abi.so.sha256" ] && [ ! -L "$ct_active/$ct_abi.so.sha256" ] &&
        cmp -s "$ct_checksum" "$ct_active/$ct_abi.so.sha256" || return 1
    fi
  fi
  # A successfully installed ABI must not leave the previous architecture active.
  rm -f "$ct_active/$ct_stale_abi.so" "$ct_active/$ct_stale_abi.so.sha256" || return 1
  # A concurrent disable must win over a writer that started from an older flag.
  if ! ct_zygisk_flags_enabled "$ct_config"; then
    rm -rf "$ct_active" || return 1
  fi
)

if [ "${1:-}" = --sync ]; then
  ct_zygisk_reconcile "${0%/*}" "${CLEVERES_TRICKY_CONFIG_DIR:-/data/adb/cleverestricky}" "${2:-auto}"
fi
