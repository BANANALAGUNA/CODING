#!/system/bin/sh
MODDIR=${0%/*}

remove_identity_companion() {
  companion=$1
  companion_parent=${companion%/*}
  [ ! -L "$companion_parent" ] || return 1
  [ ! -L "$companion" ] || return 1
  [ -e "$companion" ] || return 0
  [ -d "$companion" ] || return 1
  metadata="$companion/module.prop"
  [ -f "$metadata" ] && [ ! -L "$metadata" ] || return 1
  metadata_size=$(wc -c < "$metadata") || return 1
  case "$metadata_size" in ''|*[!0-9]*) return 1 ;; esac
  [ "$metadata_size" -le 4096 ] || return 1
  [ "$(grep -c '^id=' "$metadata")" = 1 ] || return 1
  grep -qx 'id=cleverestricky_identity_zygisk' "$metadata" || return 1
  rm -rf "$companion"
}

remove_identity_companion "${MODDIR%/*}/cleverestricky_identity_zygisk" || exit 1
case "${MODDIR%/*}" in
  */modules)
    remove_identity_companion "${MODDIR%/*}_update/cleverestricky_identity_zygisk" || exit 1
    ;;
  */modules_update)
    live_modules=${MODDIR%/*}
    remove_identity_companion "${live_modules%_update}/cleverestricky_identity_zygisk" || exit 1
    ;;
esac
