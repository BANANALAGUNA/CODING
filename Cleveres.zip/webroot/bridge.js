(function(global){'use strict';const nativeApi=global.ksu;const modulePaths=['/data/adb/modules/cleverestricky/webui_bridge','/data/adb/ksu/modules/cleverestricky/webui_bridge','/data/adb/ap/modules/cleverestricky/webui_bridge'];const chunkBytes=48*1024;const maxUploadBytes=20*1024*1024;const maxResponseBytes=20*1024*1024;const maxEnvelopeChars=1024*1024;const responseFields=new Set(['version','status','statusText','mimeType','size','body','downloadId']);const communityUrl='https://t.me/cleverestech';const keyboxHubUrl='https://keybox.tryigit.dev/';const nativeSuccessMarker='__CT_NATIVE_OK__';const nativeFilePickerIds=new Set(['kbFilePicker','cboxGenFilePicker','restoreInput']);const languageStorageKey='cleverestricky.language.v1';const systemLocaleStorageKey='cleverestricky.system_locale.v1';const supportedLocales=new Set(['en','tr','zh-CN','es','de','ru','id','hi','ar']);let callbackCounter=0;const configRoot='/data/adb/cleverestricky';const nativeRuntimeLog=`${configRoot}/native_runtime.log`;const policyResponsePaths=new Set(['/api/policy_state','/api/profile_v2']);let latestPolicyState=null;let policyStateRequest=null;let profileMutationQueue=Promise.resolve();let logsReady=false;const profileEnabledByName=new Map();const profileEnabledBySignature=new Map();const EXTENSION_COPY={tr:{'Healthy':'Sağlıklı','Stale template, manual refresh needed':'Bayat şablon, elle yenile','Backup source: {value}':'Yedek kaynak: {value}','Cron Auto Identity':'Cron Otomatik Kimlik','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Build Identity açıkken her 24 saatte bir yeni Otomatik Kimlik indirir ve uygular.','Profile enabled':'Profil etkin','Profile disabled':'Profil devre dışı','Enabled':'Etkin','Disabled':'Devre dışı','Auto Identity saved. Build Identity remains disabled.':'Otomatik Kimlik kaydedildi. Build Identity devre dışı kalmaya devam ediyor.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'Kimlik yeniden başlatma olmadan uygulandı. Açık uygulamalar eski Build değerlerini gösteriyorsa uygulamaları yeniden başlatın.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'Canlı Kimlik uygulaması kullanılamıyor. Bu Build/bölge özellik değişiklikleri için yeniden başlatma gerekiyor.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'Daha önce uygulanmış Build/bölge kimliğini kapatmak, özgün özellikleri geri yüklemek için yeniden başlatma gerekebilir.','No CleveresTricky logs found.':'CleveresTricky günlüğü bulunamadı.'},'zh-CN':{'Healthy':'健康','Stale template, manual refresh needed':'过期模板，需手动刷新','Backup source: {value}':'备用源: {value}','Cron Auto Identity':'Cron 自动身份','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'启用 Build Identity 时，每 24 小时获取并应用新的自动身份。','Profile enabled':'配置档案已启用','Profile disabled':'配置档案已禁用','Enabled':'已启用','Disabled':'已禁用','Auto Identity saved. Build Identity remains disabled.':'自动身份已保存，Build Identity 仍保持禁用。','Identity applied without reboot. Restart open apps if they still show previous Build values.':'身份已无需重启直接应用。若已打开的应用仍显示旧 Build 值，请重启这些应用。','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'无法实时应用身份；这些 Build/区域属性更改需要重启。','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'关闭已应用的 Build/区域身份后，可能需要重启才能恢复原始属性。','No CleveresTricky logs found.':'未找到 CleveresTricky 日志。'},es:{'Healthy':'Saludable','Stale template, manual refresh needed':'Plantilla obsoleta, actualizar manualmente','Backup source: {value}':'Fuente de respaldo: {value}','Cron Auto Identity':'Identidad automática Cron','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Obtiene y aplica una nueva identidad automática cada 24 horas mientras Build Identity está activado.','Profile enabled':'Perfil activado','Profile disabled':'Perfil desactivado','Enabled':'Activado','Disabled':'Desactivado','Auto Identity saved. Build Identity remains disabled.':'Identidad automática guardada. Build Identity permanece desactivado.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'Identidad aplicada sin reiniciar. Reinicia las apps abiertas si aún muestran valores Build anteriores.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'La aplicación en vivo de identidad no está disponible. Estos cambios de propiedades Build/región requieren reinicio.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'Desactivar una identidad Build/región ya aplicada puede requerir reinicio para restaurar las propiedades originales.','No CleveresTricky logs found.':'No se encontraron registros de CleveresTricky.'},de:{'Healthy':'Gesund','Stale template, manual refresh needed':'Veraltete Vorlage, manuell aktualisieren','Backup source: {value}':'Backup-Quelle: {value}','Cron Auto Identity':'Cron Auto-Identität','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Ruft alle 24 Stunden eine neue Auto-Identität ab und wendet sie an, solange Build Identity aktiviert ist.','Profile enabled':'Profil aktiviert','Profile disabled':'Profil deaktiviert','Enabled':'Aktiviert','Disabled':'Deaktiviert','Auto Identity saved. Build Identity remains disabled.':'Auto-Identität gespeichert. Build Identity bleibt deaktiviert.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'Identität ohne Neustart angewendet. Starte offene Apps neu, falls sie noch alte Build-Werte anzeigen.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'Live-Anwendung der Identität ist nicht verfügbar. Für diese Build-/Regionsänderungen ist ein Neustart erforderlich.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'Das Deaktivieren einer bereits angewendeten Build-/Regionsidentität kann einen Neustart zum Wiederherstellen der Originalwerte erfordern.','No CleveresTricky logs found.':'Keine CleveresTricky-Protokolle gefunden.'},ru:{'Healthy':'Исправно','Stale template, manual refresh needed':'Устаревший шаблон, обновите вручную','Backup source: {value}':'Резервный источник: {value}','Cron Auto Identity':'Cron Автоидентичность','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Получает и применяет новую автоидентичность каждые 24 часа, пока включён Build Identity.','Profile enabled':'Профиль включён','Profile disabled':'Профиль отключён','Enabled':'Включено','Disabled':'Отключено','Auto Identity saved. Build Identity remains disabled.':'Автоидентичность сохранена. Build Identity остаётся отключённым.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'Идентичность применена без перезагрузки. Перезапустите открытые приложения, если они показывают старые значения Build.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'Живое применение идентичности недоступно. Для этих изменений Build/региона требуется перезагрузка.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'Отключение уже применённой Build/региональной идентичности может потребовать перезагрузки для возврата исходных свойств.','No CleveresTricky logs found.':'Журналы CleveresTricky не найдены.'},id:{'Healthy':'Sehat','Stale template, manual refresh needed':'Templat usang, perlu penyegaran manual','Backup source: {value}':'Sumber cadangan: {value}','Cron Auto Identity':'Cron Identitas Otomatis','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Mengambil dan menerapkan Identitas Otomatis baru setiap 24 jam saat Build Identity aktif.','Profile enabled':'Profil diaktifkan','Profile disabled':'Profil dinonaktifkan','Enabled':'Aktif','Disabled':'Nonaktif','Auto Identity saved. Build Identity remains disabled.':'Identitas Otomatis disimpan. Build Identity tetap nonaktif.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'Identitas diterapkan tanpa reboot. Mulai ulang aplikasi yang masih menampilkan nilai Build lama.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'Penerapan Identitas langsung tidak tersedia. Perubahan properti Build/wilayah ini memerlukan reboot.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'Menonaktifkan identitas Build/wilayah yang sudah diterapkan mungkin memerlukan reboot untuk memulihkan properti asli.','No CleveresTricky logs found.':'Log CleveresTricky tidak ditemukan.'},hi:{'Healthy':'स्वस्थ','Stale template, manual refresh needed':'पुराना टेम्पलेट, मैन्युअल रूप से रीफ़्रेश करें','Backup source: {value}':'बैकअप स्रोत: {value}','Cron Auto Identity':'Cron ऑटो पहचान','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'Build Identity चालू रहने पर हर 24 घंटे में नई ऑटो पहचान लाता और लागू करता है।','Profile enabled':'प्रोफ़ाइल चालू','Profile disabled':'प्रोफ़ाइल बंद','Enabled':'चालू','Disabled':'बंद','Auto Identity saved. Build Identity remains disabled.':'ऑटो पहचान सहेजी गई। Build Identity बंद ही रहेगा।','Identity applied without reboot. Restart open apps if they still show previous Build values.':'पहचान बिना रीबूट के लागू हुई। खुले ऐप पुराने Build मान दिखाएँ तो उन्हें पुनः शुरू करें।','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'लाइव पहचान लागू करना उपलब्ध नहीं है। इन Build/क्षेत्र प्रॉपर्टी बदलावों के लिए रीबूट आवश्यक है।','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'पहले से लागू Build/क्षेत्र पहचान बंद करने पर मूल प्रॉपर्टी लौटाने के लिए रीबूट आवश्यक हो सकता है।','No CleveresTricky logs found.':'CleveresTricky लॉग नहीं मिले।'},ar:{'Healthy':'سليم','Stale template, manual refresh needed':'قالب قديم، يلزم التحديث اليدوي','Backup source: {value}':'مصدر احتياطي: {value}','Cron Auto Identity':'هوية تلقائية مجدولة','Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.':'يجلب ويطبق هوية تلقائية جديدة كل 24 ساعة ما دامت Build Identity مفعلة.','Profile enabled':'تم تفعيل الملف الشخصي','Profile disabled':'تم تعطيل الملف الشخصي','Enabled':'مفعّل','Disabled':'معطّل','Auto Identity saved. Build Identity remains disabled.':'تم حفظ الهوية التلقائية. ستبقى Build Identity معطلة.','Identity applied without reboot. Restart open apps if they still show previous Build values.':'تم تطبيق الهوية دون إعادة تشغيل. أعد تشغيل التطبيقات المفتوحة إذا استمرت في عرض قيم Build القديمة.','Live Identity apply is unavailable. Reboot is required for these Build/region property changes.':'التطبيق المباشر للهوية غير متاح. تتطلب تغييرات خصائص Build/المنطقة هذه إعادة تشغيل.','Disabling an already applied Build/region identity may require a reboot to restore original properties.':'قد يتطلب تعطيل هوية Build/المنطقة المطبقة سابقًا إعادة تشغيل لاستعادة الخصائص الأصلية.','No CleveresTricky logs found.':'لم يتم العثور على سجلات CleveresTricky.'}};const REMOTE_STATUS_COPY={tr:{ok:'Tamam',auth:'API anahtarı eksik, geçersiz veya süresi dolmuş. Remote Server API kimlik bilgilerini güncelleyin.',access:'Erişim reddedildi veya API anahtarı geçici olarak yasaklandı. Sağlayıcı erişimini ya da yasak durumunu kontrol edin.',accessRetry:'API anahtarı geçici olarak yasaklandı. Kalan süre: {seconds} saniye.',rate:'Çok fazla istek gönderildi. Yeniden yenilemeden önce bekleyin.',rateRetry:'Çok fazla istek gönderildi. Tekrar denemeden önce {seconds} saniye bekleyin.',service:'Sunucu şu anda hizmet veremiyor veya uygun keybox yok.',serviceNoKeybox:'Sunucuda şu anda kriterlere uygun bir keybox bulunmuyor.',serviceUpgrade:'Keybox sınıflandırma güncellemesi sürüyor. Lütfen birazdan tekrar deneyin.'},'zh-CN':{ok:'正常',auth:'API 密钥缺失、无效或已过期。请更新 Remote Server API 凭据。',access:'访问被拒绝，或 API 密钥被临时封禁。请检查服务提供方的访问权限或封禁状态。',accessRetry:'API 密钥已被临时封禁。剩余时间：{seconds} 秒。',rate:'请求过多。请稍后再刷新。',rateRetry:'请求过多。请等待 {seconds} 秒后重试。',service:'Remote Server 当前不可用，或目前没有符合条件的 keybox。'},es:{ok:'Correcto',auth:'La clave API falta, no es válida o ha caducado. Actualiza las credenciales de la API del Remote Server.',access:'Acceso denegado o clave API bloqueada temporalmente. Comprueba el acceso del proveedor o el estado del bloqueo.',accessRetry:'La clave API está bloqueada temporalmente. Tiempo restante: {seconds} segundos.',rate:'Demasiadas solicitudes. Espera antes de actualizar de nuevo.',rateRetry:'Demasiadas solicitudes. Vuelve a intentarlo en {seconds} segundos.',service:'El Remote Server no está disponible o no hay ningún keybox apto en este momento.'},de:{ok:'OK',auth:'API-Schlüssel fehlt, ist ungültig oder abgelaufen. Aktualisiere die Remote-Server-API-Zugangsdaten.',access:'Zugriff verweigert oder API-Schlüssel vorübergehend gesperrt. Prüfe den Anbieterzugriff oder den Sperrstatus.',accessRetry:'API-Schlüssel ist vorübergehend gesperrt. Verbleibende Zeit: {seconds} Sekunden.',rate:'Zu viele Anfragen. Warte, bevor du erneut aktualisierst.',rateRetry:'Zu viele Anfragen. Versuche es in {seconds} Sekunden erneut.',service:'Remote Server ist nicht verfügbar oder derzeit ist keine geeignete Keybox verfügbar.'},ru:{ok:'ОК',auth:'Ключ API отсутствует, недействителен или истёк. Обновите учётные данные API Remote Server.',access:'Доступ запрещён или ключ API временно заблокирован. Проверьте доступ у провайдера или статус блокировки.',accessRetry:'Ключ API временно заблокирован. Осталось: {seconds} с.',rate:'Слишком много запросов. Подождите перед следующим обновлением.',rateRetry:'Слишком много запросов. Повторите попытку через {seconds} с.',service:'Remote Server недоступен или сейчас нет подходящего keybox.'},id:{ok:'Normal',auth:'Kunci API tidak ada, tidak valid, atau kedaluwarsa. Perbarui kredensial API Remote Server.',access:'Akses ditolak atau kunci API diblokir sementara. Periksa akses penyedia atau status blokir.',accessRetry:'Kunci API diblokir sementara. Sisa waktu: {seconds} detik.',rate:'Terlalu banyak permintaan. Tunggu sebelum menyegarkan lagi.',rateRetry:'Terlalu banyak permintaan. Coba lagi dalam {seconds} detik.',service:'Remote Server tidak tersedia atau saat ini tidak ada keybox yang memenuhi syarat.'},hi:{ok:'सामान्य',auth:'API कुंजी गायब, अमान्य या समाप्त हो चुकी है। Remote Server API क्रेडेंशियल अपडेट करें।',access:'पहुंच अस्वीकृत है या API कुंजी अस्थायी रूप से प्रतिबंधित है। प्रदाता पहुंच या प्रतिबंध स्थिति जांचें।',accessRetry:'API कुंजी अस्थायी रूप से प्रतिबंधित है। शेष समय: {seconds} सेकंड।',rate:'बहुत अधिक अनुरोध भेजे गए। दोबारा रीफ़्रेश करने से पहले प्रतीक्षा करें।',rateRetry:'बहुत अधिक अनुरोध भेजे गए। {seconds} सेकंड बाद फिर प्रयास करें।',service:'Remote Server उपलब्ध नहीं है या अभी कोई उपयुक्त keybox उपलब्ध नहीं है।'},ar:{ok:'سليم',auth:'مفتاح API مفقود أو غير صالح أو منتهي الصلاحية. حدّث بيانات اعتماد API لـ Remote Server.',access:'تم رفض الوصول أو حظر مفتاح API مؤقتًا. تحقق من وصول المزوّد أو حالة الحظر.',accessRetry:'تم حظر مفتاح API مؤقتًا. الوقت المتبقي: {seconds} ثانية.',rate:'تم إرسال طلبات كثيرة جدًا. انتظر قبل التحديث مرة أخرى.',rateRetry:'تم إرسال طلبات كثيرة جدًا. أعد المحاولة بعد {seconds} ثانية.',service:'Remote Server غير متاح أو لا يوجد حاليًا keybox مؤهل.'}};const remoteStatusPrefix=/^(AUTH_ERROR|ACCESS_DENIED|RATE_LIMITED|SERVICE_UNAVAILABLE):/;const remoteRetryAfter=/Retry after ([1-9][0-9]{0,9}) seconds\./;const maxRemoteRetryAfterSeconds=31*24*60*60;function normalizeLocale(value){if(typeof value!=='string'||!value)return null;const tag=value.toLowerCase().replace(/_/g,'-');if(tag==='zh'||tag.startsWith('zh-hans')||tag.startsWith('zh-cn')||tag.startsWith('zh-sg')){return'zh-CN';}for(const loc of supportedLocales){if(loc.toLowerCase()===tag)return loc;}const base=tag.split('-')[0];for(const loc of supportedLocales){if(loc.toLowerCase()===base)return loc;}return null;}function extensionLocale(){const active=global.CleveresI18n&&global.CleveresI18n.locale;const activeLocale=normalizeLocale(active);if(activeLocale)return activeLocale;try{const stored=normalizeLocale(global.localStorage&&global.localStorage.getItem(languageStorageKey));if(stored)return stored;const systemLocale=normalizeLocale(global.CleveresSystemLocale);if(systemLocale)return systemLocale;const cachedSystem=normalizeLocale(global.localStorage&&global.localStorage.getItem(systemLocaleStorageKey));if(cachedSystem)return cachedSystem;const browserLocale=normalizeLocale(global.navigator&&global.navigator.language);if(browserLocale)return browserLocale;return'en';}catch(_){return'en';}}function extensionText(source){const catalog=EXTENSION_COPY[extensionLocale()];return catalog&&typeof catalog[source]==='string'?catalog[source]:source;}function remoteStatusText(source){const raw=String(source==null?'':source).trim();if(raw==='OK'){const locale=extensionLocale();if(locale==='en')return'OK';const catalog=REMOTE_STATUS_COPY[locale];return(catalog&&catalog.ok)?catalog.ok:'OK';}const prefix=raw.match(remoteStatusPrefix);if(!prefix)return source;const locale=extensionLocale();if(locale==='en')return raw;const catalog=REMOTE_STATUS_COPY[locale];if(!catalog)return raw;let key;if(prefix[1]==='AUTH_ERROR')key='auth';else if(prefix[1]==='SERVICE_UNAVAILABLE'){if(/no eligible keybox/i.test(raw))key='serviceNoKeybox';else if(/upgrade in progress|classification/i.test(raw))key='serviceUpgrade';else key='service';}else{const retryMatch=raw.match(remoteRetryAfter);const retrySeconds=retryMatch?Number(retryMatch[1]):0;const hasSafeRetry=Number.isSafeInteger(retrySeconds)&&retrySeconds>=1&&retrySeconds<=maxRemoteRetryAfterSeconds;key=prefix[1]==='ACCESS_DENIED'?(hasSafeRetry?'accessRetry':'access'):(hasSafeRetry?'rateRetry':'rate');if(hasSafeRetry){let formatted=String(retrySeconds);try{formatted=new Intl.NumberFormat(locale).format(retrySeconds);}catch(_){}return`${prefix[1]}: ${catalog[key].replace('{seconds}', formatted)}`;}}return`${prefix[1]}: ${catalog[key]||catalog.service||raw}`;}function refreshRemoteServerStatusCopy(){const document=global.document;if(!document||typeof document.querySelectorAll!=='function')return;document.querySelectorAll('.status-badge').forEach(node=>{if(!node||!node.dataset)return;let source=String(node.dataset.ctRemoteStatusSource||'').trim();if(!source){const current=String(node.textContent||'').trim();if(!remoteStatusPrefix.test(current)&&current!=='OK')return;source=current;node.dataset.ctRemoteStatusSource=source;}node.textContent=remoteStatusText(source);});}function abortError(){return new DOMException('The request was aborted','AbortError');}function throwIfAborted(signal){if(signal&&signal.aborted)throw abortError();}function encodeBytes(bytes){let binary='';for(let offset=0;offset<bytes.length;offset+=0x8000){binary+=String.fromCharCode.apply(null,bytes.subarray(offset,Math.min(offset+0x8000,bytes.length)));}return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/g,'');}function decodeBytes(value){if(typeof value!=='string'||!/^[A-Za-z0-9_-]*$/.test(value))throw new Error('Invalid bridge payload');const padded=value.replace(/-/g,'+').replace(/_/g,'/')+'==='.slice((value.length+3)%4);const binary=atob(padded);const bytes=new Uint8Array(binary.length);for(let index=0;index<binary.length;index++)bytes[index]=binary.charCodeAt(index);return bytes;}function encodeText(value){return encodeBytes(new TextEncoder().encode(value));}function shellCommand(args,markSuccess=false){if(!args.every(value=>typeof value==='string'&&/^[A-Za-z0-9_-]+$/.test(value))){throw new Error('Invalid bridge argument');}const paths=modulePaths.map(path=>`'${path}'`).join(' ');const prefix=`CT_BRIDGE=''; for CT_PATH in ${paths}; do [ -x "$CT_PATH" ] && { CT_BRIDGE="$CT_PATH"; break; }; done; [ -n "$CT_BRIDGE" ] || { echo 'Native WebUI bridge is unavailable' >&2; exit 127; };`;const invocation=`"$CT_BRIDGE" ${args.map(value => `'${value}'`).join(' ')}`;if(!markSuccess)return`${prefix} exec ${invocation}`;return`${prefix} ${invocation}; CT_STATUS=$?; [ "$CT_STATUS" -eq 0 ] || exit "$CT_STATUS"; printf '\
${nativeSuccessMarker}\
'`;}function validateResponseEnvelope(envelope){if(!envelope||typeof envelope!=='object'||Array.isArray(envelope))throw new Error('Invalid response envelope');const keys=Object.keys(envelope);if(!keys.every(key=>responseFields.has(key))||envelope.version!==1||!Number.isInteger(envelope.status)||envelope.status<100||envelope.status>599)throw new Error('Invalid response envelope');if(typeof envelope.statusText!=='string'||envelope.statusText.length>256||/[\u0000-\u001F\u007F]/.test(envelope.statusText)||typeof envelope.mimeType!=='string'||envelope.mimeType.length<1||envelope.mimeType.length>256||/[\u0000-\u001F\u007F]/.test(envelope.mimeType))throw new Error('Invalid response metadata');if(!Number.isSafeInteger(envelope.size)||envelope.size<0||envelope.size>maxResponseBytes)throw new Error('Invalid response size');const hasBody=typeof envelope.body==='string';const hasDownload=typeof envelope.downloadId==='string';if(hasBody===hasDownload||(hasDownload&&!/^[0-9a-f]{32}$/.test(envelope.downloadId)))throw new Error('Invalid response payload');if(hasBody&&(envelope.body.length>maxEnvelopeChars||!/^[A-Za-z0-9_-]*$/.test(envelope.body)))throw new Error('Invalid response payload');return envelope;}function extractResponseEnvelope(value,depth=0){if(value===null||value===undefined||depth>4)return null;if(typeof value==='string'){const raw=value.trim();if(!raw||raw.length>maxEnvelopeChars)return null;try{return extractResponseEnvelope(JSON.parse(raw),depth+1);}catch(_){return null;}}if(typeof value!=='object'||Array.isArray(value))return null;try{return JSON.stringify(validateResponseEnvelope(value));}catch(_){}for(const key of['stdout','out','stderr','err','message','result','data','output']){if(key in value){const envelope=extractResponseEnvelope(value[key],depth+1);if(envelope)return envelope;}}return null;}function extractMarkedNativeOutput(value,depth=0,marker=nativeSuccessMarker){
    if(value===null||value===undefined||depth>4)return null;
    if(typeof value==='string'){
        if(!value.includes(marker))return null;
        const raw=value.trim();
        if(raw===marker)return '';
        if(raw.endsWith('\n'+marker))return raw.slice(0,-marker.length).trim();
        try{
            const parsed=JSON.parse(raw);
            if(parsed&&typeof parsed==='object')return extractMarkedNativeOutput(parsed,depth+1,marker);
        }catch(_){}
        return null;
    }
    if(typeof value!=='object'||Array.isArray(value))return null;
    for(const key of['stdout','out','stderr','err','message','result','data','output']){
        if(key in value){const output=extractMarkedNativeOutput(value[key],depth+1,marker);if(output!==null)return output;}
    }
    return null;
}function normalizeExecResult(values,expectEnvelope=false){if(expectEnvelope){for(const value of[values[1],values[0],values[2]]){const envelope=extractResponseEnvelope(value);if(envelope)return{errno:0,stdout:envelope,stderr:''};}}let errno=values[0];let stdout=values[1];let stderr=values[2];if(values.length===1&&errno&&typeof errno==='object'&&!Array.isArray(errno)){const result=errno;if('errno' in result||'stdout' in result||'stderr' in result||'code' in result||'out' in result||'err' in result){errno=result.errno??result.code??0;stdout=result.stdout??result.out??'';stderr=result.stderr??result.err??'';}else if(result.version===1&&Number.isInteger(result.status)){errno=0;stdout=JSON.stringify(result);stderr='';}else{errno=-1;stdout='';stderr='Unsupported native exec result';}}else if(values.length===1&&typeof errno==='string'){const raw=errno.trim();let parsed=null;try{parsed=JSON.parse(raw);}catch(_){}if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed)&&('errno' in parsed||'stdout' in parsed||'stderr' in parsed||'code' in parsed)){errno=parsed.errno??parsed.code??0;stdout=parsed.stdout??parsed.out??'';stderr=parsed.stderr??parsed.err??'';}else{errno=0;stdout=raw;stderr='';}}const numericErrno=Number(errno);return{errno:Number.isFinite(numericErrno)?numericErrno:-1,stdout:String(stdout??'').trim(),stderr:String(stderr??'').trim()};}async function executeAiCommand(command){
    if(typeof command!=='string'||!command.trim()||command.length>8192||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f\u061c\u200e\u200f\u2028-\u202e\u2066-\u206f\ufeff]/.test(command))throw new Error('Invalid command');
    const encoded=encodeBytes(new TextEncoder().encode(command)).replace(/-/g,'+').replace(/_/g,'/');
    const padded=encoded+'='.repeat((4-encoded.length%4)%4);
    // This entry point is called only by the AI permission controller.
    const script=`umask 077
CT_AI_OUT=$(mktemp /data/local/tmp/ct-ai.XXXXXXXXXX) || exit 1
CT_AI_STATUS_FILE=$(mktemp /data/local/tmp/ct-ai-status.XXXXXXXXXX) || { rm -f "$CT_AI_OUT"; exit 1; }
trap 'rm -f "$CT_AI_OUT" "$CT_AI_STATUS_FILE"' EXIT HUP INT TERM
CT_AI_COMMAND=$(printf '%s' '${padded}' | base64 -d) || exit 1
command -v timeout >/dev/null 2>&1 || exit 1
{ timeout 25 sh -c "$CT_AI_COMMAND" 2>&1; printf '%s' "$?" >"$CT_AI_STATUS_FILE"; } | { head -c 32768; cat >/dev/null; } >"$CT_AI_OUT"
CT_AI_STATUS=$(cat "$CT_AI_STATUS_FILE")
case "$CT_AI_STATUS" in ''|*[!0-9]*) exit 1 ;; esac
cat "$CT_AI_OUT"
printf '\\n[exit=%s]\\n' "$CT_AI_STATUS"`;
    return execHostCommand(script,30000);
}
function execHostCommand(command,timeoutMs=10000,authentication=false,emergencyReport=false){
    if(authInitialized&&!authentication)return requireAuth().then(()=>{
        const generation=authGeneration;
        return execHostCommand(command,timeoutMs,true).then(result=>{if(generation!==authGeneration)throw authLockedError();return result;});
    });
    if(!nativeApi||typeof nativeApi.exec!=='function')return Promise.reject(new Error('Open this page from the WebUI button (KernelSU, APatch, or Magisk Action via the WebUI host app)'));
    const boundedTimeout=Math.min(Math.max(Number(timeoutMs)||10000,1000),emergencyReport&&authentication?120000:30000);
    return new Promise((resolve,reject)=>{
        const callbackName=`ct_host_${Date.now()}_${callbackCounter++}`;
        // Some hosts misreport status/channels; this trailer belongs only to this command.
        const successMarker=`__CT_HOST_OK_${callbackName}__`;
        let settled=false;
        const timer=setTimeout(()=>{if(settled)return;settled=true;delete global[callbackName];reject(new Error('Host command timed out'));},boundedTimeout+2000);
        global[callbackName]=(...values)=>{
            if(settled)return;
            settled=true;clearTimeout(timer);delete global[callbackName];
            for(const value of[values[1],values[0],values[2],...values.slice(3)]){
                const output=extractMarkedNativeOutput(value,0,successMarker);
                if(output!==null){resolve(output);return;}
            }
            const result=normalizeExecResult(values,false);
            reject(new Error(result.stderr||result.stdout||`Host command failed with code ${result.errno}`));
        };
        // Keep explicit exit/exec inside the subshell; only its successful exit emits the trailer.
        const wrapped=`(\n${command}\n) && printf '\\n${successMarker}\\n'`;
        try{nativeApi.exec(wrapped,'{}',callbackName);}
        catch(error){if(settled)return;settled=true;clearTimeout(timer);delete global[callbackName];reject(error);}
    });
}// One on-demand, time-bounded read; no shell input comes from the WebUI.
const processResourceCommand=`LC_ALL=C /system/bin/toybox timeout 8 /system/bin/awk '
function clean(s) { gsub(/[|[:cntrl:]]/, "_", s); return substr(s,1,128) }
function relevant(name,    parts,n) {
  n=split(name,parts,"/"); name=tolower(parts[n]);
  return name=="cleverestricky" || name=="cleverestrickyd" || name=="cleverestricky_backend" ||
    name=="cleveres.tricky.cleverestech" || name=="keystore2";
}
function readstat(pid, out,    path,s,n) {
  path="/proc/" pid "/stat";
  if ((getline s < path) <= 0) { close(path); return 0 }
  close(path);
  if (!sub(/^.*\\) +/, "", s)) return 0;
  n=split(s,out,/ +/);
  return n>=20 && out[12] ~ /^[0-9]+$/ && out[13] ~ /^[0-9]+$/ && out[20] ~ /^[0-9]+$/;
}
function process(pid,    path,s,v,a,uid,state,name,threads,rss,before,after,lines,ticks,cmdline,cmd,zero,cut) {
  if (!readstat(pid,before)) return 0;
  path="/proc/" pid "/status"; uid="";state="";name="";threads="";rss="-";lines=0;
  while ((getline s < path)>0) {
    if (++lines>128) { close(path); return 0 }
    v=s; sub(/^[^:]*:[[:space:]]*/,"",v);
    if (s ~ /^Name:/) name=clean(v);
    else if (s ~ /^Uid:/) { split(v,a,/[[:space:]]+/); uid=a[1] }
    else if (s ~ /^State:/) state=substr(v,1,1);
    else if (s ~ /^Threads:/) { split(v,a,/[[:space:]]+/); threads=a[1] }
    else if (s ~ /^VmRSS:/) { split(v,a,/[[:space:]]+/); if(a[1] ~ /^[0-9]+$/) rss=a[1] }
  }
  close(path);
  # Read only argv[0], capped before parsing; arguments are never returned.
  cmd="/system/bin/toybox head -c 256 /proc/" pid "/cmdline 2>/dev/null";
  if ((cmd | getline cmdline)>0) {
    zero=sprintf("%c",0);
    if (length(zero)>0 && (cut=index(cmdline,zero))>0) cmdline=substr(cmdline,1,cut-1);
    if (length(cmdline)>0) name=clean(cmdline);
  }
  close(cmd);
  if (!readstat(pid,after) || before[20]!=after[20] || uid !~ /^[0-9]+$/ ||
      state !~ /^[A-Za-z]$/ || threads !~ /^[0-9]+$/ || name=="") return 0;
  if (!relevant(name)) return 0;
  ticks=before[12]+before[13];
  if (ticks<0 || ticks>9007199254740991) return 0;
  printf "P|%s|%s|%s|%s|%s|%.0f|%s\\n",pid,uid,state,threads,rss,ticks,name;
  return 1;
}
BEGIN {
  print "CTRES1";
  if ((getline kernel < "/proc/sys/kernel/osrelease")>0) print "K|" clean(kernel);
  close("/proc/sys/kernel/osrelease");
  count=0;
  while ((getline line < "/proc/meminfo")>0 && count++<128) {
    split(line,parts,/[[:space:]]+/); key=parts[1]; sub(/:$/,"",key);
    if ((key=="MemTotal" || key=="MemAvailable" || key=="SwapTotal" || key=="SwapFree" || key=="Slab") && parts[2] ~ /^[0-9]+$/)
      print "M|" key "|" parts[2];
  }
  close("/proc/meminfo");
  cmd="/system/bin/toybox ps -A -n -w -k -RSS -o PID,NAME 2>/dev/null && /system/bin/toybox echo CT_PS_DONE"; seen=0; skipped=0; complete=0;
  while ((cmd | getline entry)>0) {
    gsub(/^[[:space:]]+|[[:space:]]+$/,"",entry);
    if (entry=="CT_PS_DONE") { complete=1; continue }
    split(entry,fields,/[[:space:]]+/); pid=fields[1];
    if (pid !~ /^[0-9]+$/ || pid==0 || !relevant(fields[2])) continue;
    seen++;
    if (seen<=40 && !process(pid)) skipped++;
  }
  code=close(cmd);
  if (!complete || code!=0) exit 1;
  print "E|" seen "|" skipped;
}'`;
let processResourceInFlight=null;
function parseProcessResources(raw){
  if(typeof raw!=='string'||raw.length>16384)throw new Error('Invalid process snapshot');
  const lines=raw.trim().split('\n');
  if(lines.shift()!=='CTRES1')throw new Error('Invalid process snapshot');
  const result={kernel:null,memory:{},processes:[],seen:null,skipped:null};
  const memoryKeys=new Set(['MemTotal','MemAvailable','SwapTotal','SwapFree','Slab']);
  const integer=value=>/^[0-9]{1,15}$/.test(value)&&Number.isSafeInteger(Number(value))?Number(value):null;
  for(const line of lines){
    const fields=line.split('|');
    if(fields[0]==='K'&&fields.length===2&&fields[1].length<=128)result.kernel=fields[1];
    else if(fields[0]==='M'&&fields.length===3&&memoryKeys.has(fields[1])){
      const value=integer(fields[2]);if(value===null||Object.prototype.hasOwnProperty.call(result.memory,fields[1]))throw new Error('Invalid memory snapshot');result.memory[fields[1]]=value;
    }else if(fields[0]==='P'&&fields.length===8){
      const pid=integer(fields[1]),uid=integer(fields[2]),threads=integer(fields[4]),rss=fields[5]==='-'?null:integer(fields[5]),ticks=integer(fields[6]);
      if(!pid||uid===null||threads===null||ticks===null||(fields[5]!=='-'&&rss===null)||!/^[A-Za-z]$/.test(fields[3])||!fields[7]||fields[7].length>128||result.processes.length>=40)throw new Error('Invalid process snapshot');
      result.processes.push({pid,uid,state:fields[3],threads,rss_kb:rss,cpu_ticks:ticks,name:fields[7]});
    }else if(fields[0]==='E'&&fields.length===3&&result.seen===null){
      result.seen=integer(fields[1]);result.skipped=integer(fields[2]);
    }else throw new Error('Invalid process snapshot');
  }
  if(result.seen===null||result.skipped===null||result.skipped>40||result.seen<result.processes.length+result.skipped)throw new Error('Incomplete process snapshot');
  return result;
}
function processResourcesForCaller(promise,signal){
  if(!signal)return promise;
  if(signal.aborted)return Promise.reject(abortError());
  return new Promise((resolve,reject)=>{
    const aborted=()=>{signal.removeEventListener('abort',aborted);reject(abortError());};
    signal.addEventListener('abort',aborted,{once:true});
    promise.then(value=>{signal.removeEventListener('abort',aborted);resolve(value);},error=>{signal.removeEventListener('abort',aborted);reject(error);});
    if(signal.aborted)aborted();
  });
}
function getProcessResources({fresh=false,signal=null}={}){
  if(signal&&signal.aborted)return Promise.reject(abortError());
  if(processResourceInFlight){
    if(!fresh)return processResourcesForCaller(processResourceInFlight,signal);
    // A fresh view waits for the retired host command without publishing its result.
    const queued=processResourceInFlight.then(()=>{},()=>{}).then(()=>{
      throwIfAborted(signal);
      return getProcessResources({signal});
    });
    return processResourcesForCaller(queued,signal);
  }
  const pending=execHostCommand(processResourceCommand,10000).then(parseProcessResources);
  processResourceInFlight=pending;
  pending.then(()=>{if(processResourceInFlight===pending)processResourceInFlight=null;},()=>{if(processResourceInFlight===pending)processResourceInFlight=null;});
  return processResourcesForCaller(pending,signal);
}
function execNative(args,timeoutMs,expectEnvelope=false,signal=null){if(!nativeApi||typeof nativeApi.exec!=='function')return Promise.reject(new Error('Open this page from the WebUI button (KernelSU, APatch, or Magisk Action via the WebUI host app)'));try{throwIfAborted(signal);}catch(error){return Promise.reject(error);}const boundedTimeout=Math.min(Math.max(Number(timeoutMs)||60000,1000),125000);return new Promise((resolve,reject)=>{const callbackName=`ct_exec_${Date.now()}_${callbackCounter++}`;let settled=false;let abortHandler=null;const cleanup=()=>{clearTimeout(timer);delete global[callbackName];if(signal&&abortHandler)signal.removeEventListener('abort',abortHandler);};const timer=setTimeout(()=>{if(settled)return;settled=true;cleanup();reject(new Error('Native bridge timed out'));},boundedTimeout+5000);global[callbackName]=(...values)=>{if(settled)return;settled=true;cleanup();if(!expectEnvelope){for(const value of[values[1],values[0],values[2],...values.slice(3)]){const output=extractMarkedNativeOutput(value);if(output!==null){resolve(output);return;}}}let result;try{result=normalizeExecResult(values,expectEnvelope);}catch(error){reject(error);return;}if(result.errno===0)resolve(result.stdout);else reject(new Error(result.stderr||result.stdout||`Native bridge failed with code ${result.errno}`));};if(signal){abortHandler=()=>{if(settled)return;settled=true;cleanup();reject(abortError());};signal.addEventListener('abort',abortHandler,{once:true});if(signal.aborted){abortHandler();return;}}try{nativeApi.exec(shellCommand(args,!expectEnvelope),'{}',callbackName);}catch(error){if(settled)return;settled=true;cleanup();reject(error);}});}async function openExternalUrl(url){if(typeof url!=='string')throw new Error('Invalid external URL');const trimmed=url.trim();if(trimmed.length<1||trimmed.length>2048||/['"\\`$;\s\u0000-\u001F\u007F]/.test(trimmed))throw new Error('Invalid external URL');if(!/^https?:\/\/[A-Za-z0-9\-._~:/?#[\]@!$&*+,;=%]+$/i.test(trimmed)&&!/^tg:\/\/[A-Za-z0-9\-._~:/?#[\]@!$&*+,;=%]+$/i.test(trimmed))throw new Error('Unsupported external URL');let command;const tgMatch=trimmed.match(/^https?:\/\/(?:t\.me|telegram\.me)\/([A-Za-z0-9_]+)(?:\/([0-9]+))?\/?$/i);if(tgMatch){const domain=tgMatch[1];const post=tgMatch[2];const tgUri=post?`tg://resolve?domain=${domain}&post=${post}`:`tg://resolve?domain=${domain}`;command=`/system/bin/am start --user current -a android.intent.action.VIEW -d '${tgUri}' >/dev/null 2>&1 || /system/bin/am start -a android.intent.action.VIEW -d '${tgUri}' >/dev/null 2>&1 || /system/bin/am start --user current -a android.intent.action.VIEW -d '${trimmed}' >/dev/null 2>&1 || /system/bin/am start -a android.intent.action.VIEW -d '${trimmed}' >/dev/null 2>&1`;}else{command=`/system/bin/am start --user current -a android.intent.action.VIEW -d '${trimmed}' >/dev/null 2>&1 || /system/bin/am start -a android.intent.action.VIEW -d '${trimmed}' >/dev/null 2>&1`;}await execHostCommand(command,12000,true);return true;}async function openCommunity(){return openExternalUrl(communityUrl);}/** Report configured provider availability; query failures remain unknown. */
async function getZygiskStatus(){const command=`( query_failed=0; if command -v magisk >/dev/null 2>&1; then setting=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null) || query_failed=1; case "$setting" in 1|value=1) echo available; exit 0;; esac; fi; for root in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules; do [ -d "$root" ] && [ ! -L "$root" ] || continue; for id in zygisksu zygisk_next zygisknext re_zygisk rezygisk neozygisk neo_zygisk; do provider="$root/$id"; if [ -d "$provider" ] && [ ! -L "$provider" ] && [ ! -e "$provider/disable" ] && [ ! -L "$provider/disable" ] && [ ! -e "$provider/remove" ] && [ ! -L "$provider/remove" ]; then echo available; exit 0; fi; done; done; if [ "$query_failed" = 1 ]; then echo unknown; else echo missing; fi )`;const result=await execHostCommand(command,7000);return result==='available'?true:result==='missing'?false:null;}async function openKeyboxHub(){return openExternalUrl(keyboxHubUrl);}async function getRuntimeMarker(setting){const response=await nativeFetch('/api/config');if(!response.ok)throw new Error(await response.text());const config=await response.json();return config&&config[setting]===true;}async function setRuntimeMarker(setting,enabled){const body=new URLSearchParams();body.set('setting',setting);body.set('value',String(Boolean(enabled)));const response=await nativeFetch('/api/toggle',{method:'POST',body});if(!response.ok)throw new Error(await response.text());return Boolean(enabled);}function getDebugLogging(){return getRuntimeMarker('debug_logging');}function setDebugLogging(enabled){return setRuntimeMarker('debug_logging',enabled);}async function createStage(kind,timeoutMs,signal=null){const id=await execNative(['stage-create',kind],timeoutMs,false,signal);if(!/^[0-9a-f]{32}$/.test(id))throw new Error('Invalid staging identifier');return id;}async function dropStage(kind,id){if(!/^[0-9a-f]{32}$/.test(id))return;try{await execNative(['stage-drop',kind,id],10000);}catch(_){}}async function appendStage(kind,id,bytes,timeoutMs,signal=null){for(let offset=0;offset<bytes.length;offset+=chunkBytes){throwIfAborted(signal);const chunk=bytes.subarray(offset,Math.min(offset+chunkBytes,bytes.length));await execNative(['stage-append',kind,id,encodeBytes(chunk)],timeoutMs,false,signal);}}async function stageBlob(kind,blob,timeoutMs,signal=null){const limit=kind==='export'?maxResponseBytes:maxUploadBytes;if(!['upload','export'].includes(kind)||!(blob instanceof Blob)||blob.size<=0||blob.size>limit)throw new Error('File size is outside the supported range');const id=await createStage(kind,timeoutMs,signal);try{for(let offset=0;offset<blob.size;offset+=chunkBytes){throwIfAborted(signal);const bytes=new Uint8Array(await blob.slice(offset,Math.min(offset+chunkBytes,blob.size)).arrayBuffer());await execNative(['stage-append',kind,id,encodeBytes(bytes)],timeoutMs,false,signal);}return id;}catch(error){await dropStage(kind,id);throw error;}}async function readDownload(id,size,timeoutMs,signal=null){if(!/^[0-9a-f]{32}$/.test(id)||!Number.isSafeInteger(size)||size<0||size>maxResponseBytes){throw new Error('Invalid staged response');}const output=new Uint8Array(size);for(let offset=0;offset<size;offset+=chunkBytes){throwIfAborted(signal);const length=Math.min(chunkBytes,size-offset);const encoded=await execNative(['stage-read','download',id,String(offset),String(length)],timeoutMs,false,signal);const chunk=decodeBytes(encoded);if(chunk.length!==length)throw new Error('Incomplete staged response');output.set(chunk,offset);}return output;}async function materializeDownload(reference,size,timeoutMs,signal=null){if(reference.bytes)return reference.bytes;if(reference.error)throw reference.error;if(reference.promise)return reference.promise;const id=reference.id;if(!id)throw new Error('Staged response is unavailable');reference.promise=(async()=>{try{const bytes=await readDownload(id,size,timeoutMs,signal);reference.bytes=bytes;return bytes;}catch(error){reference.error=error;throw error;}finally{if(reference.id===id)reference.id=null;await dropStage('download',id);}})();return reference.promise;}class NativeResponse{constructor(envelope,timeoutMs,signal=null){this.status=Number(envelope.status);this.statusText=String(envelope.statusText||'');this.ok=this.status>=200&&this.status<300;this.type='basic';this.url='';this.redirected=false;this.headers=new Headers({'content-type':String(envelope.mimeType||'application/octet-stream')});this.bodyUsed=false;this.bodyEncoded=typeof envelope.body==='string'?envelope.body:null;this.downloadId=typeof envelope.downloadId==='string'?envelope.downloadId:null;this.downloadRef=this.downloadId?{id:this.downloadId,promise:null,bytes:null,error:null,shared:false}:null;this.size=Number(envelope.size||0);this.timeoutMs=timeoutMs;this.signal=signal;this.cachedBytes=null;}async consumeBytes(){throwIfAborted(this.signal);if(this.bodyUsed)throw new TypeError('Response body has already been consumed');this.bodyUsed=true;if(this.cachedBytes)return this.cachedBytes;if(this.bodyEncoded!==null){this.cachedBytes=decodeBytes(this.bodyEncoded);this.bodyEncoded=null;}else if(this.downloadRef){const reference=this.downloadRef;try{const bytes=await materializeDownload(reference,this.size,this.timeoutMs,this.signal);this.cachedBytes=bytes.slice();}finally{this.downloadId=null;this.downloadRef=null;}}else{this.cachedBytes=new Uint8Array(0);}return this.cachedBytes;}async bytes(){return this.consumeBytes();}async text(){return new TextDecoder('utf-8',{fatal:false}).decode(await this.consumeBytes());}async json(){return JSON.parse(await this.text());}async blob(){return new Blob([await this.consumeBytes()],{type:this.headers.get('content-type')||'application/octet-stream'});}async arrayBuffer(){const bytes=await this.consumeBytes();return bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);}clone(){if(this.bodyUsed)throw new TypeError('Cannot clone a consumed response');const copy=Object.create(NativeResponse.prototype);Object.assign(copy,this);copy.headers=new Headers(this.headers);copy.bodyUsed=false;copy.cachedBytes=this.cachedBytes?this.cachedBytes.slice():null;if(copy.downloadRef)copy.downloadRef.shared=true;return copy;}}function addParameter(parameters,key,value){if(typeof key!=='string'||typeof value!=='string')throw new Error('Unsupported request parameter');if(key.length>128||value.length>1024*1024)throw new Error('Request parameter is too large');if(!parameters[key])parameters[key]=[];if(parameters[key].length>=32)throw new Error('Too many request values');parameters[key].push(value);}async function prepareRequest(url,options,timeoutMs,signal=null){throwIfAborted(signal);const parsed=new URL(String(url),'https://native.cleverestricky.invalid');if(parsed.origin!=='https://native.cleverestricky.invalid'||!parsed.pathname.startsWith('/api/'))throw new Error('Unsupported WebUI request path');const parameters=Object.create(null);parsed.searchParams.forEach((value,key)=>addParameter(parameters,key,value));let uploadId=null;let uploadField=null;try{const body=options.body;if(body instanceof URLSearchParams){body.forEach((value,key)=>addParameter(parameters,key,value));}else if(body instanceof FormData){for(const[key,value]of body.entries()){if(value instanceof File){if(uploadId)throw new Error('Only one file can be uploaded at a time');uploadId=await stageBlob('upload',value,timeoutMs,signal);uploadField=key;if(!parameters.filename&&value.name)addParameter(parameters,'filename',value.name);}else{addParameter(parameters,key,String(value));}}}else if(body!==undefined&&body!==null){throw new Error('Unsupported request body');}}catch(error){if(uploadId)await dropStage('upload',uploadId);throw error;}return{version:1,method:String(options.method||'GET').toUpperCase(),path:parsed.pathname,parameters,uploadId,uploadField};}async function callRequest(request,timeoutMs,signal=null){throwIfAborted(signal);const bytes=new TextEncoder().encode(JSON.stringify(request));if(bytes.length>1024*1024||request.path==='/api/ai/start'&&bytes.length>chunkBytes)throw new Error('Request is too large');let raw;if(bytes.length<=chunkBytes){raw=await execNative(['call',encodeBytes(bytes),String(timeoutMs)],timeoutMs,true,signal);}else{const stageId=await createStage('request',timeoutMs,signal);try{await appendStage('request',stageId,bytes,timeoutMs,signal);raw=await execNative(['call-file',stageId,String(timeoutMs)],timeoutMs,true,signal);}catch(error){await dropStage('request',stageId);throw error;}}let envelope;try{envelope=JSON.parse(raw);}catch(_){throw new Error('Invalid response from native bridge');}validateResponseEnvelope(envelope);const hasBody=typeof envelope.body==='string';const response=new NativeResponse(envelope,timeoutMs,signal);if(hasBody){const decoded=decodeBytes(envelope.body);if(decoded.length!==envelope.size)throw new Error('Incomplete inline response');response.cachedBytes=decoded;response.bodyEncoded=null;}return response;}function canonicalProfileValue(value){if(Array.isArray(value))return value.map(canonicalProfileValue);if(!value||typeof value!=='object')return value;const result={};Object.keys(value).sort().forEach(key=>{result[key]=canonicalProfileValue(value[key]);});return result;}function profileSignature(profile){if(!profile||typeof profile!=='object')return'';return JSON.stringify(canonicalProfileValue({applications:Array.isArray(profile.applications)?profile.applications.map(String).sort():[],template:profile.template||null,keybox:profile.keybox||null,privacy:profile.privacy||'inherit',features:profile.features&&typeof profile.features==='object'?profile.features:{},securityPatch:profile.securityPatch&&typeof profile.securityPatch==='object'?profile.securityPatch:{},rkpPassthrough:typeof profile.rkpPassthrough==='boolean'?profile.rkpPassthrough:null,drmPassthrough:typeof profile.drmPassthrough==='boolean'?profile.drmPassthrough:null}));}function rememberPolicyState(state){if(!state||typeof state!=='object'||!Array.isArray(state.profiles))return;latestPolicyState=state;profileEnabledByName.clear();profileEnabledBySignature.clear();state.profiles.forEach(profile=>{const enabled=!profile||typeof profile.enabled!=='boolean'?true:profile.enabled;const name=profile&&typeof profile.name==='string'?profile.name.trim().toLowerCase():'';if(name)profileEnabledByName.set(name,enabled);const signature=profileSignature(profile);if(!signature)return;if(!profileEnabledBySignature.has(signature))profileEnabledBySignature.set(signature,enabled);else if(profileEnabledBySignature.get(signature)!==enabled)profileEnabledBySignature.set(signature,null);});}function preparePolicySaveOptions(url,options){const parsed=new URL(String(url),'https://native.cleverestricky.invalid');const method=String(options.method||'GET').toUpperCase();if(parsed.pathname!=='/api/policy_state'||method!=='POST'||!(options.body instanceof URLSearchParams)){return options;}const encoded=options.body.get('data');if(typeof encoded!=='string'||encoded.length>1024*1024)return options;let state;try{state=JSON.parse(encoded);}catch(_){return options;}if(!state||typeof state!=='object'||!Array.isArray(state.profiles))return options;state.profiles.forEach(profile=>{if(!profile||typeof profile!=='object'||typeof profile.enabled==='boolean')return;const name=typeof profile.name==='string'?profile.name.trim().toLowerCase():'';const signature=profileSignature(profile);if(name&&profileEnabledByName.has(name)){profile.enabled=profileEnabledByName.get(name);}else if(signature&&typeof profileEnabledBySignature.get(signature)==='boolean'){profile.enabled=profileEnabledBySignature.get(signature);}else{profile.enabled=true;}});if(state.activeProfile){const activeName=String(state.activeProfile).trim().toLowerCase();const active=state.profiles.find(profile=>profile&&String(profile.name||'').trim().toLowerCase()===activeName);if(active&&active.enabled===false)state.activeProfile=null;}const body=new URLSearchParams(options.body.toString());body.set('data',JSON.stringify(state));return Object.assign({},options,{body});}async function rememberPolicyResponse(url,response){if(!response||!response.ok)return;const parsed=new URL(String(url),'https://native.cleverestricky.invalid');if(!policyResponsePaths.has(parsed.pathname))return;try{const state=await response.clone().json();rememberPolicyState(state);}catch(_){}}
// Authentication is initialized by the canonical page before its first data request.
// Capabilities remain in this closure; no localStorage, cookie or background heartbeat.
let authInitialized=false,authStatusKnown=false,authEnabled=false,authLocked=false,authChecking=false,authBusy=false;
let authError=null,authToken=null,authGeneration=0,authTimer=null,authAttempt=null;
let authReady=Promise.resolve(),authRelease=null;
let resetPhase=null,resetDeadline=0,resetTimer=null,resetError=null,resetRestarting=false;
function resetNow(){return global.performance&&typeof global.performance.now==='function'?global.performance.now():Date.now();}
function factoryResetState(){return Object.freeze({phase:resetPhase,seconds:resetPhase==='warning'?Math.max(0,Math.ceil((resetDeadline-resetNow())/1000)):0,error:resetError,restarting:resetRestarting});}
function cancelFactoryReset(){
    if(resetPhase!=='warning')return;
    if(resetTimer!==null){clearTimeout(resetTimer);resetTimer=null;}
    resetPhase=null;resetDeadline=0;resetError=null;emitAuth();
}
function beginFactoryReset(){
    if(authBusy||authChecking||resetPhase||(global.document&&global.document.hidden))throw new Error('Reset unavailable');
    resetPhase='warning';resetDeadline=resetNow()+5000;resetError=null;
    const tick=()=>{resetTimer=null;if(resetPhase!=='warning')return;emitAuth();if(resetNow()<resetDeadline)resetTimer=setTimeout(tick,250);};
    emitAuth();resetTimer=setTimeout(tick,250);return factoryResetState();
}
async function restartAfterFactoryReset(){
    if(resetRestarting||!['scheduled','unknown'].includes(resetPhase)||(global.document&&global.document.hidden))throw new Error('Reset unavailable');
    resetRestarting=true;resetError=null;emitAuth();
    try{await execHostCommand('reboot',10000,true);}
    catch(_){resetError='restart_failed';}
    finally{resetRestarting=false;emitAuth();}
}
async function factoryReset(){
    if(resetRestarting||!['warning','unknown'].includes(resetPhase)||authBusy||authChecking||(global.document&&global.document.hidden)||resetPhase==='warning'&&resetNow()<resetDeadline)throw new Error('Reset not confirmed');
    if(resetTimer!==null){clearTimeout(resetTimer);resetTimer=null;}
    resetPhase='resetting';resetError=null;authLocked=true;blockAuth();emitAuth();
    try{
        const result=await execHostCommand("CT_RESET_SCRIPT=''; for CT_RESET_DIR in /data/adb/modules/cleverestricky /data/adb/ksu/modules/cleverestricky /data/adb/ap/modules/cleverestricky; do if [ ! -L \"$CT_RESET_DIR\" ] && [ ! -L \"$CT_RESET_DIR/post-fs-data.sh\" ] && [ -f \"$CT_RESET_DIR/post-fs-data.sh\" ]; then CT_RESET_SCRIPT=\"$CT_RESET_DIR/post-fs-data.sh\"; break; fi; done; [ -n \"$CT_RESET_SCRIPT\" ] || exit 1; sh \"$CT_RESET_SCRIPT\" --request-factory-reset",60000,true);
        if(result.trim()!=='factory-reset-ready')throw new Error('Reset preparation unconfirmed');
        resetPhase='scheduled';emitAuth();await restartAfterFactoryReset();
    }catch(_){resetPhase='unknown';resetError='reset_failed';emitAuth();}
    return factoryResetState();
}
function authState(){return Object.freeze({enabled:authEnabled,locked:authLocked,checking:authChecking,busy:authBusy,error:authError});}
function emitAuth(){
    const doc=global.document;
    if(doc&&doc.documentElement)doc.documentElement.dataset.ctAuthLocked=authLocked||authChecking?'1':'0';
    if(typeof global.dispatchEvent==='function'&&typeof global.CustomEvent==='function')global.dispatchEvent(new global.CustomEvent('ct_webui_auth',{detail:authState()}));
}
function blockAuth(){if(!authRelease)authReady=new Promise(resolve=>{authRelease=resolve;});}
function releaseAuth(){if(authRelease){const release=authRelease;authRelease=null;release();}}
function authLockedError(){return new DOMException('WebUI locked','AbortError');}
async function requireAuth(signal=null){
    throwIfAborted(signal);
    if(!authInitialized)return;
    if(authLocked&&!authChecking&&!authBusy)throw authLockedError();
    if(signal){
        await new Promise((resolve,reject)=>{
            const abort=()=>{signal.removeEventListener('abort',abort);reject(new DOMException('The operation was aborted','AbortError'));};
            signal.addEventListener('abort',abort,{once:true});
            authReady.then(()=>{signal.removeEventListener('abort',abort);resolve();});
            if(signal.aborted)abort();
        });
    }else await authReady;
    throwIfAborted(signal);
    if(authLocked||authChecking)throw authLockedError();
}
function isNativeRuntimeUnreachable(error){
    const message=String(error&&error.message||'').trim();
    return message==='Android adapter is unavailable'||message.startsWith('Native WebUI service is unavailable:')||message.startsWith('Native WebUI bridge is unavailable')||message.startsWith('Native bridge')||message.startsWith('Configuration directory is unavailable:')||message.includes('Broken pipe')||Boolean(error&&error.code==='runtime_unavailable');
}
async function inspectOfflineEnvironment(){
    // Read-only, bounded system hints. Available only while the authenticated runtime is unreachable.
    if(!authInitialized||authChecking||!authLocked||authEnabled||authError!=='runtime_unavailable')
        throw new Error('Offline diagnostics unavailable');
    const command=[
        "ct_kernel=$(uname -r 2>/dev/null | tr -cd 'A-Za-z0-9._+-' | cut -c1-80); [ -n \"$ct_kernel\" ] || ct_kernel=unknown",
        "ct_sdk=$(getprop ro.build.version.sdk 2>/dev/null | tr -cd '0-9' | cut -c1-2); [ -n \"$ct_sdk\" ] || ct_sdk=0",
        "ct_pidfd=unknown; for ct_root in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules; do ct_dir=\"$ct_root/cleverestricky\"; if [ -d \"$ct_dir\" ] && [ ! -L \"$ct_dir\" ] && [ -f \"$ct_dir/cleverestrickyd\" ] && [ -x \"$ct_dir/cleverestrickyd\" ] && [ ! -L \"$ct_dir/cleverestrickyd\" ]; then if CLEVERES_TRICKY_PIDFD_MODE=support \"$ct_dir/cleverestrickyd\" \"$ct_dir\" >/dev/null 2>&1; then ct_pidfd=yes; else ct_probe_status=$?; [ \"$ct_probe_status\" -ne 2 ] || ct_pidfd=no; fi; break; fi; done",
        "ct_oneplus=no; { getprop ro.product.manufacturer; getprop ro.product.brand; } 2>/dev/null | grep -Eiq '^oneplus$' && ct_oneplus=yes",
        "ct_tee=no; if { logcat -d -t 1200 -v brief 2>/dev/null | tail -c 262144; if [ -f /data/adb/cleverestricky/native_runtime.log ] && [ ! -L /data/adb/cleverestricky/native_runtime.log ]; then tail -c 65536 /data/adb/cleverestricky/native_runtime.log 2>/dev/null; fi; } | grep -Eiq 'SECURE_HW_COMMUNICATION_FAILED|secure hardware communication failed|((KeyMint|StrongBox|TEE|keymaster).*(-49|error[[:space:]]+49)([^0-9]|$))'; then ct_tee=yes; fi",
        "printf 'CTDIAG1|%s|%s|%s|%s|%s\\n' \"$ct_kernel\" \"$ct_pidfd\" \"$ct_tee\" \"$ct_oneplus\" \"$ct_sdk\""
    ].join('\n');
    const reply=(await execHostCommand(command,12000,true)).trim();
    const match=/^CTDIAG1\|([A-Za-z0-9._+-]{1,80})\|(yes|no|unknown)\|(yes|no)\|(yes|no)\|([0-9]{1,2})$/.exec(reply);
    if(!match)throw new Error('Invalid offline diagnostic response');
    return Object.freeze({kernel:match[1],pidfd:match[2],tee:match[3]==='yes',oneplus:match[4]==='yes',sdk:Number(match[5])});
}
async function generateEmergencyReport(){
    // Diagnostics are an explicit, user-triggered exception when native auth status is unknowable.
    // Never grant a session token or unlock protected WebUI APIs from this path.
    if(!authInitialized||authChecking||authBusy||!authLocked||authEnabled||authError!=='runtime_unavailable'||resetPhase)
        throw new Error('Emergency report is unavailable');
    const command="CT_REPORT_DIR=''; for CT_ROOT in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules; do CT_CANDIDATE=\"$CT_ROOT/cleverestricky\"; if [ -d \"$CT_CANDIDATE\" ] && [ ! -L \"$CT_CANDIDATE\" ] && [ -f \"$CT_CANDIDATE/emergency-report.sh\" ] && [ ! -L \"$CT_CANDIDATE/emergency-report.sh\" ]; then CT_REPORT_DIR=\"$CT_CANDIDATE\"; break; fi; done; [ -n \"$CT_REPORT_DIR\" ] || exit 1; CLEVERES_TRICKY_REPORT_MODDIR=\"$CT_REPORT_DIR\" FROM_WEBUI=1 /system/bin/sh \"$CT_REPORT_DIR/emergency-report.sh\"";
    const path=(await execHostCommand(command,120000,true,true)).trim();
    const destinations=['/data/user_de/0/com.android.shell/files/bugreports/','/storage/emulated/0/Download/','/data/local/tmp/'];
    const destination=destinations.find(prefix=>path.startsWith(prefix));
    if(!destination||
       !/^CleveresTricky-bugreport-[0-9]{8}-[0-9]{6}-[0-9a-f]{32}\.tar\.gz$/.test(path.slice(destination.length)))
        throw new Error('Invalid emergency report destination');
    return path;
}
async function authRequest(path,values={},token=null,retryStartup=false){
    const parameters={};Object.entries(values).forEach(([key,value])=>{parameters[key]=[String(value)];});
    const request={version:1,method:path==='status'?'GET':'POST',path:'/api/webui-auth/'+path,parameters};
    if(token)request.authToken=token;
    const startupRetryDelaysMs=[250,500,1000,2000,4000,8000,16000];
    const canRetryStartup=retryStartup&&path==='status';
    for(let attempt=0;;attempt++){
        let response;
        try{response=await callRequest(request,15000);}
        catch(error){
            const message=String(error&&error.message||'').trim();
            const transient=isNativeRuntimeUnreachable(error);
            if(!canRetryStartup||!transient||attempt>=startupRetryDelaysMs.length)throw error;
        }
        if(response){
            if(response.ok)return response.json();
            if(!canRetryStartup||response.status!==503)throw new Error('Device authentication unavailable');
            let message='';
            try{message=(await response.text()).trim();}catch(_){throw new Error('Device authentication unavailable');}
            if(message!=='Native WebUI runtime is starting; retry shortly')throw new Error('Device authentication unavailable');
            if(attempt>=startupRetryDelaysMs.length)throw Object.assign(new Error('Native WebUI runtime startup timed out'),{code:'runtime_unavailable'});
        }
        await new Promise(resolve=>setTimeout(resolve,startupRetryDelaysMs[attempt]));
    }
}
function validateAuthStatus(result){
    if(typeof result.enabled!=='boolean'||typeof result.available!=='boolean')throw new Error('Invalid authentication state');
    return result;
}
async function readAuthStatus(retryStartup=false){
    try{const result=validateAuthStatus(await authRequest('status',{},null,retryStartup));authStatusKnown=true;return result;}
    catch(error){authStatusKnown=false;throw error;}
}
function acceptAuth(result){
    validateAuthStatus(result);
    if(result.enabled&&(!result.available||!(/^[0-9a-f]{64}$/).test(result.authToken||'')))throw new Error('Device authentication unavailable');
    authStatusKnown=true;
    if(result.enabled&&global.document&&global.document.hidden){
        // Never release waiting data requests while the platform prompt still obscures the WebUI.
        authEnabled=true;authToken=result.authToken;authChecking=false;lockAuth();return;
    }
    authEnabled=result.enabled;authToken=result.enabled?result.authToken:null;
    authChecking=false;authLocked=false;authError=null;authGeneration++;
    if(authTimer!==null){clearTimeout(authTimer);authTimer=null;}
    if(authEnabled)authTimer=setTimeout(()=>{lockAuth();requestAutoUnlock();},Math.min(Number(result.sessionMillis)||300000,300000)-5000);
    releaseAuth();emitAuth();
}
function initializeAuth(){
    if(authInitialized)return authReady;
    authInitialized=true;authChecking=true;authLocked=true;blockAuth();emitAuth();
    readAuthStatus(true).then(result=>{
        authEnabled=result.enabled;authChecking=false;
        if(!result.enabled)acceptAuth(result);
        else{authLocked=true;authError=result.available?null:'unavailable';if(!requestAutoUnlock())emitAuth();}
    }).catch(error=>{authChecking=false;authLocked=true;authError=isNativeRuntimeUnreachable(error)?'runtime_unavailable':'unavailable';emitAuth();});
    return authReady;
}
function requestAutoUnlock(){
    if(resetPhase||!authStatusKnown||!authEnabled||!authLocked||authBusy||authChecking||authError||(global.document&&global.document.hidden))return false;
    authenticate('unlock').catch(()=>{});
    return true;
}
function lockAuth(){
    if(!authInitialized||(!authEnabled&&authStatusKnown))return;
    const token=authToken;authToken=null;authLocked=true;authGeneration++;
    if(authTimer!==null){clearTimeout(authTimer);authTimer=null;}
    blockAuth();emitAuth();
    if(token)authRequest('lock',{},token).catch(()=>{});
}
function cancelAuth(){
    const attempt=authAttempt;
    if(attempt){attempt.cancelled=true;if(attempt.resume)attempt.resume();if(attempt.request)authRequest('cancel',{request:attempt.request}).catch(()=>{});}
}
async function awaitAuthForeground(attempt,result){
    if(!global.document||!global.document.hidden)return result;
    const started=Date.now();
    await new Promise((resolve,reject)=>{
        const finish=error=>{clearTimeout(timer);attempt.resume=null;error?reject(error):resolve();};
        const timer=setTimeout(()=>finish(new Error('Authentication return timed out')),10000);
        attempt.resume=()=>{if(attempt.cancelled)finish(new Error('Authentication cancelled'));else if(!global.document.hidden)finish();};
        attempt.resume();
    });
    return {...result,sessionMillis:Math.max(1,Math.min(Number(result.sessionMillis)||300000,300000)-(Date.now()-started))};
}
function checkAuthAttempt(attempt){
    if(attempt.cancelled||(global.document&&global.document.hidden))throw new Error('Authentication cancelled');
}
function checkAuthAction(action){
    if(action==='enable'&&authEnabled||action!=='enable'&&!authEnabled)throw new Error('Invalid authentication action');
}
async function authenticate(action){
    if(!authInitialized)initializeAuth();
    if(resetPhase||authBusy||authChecking||!['enable','unlock','disable','confirm_ai'].includes(action))throw new Error('Authentication busy');
    if(action==='confirm_ai'&&(!authEnabled||authLocked||!authToken))throw new Error('WebUI session unavailable');
    const confirmationGeneration=authGeneration,confirmationToken=authToken;
    if(authStatusKnown)checkAuthAction(action);
    const attempt={cancelled:false,request:null,confirming:false,verifiedToken:null};authAttempt=attempt;authBusy=true;authError=null;emitAuth();
    try{
        // A failed startup check is an unknown state, not evidence that a helper is needed.
        if(!authStatusKnown){
            const current=await readAuthStatus(true);authEnabled=current.enabled;
            if(!current.enabled){acceptAuth(current);if(action==='unlock'&&!attempt.cancelled)return authState();}
            else if(!current.available)throw new Error('Device authentication unavailable');
        }
        checkAuthAttempt(attempt);checkAuthAction(action);
        const rawUser=String(await execHostCommand('am get-current-user',10000,true)).trim();
        if(!/^\d{1,5}$/.test(rawUser)||Number(rawUser)>21474)throw new Error('Invalid Android user');
        checkAuthAttempt(attempt);
        let challenge;
        try{challenge=await authRequest('begin',{action,userId:rawUser});}
        catch(_){
            // Begin returns a generic HTTP 400 for both helper and enrollment failures.
            const current=await readAuthStatus();authEnabled=current.enabled;
            if(!current.enabled){acceptAuth(current);if(action==='confirm_ai')throw new Error('Authentication state changed');if(action!=='enable'&&!attempt.cancelled)return authState();}
            checkAuthAttempt(attempt);checkAuthAction(action);
            if(current.enabled&&!current.available)throw new Error('Device authentication unavailable');
            // Install/update only while foreground authentication still permits this action.
            try{
                const installed=await execHostCommand(`CT_AUTH_APK=''; for CT_AUTH_DIR in /data/adb/modules/cleverestricky /data/adb/ksu/modules/cleverestricky /data/adb/ap/modules/cleverestricky; do if [ ! -L "$CT_AUTH_DIR/webui-auth.apk" ] && [ -f "$CT_AUTH_DIR/webui-auth.apk" ]; then CT_AUTH_APK="$CT_AUTH_DIR/webui-auth.apk"; break; fi; done; [ -n "$CT_AUTH_APK" ] || exit 1; pm install -r --user ${rawUser} "$CT_AUTH_APK"`,30000,true);
                if(!/(?:^|\r?\n)Success(?:\r?\n|$)/.test(installed))throw new Error(installed||'Verification component installation failed');
            }catch(error){error.code=/INSTALL_FAILED_(?:UPDATE_INCOMPATIBLE|SHARED_USER_INCOMPATIBLE)|INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES/.test(error.message)?'helper_signature_mismatch':'helper_install_failed';throw error;}
            checkAuthAttempt(attempt);
            challenge=await authRequest('begin',{action,userId:rawUser});
        }
        if(!/^[0-9a-f]{64}$/.test(challenge.request||'')||!/^[A-Za-z0-9_-]{128,384}$/.test(challenge.challenge||'')||challenge.action!==action)throw new Error('Invalid authentication challenge');
        attempt.request=challenge.request;
        checkAuthAttempt(attempt);
        async function launch(stage){
            if(attempt.cancelled)throw new Error('Authentication cancelled');
            try{
                // A fresh helper process must reopen the persisted key before enrollment commits.
                const launched=await execHostCommand(`am start ${stage==='confirm'?'-S ':''}--user ${rawUser} -n cleveres.tricky.webuiauth/.UnlockActivity --es request '${challenge.request}' --es challenge '${challenge.challenge}' --es action '${action}'${stage?` --es stage '${stage}'`:''}`,10000,true);
                if(/(?:^|\n)\s*(?:Error\b|Exception\b|SecurityException\b)/.test(launched))throw new Error('Android verification could not start');
            }catch(error){error.code='helper_launch_failed';throw error;}
        }
        await launch(action==='enable'?'probe':null);
        const deadline=Date.now()+120000;
        while(Date.now()<deadline){
            if(attempt.cancelled)throw new Error('Authentication cancelled');
            const result=await authRequest('complete',{request:attempt.request});
            if(result.error){const error=new Error(result.error==='cancelled'?'Authentication cancelled':'Device authentication unavailable');if(result.error==='key_invalidated')error.code='key_invalidated';if(result.error==='unsupported_device'&&action==='enable')error.code='unsupported_device';throw error;}
            if(attempt.cancelled){if(action!=='confirm_ai'&&result.pending===false){if(result.enabled){authEnabled=true;authToken=result.authToken;authChecking=false;lockAuth();}else acceptAuth(result);}throw new Error('Authentication cancelled');}
            if(result.confirm!==undefined){
                if(result.confirm!==true||result.pending!==true||action!=='enable'||attempt.confirming)throw new Error('Invalid enrollment confirmation');
                attempt.confirming=true;
                await launch('confirm');
                continue;
            }
            if(result.pending===false){
                if(/^[0-9a-f]{64}$/.test(result.authToken||''))attempt.verifiedToken=result.authToken;
                if(action==='enable'&&!attempt.confirming)throw new Error('Missing enrollment confirmation');
                const ready=await awaitAuthForeground(attempt,result);
                checkAuthAttempt(attempt);
                if(action==='confirm_ai'){
                    if(!ready.enabled||ready.authToken!=null||confirmationGeneration!==authGeneration||confirmationToken!==authToken||authLocked)throw new Error('WebUI session changed');
                    return authState();
                }
                acceptAuth(ready);attempt.verifiedToken=null;return authState();
            }
            if(result.pending!==true)throw new Error('Invalid authentication result');
            await new Promise(resolve=>setTimeout(resolve,500));
        }
        throw new Error('Authentication timed out');
    }catch(error){
        if(attempt.verifiedToken)await authRequest('lock',{},attempt.verifiedToken).catch(()=>{});
        if(attempt.request)await authRequest('cancel',{request:attempt.request}).catch(()=>{});
        // Cancelling an AI confirmation must not log out or replace the active session.
        if(action==='confirm_ai')throw error;
        const hadSession=action!=='unlock'&&authEnabled&&!authLocked&&Boolean(authToken);
        let verifiedDisabled=false;
        try{const current=await readAuthStatus();if(!current.enabled){acceptAuth(current);verifiedDisabled=true;}else if(!hadSession){authEnabled=true;authChecking=false;lockAuth();}}catch(_){authChecking=false;lockAuth();}
        const helperError=['helper_signature_mismatch','helper_install_failed','helper_launch_failed'].includes(error.code)?error.code:null;
        authError=attempt.cancelled||error.message==='Authentication cancelled'?'cancelled':helperError?helperError:action==='enable'&&verifiedDisabled?(error.code==='unsupported_device'?'unsupported_device':'enable_failed'):error.code==='key_invalidated'?'key_invalidated':isNativeRuntimeUnreachable(error)?'runtime_unavailable':'unavailable';
        error.code=authError;throw error;
    }finally{authAttempt=null;authBusy=false;emitAuth();}
}
if(typeof global.addEventListener==='function'){
    // The Android prompt uses the visibility path. Leaving the document revokes its session.
    global.addEventListener('pagehide',()=>{cancelFactoryReset();cancelAuth();lockAuth();});
    global.addEventListener('pageshow',()=>requestAutoUnlock());
    if(global.document&&typeof global.document.addEventListener==='function')global.document.addEventListener('visibilitychange',()=>{if(global.document.hidden){cancelFactoryReset();if(!authBusy)lockAuth();}else{if(authAttempt&&authAttempt.resume)authAttempt.resume();requestAutoUnlock();}});
}

async function nativeFetch(url,options={}){await requireAuth(options.signal||null);const authenticationGeneration=authGeneration;const effectiveOptions=preparePolicySaveOptions(url,options);const requestedTimeout=Number(effectiveOptions.timeoutMs??60000);const timeoutMs=Number.isFinite(requestedTimeout)?Math.min(Math.max(Math.trunc(requestedTimeout),1000),120000):60000;const signal=effectiveOptions.signal||null;throwIfAborted(signal);let request;try{request=await prepareRequest(url,effectiveOptions,timeoutMs,signal);throwIfAborted(signal);if(authToken)request.authToken=authToken;if(authenticationGeneration!==authGeneration)throw authLockedError();const response=await callRequest(request,timeoutMs,signal);if(!response.ok&&request.uploadId)await dropStage('upload',request.uploadId);if(response.status===401&&authInitialized){authEnabled=true;lockAuth();throw authLockedError();}if(authenticationGeneration!==authGeneration){if(response.downloadId)await dropStage('download',response.downloadId);throw authLockedError();}await rememberPolicyResponse(url,response);return response;}catch(error){if(request&&request.uploadId)await dropStage('upload',request.uploadId);throw error;}}async function exportBlob(blob,filename){await requireAuth();if(!(blob instanceof Blob)||typeof filename!=='string'||filename.length<1||filename.length>128)throw new Error('Invalid download');const kind='export';const id=await stageBlob(kind,blob,120000);try{return await execNative(['export',kind,id,encodeText(filename)],120000);}catch(error){await dropStage(kind,id);throw error;}}async function nativeReportResolver(){
    const fallback='android/com.android.internal.app.ResolverActivity';
    let configured;
    try{configured=(await execHostCommand('/system/bin/cmd overlay lookup --user 0 android android:string/config_customResolverActivity',5000)).trim();}
    catch(_){return fallback;}
    if(!configured)return fallback;
    if(configured.length>255||!/^[A-Za-z][A-Za-z0-9_.]*\/[A-Za-z.][A-Za-z0-9_.]*$/.test(configured))throw new Error('Invalid Android resolver');
    return configured;
}
async function shareBlob(blob,filename){
    if(!(blob instanceof Blob)||blob.type!=='application/zip'||blob.size<1||blob.size>2*1024*1024||filename!=='CleveresTricky-basic-report.zip')throw new Error('Invalid basic report');
    if(authLocked||authChecking)throw authLockedError();
    const navigator=global.navigator;
    if(navigator&&typeof navigator.canShare==='function'&&typeof navigator.share==='function'&&typeof File==='function'){
        const file=new File([blob],filename,{type:'application/zip'});
        if(navigator.canShare({files:[file]})){
            // Invoke before the first await: Web Share consumes transient user activation.
            await navigator.share({files:[file],title:'CleveresTricky'});return {method:'shared'};
        }
    }
    await requireAuth();const generation=authGeneration;const id=await stageBlob('export',blob,120000);
    try{
        if(generation!==authGeneration)throw authLockedError();
        const path=(await execNative(['export-basic-report',id],120000)).trim();
        const match=path.match(/^\/data\/user_de\/0\/com\.android\.shell\/files\/bugreports\/(CleveresTricky-basic-report-[a-f0-9]{32}\.zip)$/);
        if(!match||match[1]!==`CleveresTricky-basic-report-${id}.zip`)throw new Error('Invalid share destination');
        if(generation!==authGeneration)throw authLockedError();
        // Shell owns this FileProvider. Secondary users use the normal download fallback.
        const uri=`content://com.android.shell/bugreports/${match[1]}`;
        const resolver=await nativeReportResolver();
        if(generation!==authGeneration)throw authLockedError();
        const command=`/system/bin/restorecon '${path}' >/dev/null 2>&1 || exit 1; ct_share_user=$(/system/bin/am get-current-user); [ "$ct_share_user" = 0 ] || exit 1; su 2000 -c '/system/bin/content read --uri ${uri} >/dev/null 2>&1 && /system/bin/am start --user 0 -W -n ${resolver} -a android.intent.action.SEND -t application/zip --eu android.intent.extra.STREAM ${uri} --grant-read-uri-permission' 2>&1`;
        const launch=await execHostCommand(command,12000);
        if(!/^Status: ok\s*$/m.test(launch))throw new Error('Android sharing unavailable');
        return {method:'shared'};
    }catch(error){await dropStage('export',id);throw error;}
}

async function exportResponse(response,filename){await requireAuth();if(!(response instanceof NativeResponse)||typeof filename!=='string'||filename.length<1||filename.length>128)throw new Error('Invalid download');if(response.bodyUsed)throw new TypeError('Response body has already been consumed');if(response.downloadRef&&response.downloadRef.id&&!response.downloadRef.shared&&!response.downloadRef.promise&&!response.downloadRef.bytes){const reference=response.downloadRef;const id=reference.id;response.bodyUsed=true;response.downloadId=null;response.downloadRef=null;reference.id=null;try{return await execNative(['export','download',id,encodeText(filename)],120000);}catch(error){await dropStage('download',id);throw error;}}return exportBlob(await response.blob(),filename);}function listPackages(){if(authInitialized&&(authLocked||authChecking))return[];if(!nativeApi||typeof nativeApi.listPackages!=='function')return[];try{const parsed=JSON.parse(nativeApi.listPackages('all'));if(!Array.isArray(parsed)||parsed.length>100000)return[];return Array.from(new Set(parsed.filter(value=>typeof value==='string'&&value.length<=255&&/^[A-Za-z0-9_.]+$/.test(value)))).sort();}catch(_){return[];}}function routeExternalLinks(){const document=global.document;if(!document||!document.documentElement||!document.documentElement.dataset||document.documentElement.dataset.ctExternalLinkRouting)return;document.documentElement.dataset.ctExternalLinkRouting='1';document.addEventListener('click',event=>{const link=event.target&&event.target.closest?event.target.closest('a[href]'):null;if(!link)return;const href=link.getAttribute('href')||link.href;if(typeof href!=='string')return;const trimmed=href.trim();if(!/^https?:\/\//i.test(trimmed)&&!/^tg:\/\//i.test(trimmed))return;event.preventDefault();event.stopPropagation();openExternalUrl(trimmed).catch(()=>{if(!nativeApi||typeof nativeApi.exec!=='function'){try{global.open(trimmed,'_blank','noopener,noreferrer');}catch(_){}}});},true);}function relaxNativeFilePicker(input){if(!input||!nativeFilePickerIds.has(input.id))return;input.accept='*/*';}function installNativeFilePickerCompatibility(){const document=global.document;if(!document)return;nativeFilePickerIds.forEach(id=>relaxNativeFilePicker(document.getElementById(id)));if(!document.documentElement||document.documentElement.dataset.ctNativePickerCompatibility)return;document.documentElement.dataset.ctNativePickerCompatibility='1';document.addEventListener('click',event=>{const target=event.target;if(target&&target.id)relaxNativeFilePicker(target);},true);}function notifyExtension(message,type='normal'){if(typeof global.notify==='function')global.notify(extensionText(message),type);}async function readPolicyState(){if(policyStateRequest)return policyStateRequest;const request=(async()=>{const response=await nativeFetch('/api/policy_state');if(!response.ok)throw new Error(await response.text());const state=await response.json();rememberPolicyState(state);return state;})();policyStateRequest=request;try{return await request;}finally{if(policyStateRequest===request)policyStateRequest=null;}}async function performProfileEnabledMutation(name,enabled){if(typeof name!=='string')throw new Error('Invalid profile');const body=new URLSearchParams();body.set('action','set_enabled');body.set('data',JSON.stringify({name,enabled}));const response=await nativeFetch('/api/profile_v2',{method:'POST',body});if(!response.ok)throw new Error(await response.text());const state=await response.json();rememberPolicyState(state);return state;}function enqueuePolicyMutation(run){const operation=profileMutationQueue.catch(()=>{}).then(run);profileMutationQueue=operation.catch(()=>{});return operation;}function setProfileEnabled(profile,enabled){const name=profile&&typeof profile==='object'?profile.name:null;const requested=Boolean(enabled);return enqueuePolicyMutation(()=>performProfileEnabledMutation(name,requested));}function decorateProfileEnablement(){const document=global.document;const list=document&&document.getElementById('ct_profile_list');const profiles=latestPolicyState&&Array.isArray(latestPolicyState.profiles)?latestPolicyState.profiles:[];if(!list||!profiles.length)return;const rows=Array.from(list.querySelectorAll('.ct-profile-item'));rows.forEach((row,index)=>{if(row.dataset.ctProfileEnablement==='1')return;const profile=profiles[index];if(!profile)return;row.dataset.ctProfileEnablement='1';const label=document.createElement('label');label.className='ct-profile-enabled-control';label.style.cssText='display:inline-flex;align-items:center;gap:8px;min-height:44px;flex:0 0 auto;';const text=document.createElement('span');text.dataset.ctExtensionCopy='profile-state';text.textContent=extensionText(profile.enabled===false?'Disabled':'Enabled');const input=document.createElement('input');input.type='checkbox';input.className='ct-switch';input.checked=profile.enabled!==false;input.setAttribute('aria-label',`${profile.name}: ${extensionText('Enabled')}`);input.addEventListener('change',async()=>{const requested=input.checked;input.disabled=true;let state;try{state=await setProfileEnabled(profile,requested);}catch(error){input.checked=!requested;try{if(typeof global.notify==='function')global.notify(error.message||'Could not update profile','error');}catch(notifyError){console.error('[CleveresTricky] Profile failure notification failed',notifyError);}return;}finally{input.disabled=false;}try{if(typeof global.dispatchEvent==='function'&&typeof global.CustomEvent==='function'){global.dispatchEvent(new global.CustomEvent('ct-policy-state',{detail:state}));}text.textContent=extensionText(requested?'Enabled':'Disabled');notifyExtension(requested?'Profile enabled':'Profile disabled');}catch(error){console.error('[CleveresTricky] Profile saved, but presentation refresh failed',error);}});label.append(text,input);const editButton=row.querySelector('[data-edit-profile]');row.insertBefore(label,editButton||null);});}async function ensureProfileEnablement(){const document=global.document;const list=document&&document.getElementById('ct_profile_list');if(!list)return false;if(!latestPolicyState){try{await readPolicyState();}catch(_){return false;}}decorateProfileEnablement();if(!list.dataset.ctProfileEnablementObserver&&typeof global.MutationObserver==='function'){list.dataset.ctProfileEnablementObserver='1';new global.MutationObserver(()=>decorateProfileEnablement()).observe(list,{childList:true});}return true;}function getCronAutoIdentity(){return getRuntimeMarker('cron_auto_identity');}function setCronAutoIdentity(enabled){return setRuntimeMarker('cron_auto_identity',enabled);}function updateIdentityHealthBadge(degradation,source){const badge=global.document&&global.document.getElementById('ct_identity_health_badge');if(!badge)return;const state=String(degradation||'HEALTHY').toUpperCase();const src=String(source||'FLASHSTATION');badge.dataset.ctDegradation=state;badge.dataset.ctSource=src;if(state==='HEALTHY'){badge.style.border='1px solid #2ecc71';badge.style.color='#2ecc71';badge.style.background='rgba(46, 204, 113, 0.15)';badge.dataset.ctExtensionSource='Healthy';badge.textContent=extensionText('Healthy');}else if(state==='DEGRADED'){badge.style.border='1px solid #f1c40f';badge.style.color='#f1c40f';badge.style.background='rgba(241, 196, 15, 0.15)';badge.dataset.ctExtensionSource='Backup source: {value}';badge.textContent=extensionText('Backup source: {value}').replace('{value}',src);}else{badge.style.border='1px solid #e74c3c';badge.style.color='#e74c3c';badge.style.background='rgba(231, 76, 60, 0.15)';badge.dataset.ctExtensionSource='Stale template, manual refresh needed';badge.textContent=extensionText('Stale template, manual refresh needed');}}async function installCronAutoIdentity(){const document=global.document;const identityPanel=document&&document.querySelector('#spoof .panel');const notes=identityPanel?Array.from(identityPanel.querySelectorAll('.scope-note')):[];const autoIdentityNote=notes.length>1?notes[notes.length-1]:notes[0];if(!identityPanel||!autoIdentityNote||document.getElementById('ct_cron_auto_identity_row'))return Boolean(identityPanel);const row=document.createElement('div');row.id='ct_cron_auto_identity_row';row.className='row';row.style.cssText='margin:12px 0 0;padding-top:12px;border-top:1px dashed var(--border);';const label=document.createElement('label');label.htmlFor='ct_cron_auto_identity';label.style.cssText='flex:1;padding-right:10px;';const title=document.createElement('strong');title.style.color='#fff';title.dataset.ctExtensionSource='Cron Auto Identity';title.textContent=extensionText('Cron Auto Identity');const description=document.createElement('span');description.className='res-desc';description.dataset.ctExtensionSource='Fetches and applies a fresh Auto Identity every 24 hours while Build Identity is enabled.';description.textContent=extensionText(description.dataset.ctExtensionSource);const healthBadge=document.createElement('span');healthBadge.id='ct_identity_health_badge';healthBadge.className='ct-badge';healthBadge.style.cssText='display:inline-block;padding:2px 8px;border-radius:999px;font-size:0.75em;font-weight:600;margin-left:8px;vertical-align:middle;';title.append(healthBadge);updateIdentityHealthBadge('HEALTHY','FLASHSTATION');nativeFetch('/api/identity_diagnostics').then(async res=>{if(res.ok){const diag=await res.json();updateIdentityHealthBadge(diag.degradation,diag.servingSource);}}).catch(()=>{});label.append(title,description);const toggle=document.createElement('input');toggle.id='ct_cron_auto_identity';toggle.type='checkbox';toggle.className='ct-switch';toggle.disabled=true;toggle.addEventListener('change',async()=>{const requested=toggle.checked;toggle.disabled=true;try{await setCronAutoIdentity(requested);notifyExtension(requested?'Enabled':'Disabled');}catch(error){toggle.checked=!requested;if(typeof global.notify==='function')global.notify(error.message||'Could not update Cron Auto Identity','error');}finally{toggle.disabled=false;}});row.append(label,toggle);autoIdentityNote.insertAdjacentElement('afterend',row);try{toggle.checked=await getCronAutoIdentity();}catch(_){toggle.checked=false;}finally{toggle.disabled=false;}return true;}
async function applyIdentityLive(){
    try{
        const response=await nativeFetch('/api/identity/apply',{method:'POST',timeoutMs:30000});
        if(!response.ok)throw new Error(await response.text());
        const result=await response.json();
        if(!result||typeof result.applied!=='boolean'||typeof result.rebootRequired!=='boolean'){
            throw new Error('Invalid live Identity response');
        }
        return result;
    }catch(error){
        return {applied:false,rebootRequired:true,error};
    }
}
const cleveresLogsCommand=`{ logcat -d -t 2000 2>/dev/null | grep -E ' (CleveresTricky|cleverestricky|cleverestrickyd|cleverestricky_backend) *:' || true; `+`if [ -f '${nativeRuntimeLog}' ] && [ ! -L '${nativeRuntimeLog}' ]; then printf '\
--- native runtime ---\
'; tail -n 1000 '${nativeRuntimeLog}' 2>/dev/null; fi; } | tail -n 2500 | tail -c 1048576`;async function loadCleveresLogs(){return(await execHostCommand(cleveresLogsCommand,10000)).trim();}
function installLogsOwner(){
    const original=global.fetchLogs;if(typeof original!=='function'||original.ctCleveresLogs)return false;
    let generation=0;
    const wrapped=async function(){
        const current=++generation;const document=global.document;const typeNode=document&&document.getElementById('logType');
        const type=typeNode?typeNode.value:'cleverestricky';if(type!=='cleverestricky')return original.apply(this,arguments);
        const isCurrent=()=>{const page=document&&document.getElementById('log');return current===generation&&(!typeNode||typeNode.value===type)&&(!page||page.classList.contains('active'));};
        try{
            const logs=await loadCleveresLogs();if(!isCurrent())return;
            const viewer=document.getElementById('logViewer');if(viewer){viewer.value=logs.trim()||extensionText('No CleveresTricky logs found.');viewer.scrollTop=viewer.scrollHeight;}
            if(typeof global.notify==='function')global.notify('Refresh Logs');
        }catch(_){if(isCurrent()&&typeof global.notify==='function')global.notify('Failed to load logs','error');}
    };
    wrapped.ctCleveresLogs=true;global.fetchLogs=wrapped;return true;
}function refreshExtensionCopy(){const document=global.document;if(!document)return;document.querySelectorAll('[data-ct-extension-source]').forEach(node=>{node.textContent=extensionText(node.dataset.ctExtensionSource);});document.querySelectorAll('[data-ct-extension-copy="profile-state"]').forEach(node=>{const input=node.parentElement&&node.parentElement.querySelector('input[type="checkbox"]');node.textContent=extensionText(input&&input.checked?'Enabled':'Disabled');});refreshRemoteServerStatusCopy();const hb=document.getElementById("ct_identity_health_badge");if(hb&&hb.dataset.ctDegradation){updateIdentityHealthBadge(hb.dataset.ctDegradation,hb.dataset.ctSource);}}function installRuntimeEnhancements(attempt=0){const document=global.document;if(!document||!document.body)return;refreshRemoteServerStatusCopy();ensureProfileEnablement().catch(()=>{});installCronAutoIdentity().catch(()=>{});const logsReady=installLogsOwner()||(typeof global.fetchLogs==='function'&&global.fetchLogs.ctCleveresLogs===true);const identityPanel=document.querySelector('#spoof .panel');if(identityPanel&&!identityPanel.dataset.ctCronObserver&&typeof global.MutationObserver==='function'){identityPanel.dataset.ctCronObserver='1';new global.MutationObserver(()=>installCronAutoIdentity().catch(()=>{})).observe(identityPanel,{childList:true,subtree:true});}if(attempt<100&&(!document.getElementById('ct_profile_list')||!document.getElementById('ct_cron_auto_identity_row')||!logsReady)){global.setTimeout(()=>installRuntimeEnhancements(attempt+1),100);}}function scheduleRuntimeEnhancements(){const document=global.document;if(!document||!document.getElementById('tab_dashboard'))return;const start=()=>global.setTimeout(()=>installRuntimeEnhancements(),0);if(document.readyState==='complete')start();else global.addEventListener('load',start,{once:true});}function loadUxEnhancements(){const document=global.document;if(!document||!document.head||!document.createElement||document.getElementById('ct_ux_script'))return;const script=document.createElement('script');script.id='ct_ux_script';script.src='ux.js?revision=27';script.defer=true;script.onload=()=>global.setTimeout(installNativeFilePickerCompatibility,0);document.head.appendChild(script);}try{if(nativeApi&&typeof nativeApi.enableEdgeToEdge==='function')nativeApi.enableEdgeToEdge(true);}catch(_){}try{if(nativeApi&&typeof nativeApi.enableInsets==='function')nativeApi.enableInsets(true);}catch(_){}if(typeof global.addEventListener==='function'){global.addEventListener('ct_retranslate',refreshExtensionCopy);}if(global.document&&global.document.documentElement&&global.document.documentElement.dataset.ctAuthLocked==='1')initializeAuth();routeExternalLinks();installNativeFilePickerCompatibility();scheduleRuntimeEnhancements();global.CleveresBridge=Object.freeze({revision:18,executeAiCommand,initializeAuth,authState,authenticate,confirmAiAccess:()=>authenticate('confirm_ai'),cancelAuth,lockAuth,factoryResetState,beginFactoryReset,cancelFactoryReset,factoryReset,restartAfterFactoryReset,generateEmergencyReport,inspectOfflineEnvironment,fetch:nativeFetch,exportBlob,exportResponse,shareBlob,listPackages,openCommunity,openKeyboxHub,openExternalUrl,getZygiskStatus,getDebugLogging,setDebugLogging,enqueuePolicyMutation,setProfileEnabled,getCronAutoIdentity,setCronAutoIdentity,applyIdentityLive,loadCleveresLogs,translateExtension:extensionText,translateRemoteStatus:remoteStatusText,updateIdentityHealthBadge,getProcessResources});loadUxEnhancements();})(window);

