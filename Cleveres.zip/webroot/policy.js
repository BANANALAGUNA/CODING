(function(global){'use strict';const bridge=global.CleveresBridge;if(!bridge)return;let zygiskAvailable=null;const FEATURE_KEYS=[['buildIdentity','Build identity','Boot fingerprint, model and build fields. Requires a reboot when early-boot properties change.'],['attestationIdentity','Attestation identity','Uses the configured attestation identity only for selected targets; genuine hardware key operations remain on Android.'],['telephonyIdentity','Telephony identity','Controls optional IMEI/IMSI/ICCID/phone presentation for selected apps.'],['regionIdentity','Region identity','Controls optional region/hardware-region presentation. Some values require a reboot.'],['identityRefresh','Identity refresh','Prepares a new identity for the next boot only while this option is enabled.'],['customProps','Custom properties','Set your own system properties as KEY=VALUE lines. Applied after templates and build values; needs a reboot in global mode.']];const PATCH_COMPONENTS=[['system','System'],['vendor','Vendor'],['boot','Boot']];const PATCH_MODES=[['device_default','Device default'],['prop','ROM property'],['manual','Manual date'],['automatic','Automatic'],['no','Omit']];const PROFILE_FEATURES=FEATURE_KEYS.filter((feature)=>feature[0]!=='customProps').map((feature)=>feature[0]==='identityRefresh'?['identityRefresh','Auto Identity (Pixel Beta)','Refreshes identity every 24 hours while this profile and Build identity are enabled. Device-wide Build properties stay unchanged.']:feature);const KEYBOX_PRIORITY_CATEGORIES=['VALID_RKP','VALID_RKP_SERVER','VALID_TEE','VALID_TEE_SERVER','INVALID_EXPIRED_RKP','INVALID_EXPIRED_RKP_SERVER','INVALID_EXPIRED_TEE','INVALID_EXPIRED_TEE_SERVER','INVALID_REVOKED_RKP','INVALID_REVOKED_RKP_SERVER','INVALID_REVOKED_TEE','INVALID_REVOKED_TEE_SERVER'];const LEGACY_KEYBOX_PRIORITY_CATEGORIES=['VALID_RKP','VALID_TEE','INVALID_EXPIRED_RKP','INVALID_EXPIRED_TEE','INVALID_REVOKED_RKP','INVALID_REVOKED_TEE'];const FULL_KEYBOX_PRIORITY_CATEGORIES=['VALID','INVALID_EXPIRED','INVALID_REVOKED','INVALID_VERIFICATION_FAILED'].flatMap(reason=>['RKP','STRONGBOX','TEE','UNKNOWN'].flatMap(level=>[reason+'_'+level,reason+'_'+level+'_SERVER']));const SAVED_BUILD_IDENTITY_KEYS=new Set(['BRAND','PRODUCT','DEVICE','MANUFACTURER','MODEL','FINGERPRINT','RELEASE','BUILD_ID','INCREMENTAL','SECURITY_PATCH']);const SAVED_BUILD_IDENTITY_FIELDS=[['BRAND','Brand'],['PRODUCT','Product'],['DEVICE','Device'],['BUILD_ID','Build ID'],['RELEASE','Android release'],['SECURITY_PATCH','Security patch'],['INCREMENTAL','Incremental']];let policyState=null;let legacyConfig=null;let packages=[];let keyboxes=[];let templates=[];let selectedProfileIndex=-1;let profileEditorRevision=0;let profilePolicyRevision=0;let profileEditorLockCount=0;let profileEditorWasDisabled=false;let saving=false;let legacyToggleQueue=Promise.resolve();const pendingLegacyToggles=new Map();const pendingPolicyToggles=new Map();let savedBuildIdentity=Object.freeze({});let patchInspectionController=null;let effectiveInspectionController=null;let referenceDataController=null;const REBOOT_POLICY_FEATURES=new Set(['buildIdentity','regionIdentity','identityRefresh','customProps']);const MAX_REFERENCE_PACKAGES=10000;const MAX_REFERENCE_KEYBOXES=4096;const MAX_REFERENCE_TEMPLATES=256;const MAX_POLICY_PROFILES=64;const MAX_PROFILE_APPLICATIONS=256;const MAX_TOTAL_ASSIGNMENTS=2048;const MAX_PROFILE_VALUE_LENGTH=256;function onReady(fn){if(document.body)fn();else document.addEventListener('DOMContentLoaded',fn,{once:true});}async function request(path,options){const fetcher=(typeof global.fetchAuth==='function')?global.fetchAuth:bridge.fetch;const response=await fetcher(path,options||{});if(!response.ok){const text=await response.text();throw new Error(text||`Request failed (${response.status})`);}const type=response.headers.get('content-type')||'';return type.includes('application/json')?response.json():response.text();}function notify(message,type){if(typeof global.notify==='function')global.notify(message,type||'normal');}function policyCompatibilityWarning(state){if(!state||state.compatibilitySync!=='pending')return'';return String(state.compatibilityWarning||'Policy was saved, but early-boot compatibility synchronization is pending. Retry before reboot.');}function notifyPolicyMutation(successMessage,state){const message=successMessage||'Saved';const warning=policyCompatibilityWarning(state);const runtimeWarning=state&&state.runtimeWarning;if(runtimeWarning)notify(`${message}. Warning: ${runtimeWarning}`,'warning');else if(warning)notify(`${message}. Warning: ${warning}`);else if(state&&(state.zygiskRebootRequired||(state.runtimeTransition&&state.runtimeTransition.rebootRequired===true)))notify(`${message}. ${pickerText('Reboot required','Reboot required')}`,'warning');else notify(message);}
function refreshPresentation(root){
    const i18n=global.CleveresI18n;
    if(i18n&&typeof i18n.apply==='function')i18n.apply(root);
}
function safeClone(value){return JSON.parse(JSON.stringify(value));}function normalizePolicyFeatures(value){const source=value&&typeof value==='object'?value:{};return{buildIdentity:source.buildIdentity===true,attestationIdentity:source.attestationIdentity===true,telephonyIdentity:source.telephonyIdentity===true,regionIdentity:source.regionIdentity===true,identityRefresh:source.identityRefresh===true,securityPatch:source.securityPatch===true,customProps:source.customProps===true};}function normalizeProfile(profile){const source=profile&&typeof profile==='object'?profile:{};const features={};if(source.features&&typeof source.features==='object'){PROFILE_FEATURES.forEach(([key])=>{if(typeof source.features[key]==='boolean')features[key]=source.features[key];});if(typeof source.features.securityPatch==='boolean')features.securityPatch=source.features.securityPatch;}const patch={};PATCH_COMPONENTS.forEach(([key])=>{const value=source.securityPatch&&source.securityPatch[key];if(value&&typeof value==='object'&&PATCH_MODES.some(([mode])=>mode===value.mode)){patch[key]={mode:value.mode};if(value.mode==='manual'&&typeof value.value==='string')patch[key].value=value.value.slice(0,10);}});const applications=Array.isArray(source.applications)?[...new Set(source.applications.map(value=>String(value).trim()).filter(value=>value))]:[];const template=typeof source.template==='string'&&source.template.length<=MAX_PROFILE_VALUE_LENGTH?source.template:null;const keybox=typeof source.keybox==='string'&&source.keybox.length<=MAX_PROFILE_VALUE_LENGTH?source.keybox:null;return{name:String(source.name||'').trim().slice(0,MAX_PROFILE_VALUE_LENGTH),enabled:source.enabled!==false,applications,template,keybox,privacy:['inherit','isolate','redact'].includes(source.privacy)?source.privacy:'inherit',features,securityPatch:patch,rkpPassthrough:typeof source.rkpPassthrough==='boolean'?source.rkpPassthrough:null,drmPassthrough:typeof source.drmPassthrough==='boolean'?source.drmPassthrough:null};}function normalizeKeyboxPriorityOrder(value) {
    const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    if (source.mode !== 'custom') return {mode: 'default'};
    const order = Array.isArray(source.customOrder) ? source.customOrder.map(String) : [];
    const complete = categories => order.length === categories.length && new Set(order).size === categories.length && order.every(category => categories.includes(category));
    if (complete(KEYBOX_PRIORITY_CATEGORIES) || complete(FULL_KEYBOX_PRIORITY_CATEGORIES)) return {mode: 'custom', customOrder: order};
    if (complete(LEGACY_KEYBOX_PRIORITY_CATEGORIES) || complete(FULL_KEYBOX_PRIORITY_CATEGORIES.filter(category => !category.endsWith('_SERVER')))) {
        return {mode: 'custom', customOrder: order};
    }
    return {mode: 'default'};
}
function normalizeSecurityPatch(value){const source=value&&typeof value==='object'?value:{};const normalized={automaticThresholdMonths:Math.min(24,Math.max(1,Number(source.automaticThresholdMonths)||6))};PATCH_COMPONENTS.forEach(([key])=>{const item=source[key]&&typeof source[key]==='object'?source[key]:{};const mode=PATCH_MODES.some(([option])=>option===item.mode)?item.mode:'device_default';normalized[key]={mode};if(mode==='manual'&&typeof item.value==='string')normalized[key].value=item.value.slice(0,10);});return normalized;}function validatePolicyLimits(source){const profiles=Array.isArray(source&&source.profiles)?source.profiles:[];if(profiles.length>MAX_POLICY_PROFILES){throw new Error(`Policy supports at most ${MAX_POLICY_PROFILES} profiles`);}let totalAssignments=0;profiles.forEach(profile=>{const applications=Array.isArray(profile&&profile.applications)?profile.applications:[];if(applications.length>MAX_PROFILE_APPLICATIONS){throw new Error(`A profile supports at most ${MAX_PROFILE_APPLICATIONS} application assignments`);}totalAssignments+=applications.length;if(totalAssignments>MAX_TOTAL_ASSIGNMENTS){throw new Error(`Policy supports at most ${MAX_TOTAL_ASSIGNMENTS} total application assignments`);}});}function stateForSave(source){const normalized={version:Number(source.version)||2,features:normalizePolicyFeatures(source.features),securityPatch:normalizeSecurityPatch(source.securityPatch),profiles:Array.isArray(source.profiles)?source.profiles.map(normalizeProfile):[],activeProfile:typeof source.activeProfile==='string'?source.activeProfile.slice(0,MAX_PROFILE_VALUE_LENGTH):null,blockInvalidKeyboxes:source.blockInvalidKeyboxes!==false,globalIdentity:source.globalIdentity!==false,spoofProps:source.spoofProps!==false,keyboxPriorityOrder:normalizeKeyboxPriorityOrder(source.keyboxPriorityOrder)};validatePolicyLimits(normalized);return normalized;}function normalizePolicyState(value){const source=value&&typeof value==='object'&&!Array.isArray(value)?safeClone(value):{};source.features=normalizePolicyFeatures(source.features);source.profiles=Array.isArray(source.profiles)?source.profiles.map(normalizeProfile):[];source.securityPatch=normalizeSecurityPatch(source.securityPatch);source.activeProfile=typeof source.activeProfile==='string'?source.activeProfile.slice(0,MAX_PROFILE_VALUE_LENGTH):null;source.blockInvalidKeyboxes=source.blockInvalidKeyboxes!==false;source.globalIdentity=source.globalIdentity!==false;source.spoofProps=source.spoofProps!==false;source.keyboxPriorityOrder=normalizeKeyboxPriorityOrder(source.keyboxPriorityOrder);return source;}
function validateImportedPolicy(value){
    const object=item=>item!==null&&typeof item==='object'&&!Array.isArray(item);
    const has=(item,key)=>Object.prototype.hasOwnProperty.call(item,key);
    const invalid=()=>{throw new Error('Could not import profile policy');};
    const patchShape=patch=>{
        if(!object(patch))return false;
        if(has(patch,'automaticThresholdMonths')&&!Number.isSafeInteger(patch.automaticThresholdMonths))return false;
        return PATCH_COMPONENTS.every(([key])=>{
            if(!has(patch,key))return true;
            const component=patch[key];
            return object(component)&&typeof component.mode==='string'&&(!has(component,'value')||typeof component.value==='string');
        });
    };
    if(!object(value)||value.version!==2||!object(value.features)||!patchShape(value.securityPatch)||!Array.isArray(value.profiles))invalid();
    for(const key of ['buildIdentity','attestationIdentity','telephonyIdentity','regionIdentity','identityRefresh','securityPatch']){
        if(typeof value.features[key]!=='boolean')invalid();
    }
    if(has(value.features,'customProps')&&typeof value.features.customProps!=='boolean')invalid();
    for(const key of ['blockInvalidKeyboxes','globalIdentity','spoofProps']){
        if(has(value,key)&&typeof value[key]!=='boolean')invalid();
    }
    if(has(value,'activeProfile')&&value.activeProfile!==null&&typeof value.activeProfile!=='string')invalid();
    if(has(value,'keyboxPriorityOrder')){
        const priority=value.keyboxPriorityOrder;
        if(!object(priority)||!['default','custom'].includes(priority.mode)||Object.keys(priority).some(key=>!['mode','customOrder'].includes(key)))invalid();
        if(priority.mode==='default'&&has(priority,'customOrder'))invalid();
        if(priority.mode==='custom'&&(!Array.isArray(priority.customOrder)||priority.customOrder.some(item=>typeof item!=='string')||normalizeKeyboxPriorityOrder(priority).mode!=='custom'))invalid();
    }
    for(const profile of value.profiles){
        if(!object(profile)||typeof profile.name!=='string'||!Array.isArray(profile.applications)||profile.applications.some(item=>typeof item!=='string'))invalid();
        if(has(profile,'enabled')&&typeof profile.enabled!=='boolean')invalid();
        if(has(profile,'privacy')&&typeof profile.privacy!=='string')invalid();
        for(const key of ['template','keybox'])if(has(profile,key)&&profile[key]!==null&&typeof profile[key]!=='string')invalid();
        for(const key of ['rkpPassthrough','drmPassthrough'])if(has(profile,key)&&profile[key]!==null&&typeof profile[key]!=='boolean')invalid();
        if(has(profile,'features')&&(!object(profile.features)||Object.values(profile.features).some(item=>typeof item!=='boolean')))invalid();
        if(has(profile,'securityPatch')&&!patchShape(profile.securityPatch))invalid();
    }
    return value;
}
function profileIndexByName(state,name){
    if(!state||!Array.isArray(state.profiles)||typeof name!=='string')return -1;
    const key=name.toLowerCase();
    return state.profiles.findIndex(profile=>profile.name.toLowerCase()===key);
}
function publishPolicyState(value){
    const editingExisting=selectedProfileIndex>=0;
    const edited=editingExisting&&policyState?policyState.profiles[selectedProfileIndex]:null;
    const next=normalizePolicyState(value);
    policyState=next;
    if(editingExisting){
        selectedProfileIndex=profileIndexByName(next,edited&&edited.name);
        if(selectedProfileIndex<0){
            profileEditorRevision++;
            const panel=document.getElementById('ct_profile_editor_panel');
            if(panel)panel.hidden=true;
        }
    }
    return next;
}
function lockProfileEditor(){
    const fields=document.getElementById('ct_profile_editor_fields');
    if(profileEditorLockCount===0)profileEditorWasDisabled=fields?fields.disabled:false;
    profileEditorLockCount++;
    if(fields)fields.disabled=true;
}
function unlockProfileEditor(){
    if(profileEditorLockCount===0)return;
    profileEditorLockCount--;
    if(profileEditorLockCount===0){
        const fields=document.getElementById('ct_profile_editor_fields');
        if(fields)fields.disabled=profileEditorWasDisabled;
    }
}
function transitionRequiresReboot(transition,feature){
    if(!transition||typeof transition!=='object')return true;
    if(feature==='customProps'){
        return typeof transition.customPropsRebootRequired==='boolean'
            ?transition.customPropsRebootRequired:transition.rebootRequired!==false;
    }
    if(transition.rebootRequired!==true)return false;
    const appliedKey=feature==='buildIdentity'?'buildApplied':'regionApplied';
    return![transition.restore,transition.apply].some(result=>result&&result[appliedKey]===true);
}
function rebootFeatureEnabled(state,feature){
    if(!state||!state.features||!state.features[feature])return false;
    if(feature==='identityRefresh')return true;
    return state.globalIdentity!==false&&(feature!=='buildIdentity'||state.spoofProps!==false);
}
function reconcilePolicyPendingReboot(previous,next){
    REBOOT_POLICY_FEATURES.forEach(feature=>{
        const before=rebootFeatureEnabled(previous,feature);
        const after=rebootFeatureEnabled(next,feature);
        if(before===after)return;
        if(feature==='identityRefresh'||transitionRequiresReboot(next.runtimeTransition,feature)){
            markPendingReboot(`feature:${feature}`);
        }else{
            clearPendingReboot(`feature:${feature}`);
        }
    });
    if(next.runtimeTransition&&next.runtimeTransition.customPropsRebootRequired===true)markPendingReboot('feature:customProps');
}
function enqueueMutation(run){if(typeof bridge!=='undefined'&&typeof bridge.enqueuePolicyMutation==='function')return bridge.enqueuePolicyMutation(run);const operation=legacyToggleQueue.catch(()=>{}).then(run);legacyToggleQueue=operation.catch(()=>{});return operation;}
function policyViewState(){if(!policyState)return null;const view={...policyState,features:{...policyState.features}};pendingPolicyToggles.forEach(change=>change.mutator(view));return view;}
function legacyToggleValue(setting,fallback=false){const pending=pendingLegacyToggles.get(setting);if(pending)return pending.enabled;if(setting==='block_invalid_keyboxes'&&policyState)return policyState.blockInvalidKeyboxes!==false;return Boolean(legacyConfig&&typeof legacyConfig[setting]==='boolean'?legacyConfig[setting]:fallback);}
function refreshPolicyControls(){try{renderFeatureCenter();renderIdentityScopeBanner();const banner=document.getElementById('ct_identity_scope_banner');if(banner)refreshPresentation(banner);}catch(error){console.error('[CleveresTricky] Toggle presentation refresh failed',error);}}
async function performPolicySave(mutator,successMessage,refresh=renderAll,onCommitted=()=>{},importedPolicy=undefined){if(!policyState)return false;let previous;try{previous=safeClone(policyState);const next=safeClone(policyState);mutator(next);const body=new URLSearchParams();body.set('data',JSON.stringify(importedPolicy===undefined?stateForSave(next):importedPolicy));publishPolicyState(await request('/api/policy_state',{method:'POST',body}));}catch(error){try{notify(error.message||'Could not save policy','error');}catch(notifyError){console.error('[CleveresTricky] Policy failure notification failed',notifyError);}try{refresh();}catch(refreshError){console.error('[CleveresTricky] Policy failure view refresh failed',refreshError);}return false;}try{onCommitted();reconcilePolicyPendingReboot(previous,policyState);refresh();}catch(error){console.error('[CleveresTricky] Policy saved, but presentation refresh failed',error);}try{notifyPolicyMutation(successMessage,policyState);}catch(error){console.error('[CleveresTricky] Policy saved, but notification failed',error);}return true;}
function readKeyboxPriorityOrder(options={}){return enqueueMutation(async()=>{const state=publishPolicyState(await request('/api/policy_state',options));return safeClone(state.keyboxPriorityOrder);});}
function saveKeyboxPriorityOrder(preference,successMessage){const requested=normalizeKeyboxPriorityOrder(safeClone(preference));return enqueueMutation(async()=>{if(!policyState)publishPolicyState(await request('/api/policy_state'));return performPolicySave(next=>{next.keyboxPriorityOrder=requested;},successMessage,()=>{});});}
function savePolicy(mutator,successMessage,isCurrent=()=>true){if(!policyState||saving)return Promise.resolve(false);saving=true;document.documentElement.classList.add('ct-saving');return enqueueMutation(()=>isCurrent()?performPolicySave(mutator,successMessage):false).finally(()=>{saving=false;document.documentElement.classList.remove('ct-saving');});}
function setPolicyToggle(key,mutator,message){if(!policyState)return Promise.resolve(false);const change={mutator};pendingPolicyToggles.delete(key);pendingPolicyToggles.set(key,change);refreshPolicyControls();return enqueueMutation(async()=>{if(pendingPolicyToggles.get(key)!==change)return true;try{return await performPolicySave(mutator,message,refreshPolicyControls);}finally{if(pendingPolicyToggles.get(key)===change)pendingPolicyToggles.delete(key);try{refreshPolicyControls();}catch(error){console.error('[CleveresTricky] Toggle view refresh failed',error);}}});}
function injectStyles(){if(document.getElementById('ctPolicyUxStyle'))return;const style=document.createElement('style');style.id='ctPolicyUxStyle';style.textContent=`
    .ct-feature-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:12px}
    .ct-feature-card{border:1px solid var(--ct-soft-border,var(--border));border-radius:18px;padding:16px;background:var(--panel);min-width:0}
    .ct-feature-card .row{margin:0;align-items:center;flex-wrap:wrap;row-gap:8px}
    .ct-feature-card strong{display:block;color:#fff}
    .ct-feature-card p{margin:6px 0 0;color:#999;font-size:.84em;line-height:1.45}
    .ct-subcontrols{margin-top:12px;padding-top:10px;border-top:1px solid var(--border)}
    .ct-subcontrols[hidden]{display:none!important}
    .ct-subcontrols .row{margin-bottom:10px}
    .ct-subcontrols .row:last-child{margin-bottom:0}
    .ct-help{margin-top:12px;border-top:1px solid var(--ct-soft-border,var(--border));padding-top:0}
    .ct-help summary{cursor:pointer;color:var(--accent);font-size:13px;min-height:44px;display:flex;align-items:center}
    .ct-help p{margin:5px 0 0!important}
    .ct-banner{border:1px solid #5c4b19;background:rgba(245,158,11,.09);border-radius:10px;padding:13px 14px;margin-bottom:16px;color:#f3d68a;line-height:1.45}
    .ct-action-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px!important;width:100%}
    .ct-action-grid>button{width:100%!important;min-width:0!important;white-space:normal;overflow-wrap:anywhere;line-height:1.25;padding:12px 10px!important}
    .ct-toolbar{display:flex;gap:10px;flex-wrap:wrap}.ct-toolbar button{flex:1 1 160px;min-width:0}
    .ct-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .ct-inline-note{font-size:.82em;color:#999;line-height:1.45;margin:8px 0 0}
    .ct-chip-wrap{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}
    .ct-chip{display:inline-flex;gap:7px;align-items:center;min-width:0;overflow-wrap:anywhere;border:1px solid #3a3a3a;border-radius:999px;padding:6px 9px;font-size:.8em;background:#1c1c1c}
    .ct-chip button{flex:0 0 44px;min-width:44px;min-height:44px;padding:0;border-radius:50%;font-size:16px}
    .ct-profile-item{display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--border);padding:10px 0}
    .ct-profile-item:last-child{border-bottom:0}.ct-profile-item .ct-profile-copy{flex:1;min-width:0}
    .ct-profile-item .ct-profile-copy small{display:block;color:#888;margin-top:3px;overflow-wrap:anywhere}
    .ct-profile-item button{flex:0 0 auto;padding:9px 12px}
    .ct-patch-component{border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:10px}
    .ct-patch-component:last-child{margin-bottom:0}
    .ct-saving button[type="submit"]{pointer-events:none}
    .ct-keybox-summary{margin-top:8px;color:#999;font-size:.84em;line-height:1.4}
    .ct-package-picker{position:relative}.ct-package-suggestions{position:absolute;z-index:1300;left:0;right:0;top:calc(100% + 4px);max-height:min(42dvh,320px);overflow:auto;border:1px solid var(--border);border-radius:14px;background:#181818;box-shadow:0 10px 28px rgba(0,0,0,.45);padding:6px}.ct-package-suggestions[hidden]{display:none!important}.ct-package-option{display:flex;align-items:center;gap:12px;width:100%;min-height:68px;padding:12px 16px;border:0;border-radius:10px;background:transparent;color:var(--fg);text-align:left;text-transform:none;letter-spacing:0;overflow-wrap:anywhere;cursor:pointer}.ct-package-option:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}.ct-package-option:focus,.ct-package-option:hover,.ct-package-option[aria-selected="true"]{background:rgba(255,255,255,.06)}.ct-pkg-empty{padding:12px 16px;font-size:.85em;color:var(--text-muted);text-align:center}
    input[type="checkbox"].ct-switch{appearance:none!important;-webkit-appearance:none!important;width:48px!important;height:28px!important;min-width:48px!important;min-height:28px!important;padding:0!important;margin:0!important;border:1px solid #4a4d52!important;border-radius:999px!important;background:#292b2f!important;box-sizing:border-box!important;position:relative!important;cursor:pointer!important;transition:background .18s ease,border-color .18s ease!important;flex:0 0 48px!important}
    input[type="checkbox"].ct-switch::after{content:''!important;position:absolute!important;width:22px!important;height:22px!important;left:2px!important;top:2px!important;border-radius:50%!important;background:#f4f4f5!important;box-shadow:0 1px 4px rgba(0,0,0,.45)!important;transform:translateX(0)!important;transition:transform .18s cubic-bezier(.22,.8,.25,1),background .18s ease!important}
    input[type="checkbox"].ct-switch:checked{background:var(--success,#30d158)!important;border-color:var(--success,#30d158)!important}
    input[type="checkbox"].ct-switch:checked::after{transform:translateX(20px)!important;background:#ffffff!important}
    input[type="checkbox"].ct-switch.pending-reboot,input[type="checkbox"].toggle.pending-reboot{background:#854d0e!important;border-color:#eab308!important;box-shadow:none!important}
    input[type="checkbox"].ct-switch.pending-reboot:checked,input[type="checkbox"].toggle.pending-reboot:checked{background:#d97706!important;border-color:#fbbf24!important;box-shadow:none!important}
    input[type="checkbox"].ct-switch.pending-reboot:checked::after{transform:translateX(20px)!important;background:#ffffff!important}
    input[type="checkbox"].ct-switch:focus-visible{outline:2px solid var(--accent)!important;outline-offset:3px!important}
    input[type="checkbox"].ct-switch:disabled{opacity:.5!important;cursor:not-allowed!important}
    #dashboard,#info,#spoof,#patch,#profiles,#effective,#apps,#diagnostics{padding-bottom:max(120px,calc(78px + env(safe-area-inset-bottom)))!important}
    @media(max-width:640px){.ct-choice-grid{grid-template-columns:1fr}.ct-action-grid{grid-template-columns:1fr!important}.identity-actions{display:grid!important;grid-template-columns:1fr!important;width:100%}.identity-actions>button{width:100%!important;min-width:0!important;white-space:normal}.grid-2{grid-template-columns:1fr!important}.panel{padding:16px}.ct-profile-item{align-items:flex-start;flex-wrap:wrap}.ct-profile-item button{width:100%}}
  .ct-identity-scope-app{border-left:3px solid var(--accent);border-radius:14px;padding:14px 16px;line-height:1.55;background:var(--input-bg)}.ct-identity-scope-app strong{display:block;margin-bottom:8px}.ct-zygisk-warning{color:var(--text-muted);background:var(--input-bg);border-left:3px solid var(--accent);padding:10px 12px;border-radius:10px;margin:10px 0 14px}.ct-global-identity-warning{padding:12px 14px;margin:4px 0 16px;border:1px solid var(--warning);border-radius:12px;background:var(--warning-soft);color:var(--text);font-size:13px;line-height:1.6;overflow-wrap:anywhere}`;document.head.appendChild(style);}function navigateTabs(event){if(event.key!=='ArrowRight'&&event.key!=='ArrowLeft')return;const tabs=document.querySelector('.tabs');const current=event.target&&event.target.closest?event.target.closest('.tab'):null;if(!tabs||!current||!tabs.contains(current))return;const items=[...tabs.querySelectorAll('.tab')].filter(tab=>!tab.hidden&&tab.getAttribute('aria-hidden')!=='true'&&(typeof global.getComputedStyle!=='function'||global.getComputedStyle(tab).display!=='none'));const index=items.indexOf(current);if(index<0||items.length<2)return;event.preventDefault();event.stopImmediatePropagation();const delta=(event.key==='ArrowRight'?1:-1)*(document.documentElement&&document.documentElement.dir==='rtl'?-1:1);const next=items[(index+delta+items.length)%items.length];const id=next.id.replace(/^tab_/,'');if(typeof global.switchTab==='function')global.switchTab(id);if(next.getAttribute('aria-selected')==='true')next.focus();}function installTabNavigationOwner(){const tabs=document.querySelector('.tabs');if(!tabs||tabs.dataset.ctPolicyKeyboardNav==='1')return;tabs.dataset.ctPolicyKeyboardNav='1';tabs.addEventListener('keydown',navigateTabs,true);}function tabIconSvg(id){if(id==='patch'){return'<svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';}if(id==='profiles'){return'<svg class="tab-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';}return'';}function makeTab(id,title,afterId){if(document.getElementById(`tab_${id}`))return;const tabs=document.querySelector('.tabs');const after=document.getElementById(`tab_${afterId}`);if(!tabs)return;const tab=document.createElement('div');tab.className='tab';tab.id=`tab_${id}`;tab.setAttribute('role','tab');tab.setAttribute('tabindex','-1');tab.setAttribute('aria-selected','false');tab.setAttribute('aria-controls',id);const icon=tabIconSvg(id);tab.innerHTML=`${icon}<span class="tab-label">${title}</span>`;tab.onclick=()=>global.switchTab&&global.switchTab(id);if(after&&after.nextSibling)tabs.insertBefore(tab,after.nextSibling);else tabs.appendChild(tab);}function makePage(id,afterId){let page=document.getElementById(id);if(page)return page;page=document.createElement('div');page.id=id;page.className='content';page.setAttribute('role','tabpanel');page.setAttribute('aria-labelledby',`tab_${id}`);const after=document.getElementById(afterId);if(after&&after.nextSibling)after.parentNode.insertBefore(page,after.nextSibling);else document.body.appendChild(page);return page;}function removeLegacySurfaces(){const dashboard=document.getElementById('dashboard');if(dashboard){const statusGrid=dashboard.querySelector('.status-grid');if(statusGrid)statusGrid.remove();const statusEngine=document.getElementById('status_engine');const statusGlobal=document.getElementById('status_global');if(statusEngine&&statusGlobal){const strip=statusEngine.parentElement&&statusEngine.parentElement.parentElement;if(strip&&strip.contains(statusGlobal)&&strip.parentElement===dashboard)strip.remove();} [...dashboard.querySelectorAll('.panel')].forEach(panel=>{const title=(panel.querySelector('h3')?.textContent||'').trim();if(/^System Control$/i.test(title))panel.remove();});} ['spoof_enabled','spoof_build_identity','random_on_boot','spoof_region_cn','telephony','global_mode','rkp_passthrough','drm_passthrough'].forEach(id=>{const node=document.getElementById(id);if(!node)return;const panel=node.closest('.panel');const row=node.closest('.row');if(panel&&/System Control|DRM Passthrough/i.test(panel.textContent||''))panel.remove();else if(row)row.remove();});const spoof=document.getElementById('spoof');if(spoof){[...spoof.querySelectorAll('.panel')].forEach(panel=>{const title=(panel.querySelector('h3')?.textContent||'').trim();if(/^Identity Controls$/i.test(title)&&panel.id!=='ct_identity_controls')panel.remove();});}const stale=document.getElementById('ct_resources_controls');if(stale)stale.remove();}function retireLegacyLocalization(){global.setTimeout(()=>{if(typeof global.loadLanguage==='function')global.loadLanguage=async function(){};if(typeof global.applyTranslations==='function')global.applyTranslations=function(){};},0);}function markIdentityActionGroups(){const spoof=document.getElementById('spoof');if(!spoof)return;const buttons=(typeof spoof.querySelectorAll==='function')?spoof.querySelectorAll('button'):[];buttons.forEach(button=>{const action=typeof button.getAttribute==='function'?button.getAttribute('data-action'):null;const text=(button.textContent||'').trim().toUpperCase();if(action==='auto-identity'||action==='randomize-all'||action==='apply-identity'||action==='clear-all'||text.includes('AUTO IDENTITY')||text.includes('RANDOMIZE ALL')||text==='APPLY IDENTITY'||text==='CLEAR ALL'){const parent=button.parentElement;if(parent&&parent.children&&parent.children.length>=2)parent.classList.add('ct-action-grid');}});}function getPendingRebootSettings(){try{const raw=typeof sessionStorage!=='undefined'&&sessionStorage.getItem('ct_pending_reboot');const parsed=raw?JSON.parse(raw):[];return new Set(Array.isArray(parsed)?parsed.filter(value=>typeof value==='string'):[]);}catch(e){return new Set();}}function writePendingRebootSettings(pending){if(typeof sessionStorage!=='undefined'){sessionStorage.setItem('ct_pending_reboot',JSON.stringify([...pending]));}}function markPendingReboot(setting){try{const pending=getPendingRebootSettings();pending.add(setting);writePendingRebootSettings(pending);}catch(e){}}function clearPendingReboot(setting){try{const pending=getPendingRebootSettings();pending.delete(setting);writePendingRebootSettings(pending);}catch(e){}}function isPendingReboot(setting){return getPendingRebootSettings().has(setting);}function refreshZygiskStatus(){if(typeof bridge.getZygiskStatus!=='function')return;const update=available=>{const next=typeof available==='boolean'?available:null;if(next===zygiskAvailable)return;zygiskAvailable=next;if(policyState){renderFeatureCenter();renderIdentityScopeBanner();}};bridge.getZygiskStatus().then(update).catch(()=>update(null));}function policyIdentityEnabled(){const view=policyViewState();if(!view||!view.features)return false;return FEATURE_KEYS.some(([key])=>Boolean(view.features[key]))||Boolean(view.features.securityPatch);}function identityEnabled(){const view=policyViewState();return policyIdentityEnabled()||Boolean(view&&(view.profiles||[]).some(profile=>profile.enabled!==false&&profile.features&&profile.features.securityPatch===true))||legacyToggleValue('camera_visibility');}function escapeAttr(s){return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}function helpMarkup(text){return`<details class="ct-help"><summary data-i18n="What does this do?">What does this do?</summary><p data-i18n="${escapeAttr(text)}">${escapeHtml(text)}</p></details>`;}function policyFeatureFromMarkup(extra){const match=String(extra||'').match(/data-policy-feature="([^"]+)"/);return match?match[1]:'';}function switchMarkup(id,checked,extra){const extraAttr=extra||'';const feature=policyFeatureFromMarkup(extraAttr);const pendingKey=feature?`feature:${feature}`:'';const isPending=Boolean((pendingKey&&isPendingReboot(pendingKey)));const pendingAttr=isPending?'data-pending-reboot="true"':'';if(extraAttr.includes('class="')){return`<input id="${id}" type="checkbox" ${extraAttr.replace('class="', `class="${isPending ? 'pending-reboot ' : ''}`)} ${pendingAttr} ${checked ? 'checked' : ''}>`;}if(isPending){return`<input id="${id}" type="checkbox" class="ct-switch pending-reboot" ${extraAttr} ${pendingAttr} ${checked ? 'checked' : ''}>`;}return`<input id="${id}" type="checkbox" class="ct-switch" ${extraAttr} ${checked ? 'checked' : ''}>`;}function cardMarkup(id,title,description,checked,children){return`<div class="ct-feature-card"><div class="row"><label for="${id}" style="flex:1 1 220px;min-width:0;padding-right:12px"><strong>${escapeHtml(title)}</strong><span class="res-desc">${escapeHtml(description)}</span></label>${switchMarkup(id,checked)}</div>${children || ''}</div>`;}function defaultPatch(){return{automaticThresholdMonths:6,system:{mode:'device_default'},vendor:{mode:'device_default'},boot:{mode:'device_default'}};}function isAutoPatch(){if(!policyState||!policyState.securityPatch)return false;return PATCH_COMPONENTS.every(([key])=>policyState.securityPatch[key]&&policyState.securityPatch[key].mode==='automatic');}function buildFeatureCenterMarkup(prefix){const view=policyViewState();const globalKeyboxOn=legacyToggleValue('global_mode');const keyboxOn=legacyToggleValue('auto_keybox_check');const blockInvalidOn=legacyToggleValue('block_invalid_keyboxes',view?view.blockInvalidKeyboxes:true);const drmOn=legacyToggleValue('drm_passthrough');const identityCards=identityFeatureCardsMarkup(`${prefix}_identity`);const drmHelp=helpMarkup("DRM App Passthrough keeps configured packages on Android's genuine Keystore path. It does not fake a DRM security level; use Profiles > Privacy > Isolate for app-scoped DRM device identifiers.");const drmChildren=`<div class="ct-subcontrols" id="${prefix}_drm_children"><strong>DRM Identifier Privacy</strong><p>Profile privacy Isolate replaces only DRM deviceUniqueId with a stable app-scoped pseudonymous ID. Licenses, provisioning and security level stay on Android's genuine DRM path.</p>${helpMarkup('Use Profiles > Privacy > Isolate for apps that should not share the genuine DRM device identifier.')}<button type="button" data-open-tab="profiles" style="width:100%;margin-top:10px">Configure Profiles</button></div>`;return`<div class="ct-feature-grid">
    ${cardMarkup(`${prefix}_global`,'Global Keybox','Applies custom Keybox attestation spoofing to all applications without requiring target.txt.',globalKeyboxOn,helpMarkup('Global Keybox is the module-wide attestation scope switch. Recommended ON for normal root usage.'))}
    ${identityCards}
    ${cardMarkup(`${prefix}_block_invalid`,'Block Invalid Keyboxes','Excludes invalid, expired, and revoked keyboxes from the active selection pool. Verification failures are always excluded.',blockInvalidOn,helpMarkup('When enabled, only valid keyboxes are selected. When disabled, expired and revoked keyboxes can participate in selection, but structurally invalid keyboxes remain blocked.') + `<div class="ct-subcontrols" id="${prefix}_block_invalid_children"><div class="row" style="align-items:center"><label for="${prefix}_keybox" style="flex:1 1 220px;min-width:0;padding-right:12px"><strong>Automatic Keybox Check</strong><span class="res-desc">Checks configured keyboxes against the module revocation source when enabled.</span></label>${switchMarkup(`${prefix}_keybox`,keyboxOn)}</div>${helpMarkup('Optional network-backed keybox hygiene; manual management remains available.')}</div>`)}
    ${cardMarkup(`${prefix}_drm_passthrough`,'DRM App Passthrough',"Keeps packages from drm_packages.txt on Android's genuine Keystore path. This does not fake a DRM security level.",drmOn,drmHelp + drmChildren)}
    <div class="ct-feature-card"><strong>Keybox / TEE path</strong><p>Keyboxes are selected per profile or from the stored pool. Stored XML/CBOX sources are reloaded without requiring an environment reset.</p>${helpMarkup('The core Keystore hook remains separate from Identity. Certificate chains are cached to avoid repeated expensive work.')}<button type="button" data-open-tab="keys" style="width:100%;margin-top:10px">Open keyboxes</button></div>
  </div>`;}function refreshDynamicVisibility(){const view=policyViewState();const spoofTab=document.getElementById('tab_spoof');const identityOn=identityEnabled();if(spoofTab&&spoofTab.style){spoofTab.style.display=identityOn?'':'none';const isSpoofActive=(spoofTab.classList&&typeof spoofTab.classList.contains==='function')?spoofTab.classList.contains('active'):String(spoofTab.className||'').includes('active');if(!identityOn&&isSpoofActive){if(typeof global.switchTab==='function')global.switchTab('dashboard');}}const spoofPage=document.getElementById('spoof');if(spoofPage&&view&&view.features){const features=view.features;const cameraOn=legacyToggleValue('camera_visibility');const telephonyOn=Boolean(features.telephonyIdentity);const headers=(typeof spoofPage.querySelectorAll==='function')?(spoofPage.querySelectorAll('.section-header[data-section]')||[]):[];headers.forEach(header=>{if(!header||!header.style)return;const section=header.getAttribute('data-section')||'';if(section==='sim1'||section==='sim2'){header.style.display=telephonyOn?'':'none';const next=header.nextElementSibling;if(next&&next.style){next.style.display=telephonyOn?'':'none';}}else if(section==='telephony'){header.style.display=telephonyOn?'':'none';const next=header.nextElementSibling;if(next&&next.style){next.style.display=telephonyOn?'':'none';const action=next.nextElementSibling;if(action&&action.style){action.style.display=telephonyOn?'':'none';}}}else if(section==='hardware'){header.style.display=cameraOn?'':'none';const next=header.nextElementSibling;if(next&&next.style){next.style.display=cameraOn?'':'none';}}});const kernelPanel=document.getElementById('ct_kernel_identity_panel');if(kernelPanel){const kernelEnabled=document.getElementById('ct_kernel_enabled');const kernelChildren=document.getElementById('ct_kernel_children');if(kernelChildren&&kernelEnabled){kernelChildren.hidden=!kernelEnabled.checked;}}}refreshCustomPropsEditorState();}function syncFeatureCenter(panel,prefix){const view=policyViewState();const host=panel.querySelector('.ct-control-host');if(!host||typeof host.querySelector!=='function')return;const globalToggle=host.querySelector(`#${prefix}_global`);const keyboxToggle=host.querySelector(`#${prefix}_keybox`);const blockInvalidToggle=host.querySelector(`#${prefix}_block_invalid`);const drmToggle=host.querySelector(`#${prefix}_drm_passthrough`);if(globalToggle)globalToggle.checked=legacyToggleValue('global_mode');if(keyboxToggle)keyboxToggle.checked=legacyToggleValue('auto_keybox_check');if(blockInvalidToggle)blockInvalidToggle.checked=legacyToggleValue('block_invalid_keyboxes',view?view.blockInvalidKeyboxes:true);if(drmToggle)drmToggle.checked=legacyToggleValue('drm_passthrough');const identityOn=policyIdentityEnabled();const globalOn=identityOn&&view.globalIdentity!==false;const master=host.querySelector(`#${prefix}_identity_master`);const children=host.querySelector(`#${prefix}_identity_children`);if(master)master.checked=identityOn;if(children)children.hidden=!identityOn;const globalIdentity=host.querySelector(`#${prefix}_identity_global_identity`);if(globalIdentity){globalIdentity.checked=globalOn;globalIdentity.setAttribute('aria-describedby',`${prefix}_identity_global_identity_note${globalOn?` ${prefix}_identity_global_identity_warning`:""}`);}const globalWarning=host.querySelector(`#${prefix}_identity_global_identity_warning`);if(globalWarning)globalWarning.hidden=!globalOn;FEATURE_KEYS.forEach(([key])=>{const sw=host.querySelector(`#${prefix}_identity_${key}`);if(sw)sw.checked=Boolean(view.features&&view.features[key]);});const spoofProps=host.querySelector(`#${prefix}_identity_spoof_props`);if(spoofProps){spoofProps.checked=view.spoofProps!==false;spoofProps.disabled=!view.features.buildIdentity;}const buildProps=host.querySelector(`#${prefix}_identity_build_props`);if(buildProps)buildProps.hidden=!view.features.buildIdentity;const camera=host.querySelector(`#${prefix}_identity_camera_visibility`);if(camera)camera.checked=legacyToggleValue('camera_visibility');const telScope=host.querySelector(`#${prefix}_identity_telephony_scope`);if(telScope)telScope.hidden=!((view.features&&view.features.telephonyIdentity)||(legacyConfig&&legacyConfig.telephony));const globalTel=host.querySelector(`#${prefix}_identity_global_telephony`);if(globalTel)globalTel.checked=legacyToggleValue('global_telephony_mode');const attScope=host.querySelector(`#${prefix}_identity_attestation_scope`);if(attScope)attScope.hidden=!((view.features&&view.features.attestationIdentity)||(legacyConfig&&legacyConfig.spoof_enabled));const globalAtt=host.querySelector(`#${prefix}_identity_global_attestation`);if(globalAtt)globalAtt.checked=legacyToggleValue('global_attestation_mode');}function renderFeatureCenter(){if(!policyState)return;const panel=document.getElementById('ct_dashboard_controls');if(!panel||typeof panel.querySelector!=='function')return;const host=panel.querySelector('.ct-control-host');if(!host)return;if(typeof host.querySelector!=='function'||!host.querySelector('#ct_dash_identity_master')){host.innerHTML=buildFeatureCenterMarkup('ct_dash');bindFeatureCenter(panel,'ct_dash');}else{syncFeatureCenter(panel,'ct_dash');}refreshDynamicVisibility();const status=document.getElementById('keyboxStatus');if(status&&legacyConfig&&Number.isFinite(Number(legacyConfig.keybox_count)))status.textContent=`${Number(legacyConfig.keybox_count)} Keys Loaded`;}function bindFeatureCenter(panel,prefix){const globalToggle=panel.querySelector(`#${prefix}_global`);const keyboxToggle=panel.querySelector(`#${prefix}_keybox`);const blockInvalidToggle=panel.querySelector(`#${prefix}_block_invalid`);const drmToggle=panel.querySelector(`#${prefix}_drm_passthrough`);if(globalToggle)globalToggle.onchange=()=>setLegacyToggle('global_mode',globalToggle.checked);if(keyboxToggle)keyboxToggle.onchange=()=>setLegacyToggle('auto_keybox_check',keyboxToggle.checked);if(blockInvalidToggle)blockInvalidToggle.onchange=()=>setLegacyToggle('block_invalid_keyboxes',blockInvalidToggle.checked);if(drmToggle)drmToggle.onchange=()=>setLegacyToggle('drm_passthrough',drmToggle.checked);bindIdentityControls(panel,`${prefix}_identity`);panel.querySelectorAll('[data-open-tab]').forEach(button=>{button.onclick=()=>global.switchTab&&global.switchTab(button.dataset.openTab);});}async function performLegacyToggle(setting,enabled){try{const body=new URLSearchParams();body.set('setting',setting);body.set('value',String(Boolean(enabled)));await request('/api/toggle',{method:'POST',body});}catch(error){try{notify(error.message||'Could not update setting','error');}finally{await loadLegacyConfig();}return false;}legacyConfig={...(legacyConfig||{}),[setting]:Boolean(enabled)};if(setting==='block_invalid_keyboxes'&&policyState)policyState.blockInvalidKeyboxes=Boolean(enabled);return true;}
function setLegacyToggle(setting,enabled){const change={enabled:Boolean(enabled)};pendingLegacyToggles.set(setting,change);refreshPolicyControls();return enqueueMutation(async()=>{if(pendingLegacyToggles.get(setting)!==change)return true;try{return await performLegacyToggle(setting,change.enabled);}finally{if(pendingLegacyToggles.get(setting)===change)pendingLegacyToggles.delete(setting);try{refreshPolicyControls();}catch(error){console.error('[CleveresTricky] Toggle view refresh failed',error);}}});}
function installFeatureCenter(){const dashboard=document.getElementById('dashboard');if(!dashboard)return;removeLegacySurfaces();if(!document.getElementById('ct_dashboard_controls')){const panel=document.createElement('div');panel.id='ct_dashboard_controls';panel.className='panel';panel.innerHTML='<h3>Feature Center</h3><div class="scope-note">Main controls are here. Parent features reveal only the settings that belong to them.</div><div class="ct-control-host"></div>';const status=document.getElementById('ct_dashboard_status');if(status)status.insertAdjacentElement('afterend',panel);else dashboard.prepend(panel);}const keysPage=document.getElementById('keys');if(keysPage&&!document.getElementById('keyboxStatus')){const statusPanel=document.createElement('div');statusPanel.id='ct_keybox_status_panel';statusPanel.className='panel';statusPanel.innerHTML='<h3>Keybox Status</h3><div id="keyboxStatus" class="ct-keybox-summary" aria-live="polite">Loading keybox state...</div>';keysPage.prepend(statusPanel);}}function identityProviderWarningMarkup(){const runtime=policyState&&policyState.runtime;if(!runtime||runtime.buildIdentityConflict!==true)return '';const copy=runtime.buildIdentityProviderState==='unavailable'?"Identity provider status could not be verified. Build and Custom property Identity remain paused.":"Build and Custom property Identity are paused because another identity provider is active. Disable that provider and reboot to resume. Other Identity features keep their own scope.";return `<div class="scope-note ct-zygisk-warning" role="status" data-i18n="${escapeHtml(copy)}">${escapeHtml(pickerText(copy,copy))}</div>`;}function identityFeatureCardsMarkup(prefix){const view=policyViewState();const features=view?view.features:{};const identityOn=policyIdentityEnabled();const globalOn=identityOn&&view.globalIdentity!==false;const cameraOn=legacyToggleValue('camera_visibility');const activeProfileName=view&&typeof view.activeProfile==='string'?view.activeProfile.trim().slice(0,64):'';const profileRow=activeProfileName?`<div class="ct-identity-summary"><span>${escapeHtml(pickerText('active_profile', 'Active profile'))}</span><strong>${escapeHtml(activeProfileName)}</strong></div>`:'';const telephonyScopeOn=Boolean((features&&features.telephonyIdentity)||(legacyConfig&&legacyConfig.telephony));const globalScopeTelOn=legacyToggleValue('global_telephony_mode');const telephonyScopeBlock=`<div class="ct-subcontrols" id="${prefix}_telephony_scope" ${telephonyScopeOn ? '' : 'hidden'}><div class="row" style="margin-top:10px"><label for="${prefix}_global_telephony" style="flex:1 1 220px;min-width:0;padding-right:12px"><strong data-i18n="global_telephony_title">${escapeHtml(pickerText('global_telephony_title','Telephony for all targets'))}</strong><span class="res-desc" data-i18n="global_telephony_desc">${escapeHtml(pickerText('global_telephony_desc','Apply telephony overrides to every targeted app. Turn off to limit telephony to explicitly selected targets.'))}</span></label>${switchMarkup(`${prefix}_global_telephony`,globalScopeTelOn)}</div></div>`;const attestationScopeOn=Boolean((features&&features.attestationIdentity)||(legacyConfig&&legacyConfig.spoof_enabled));const globalScopeAttOn=legacyToggleValue('global_attestation_mode');const attestationScopeBlock=`<div class="ct-subcontrols" id="${prefix}_attestation_scope" ${attestationScopeOn ? '' : 'hidden'}><div class="row" style="margin-top:10px"><label for="${prefix}_global_attestation" style="flex:1 1 220px;min-width:0;padding-right:12px"><strong data-i18n="global_attestation_title">${escapeHtml(pickerText('global_attestation_title','Attestation for all targets'))}</strong><span class="res-desc" data-i18n="global_attestation_desc">${escapeHtml(pickerText('global_attestation_desc','Apply attestation identifiers to every targeted app. Turn off to limit attestation to explicitly selected targets.'))}</span></label>${switchMarkup(`${prefix}_global_attestation`,globalScopeAttOn)}</div></div>`;const buildPropsBlock=`<div class="ct-subcontrols" id="${prefix}_build_props" ${features.buildIdentity?'':'hidden'}><div class="row"><label for="${prefix}_spoof_props" style="flex:1 1 220px;min-width:0;padding-right:10px"><strong data-i18n="Build system properties">${escapeHtml(pickerText('Build system properties','Build system properties'))}</strong><span class="res-desc" data-i18n="Turn off to keep the ROM's build properties and change only app-visible Build fields via Zygisk. Attestation Identity is independent.">${escapeHtml(pickerText("Turn off to keep the ROM's build properties and change only app-visible Build fields via Zygisk. Attestation Identity is independent.","Turn off to keep the ROM's build properties and change only app-visible Build fields via Zygisk. Attestation Identity is independent."))}</span></label>${switchMarkup(`${prefix}_spoof_props`,view.spoofProps!==false,features.buildIdentity?'':'disabled')}</div></div>`;const children=FEATURE_KEYS.map(([key,title,desc])=>`<div class="row"><label for="${prefix}_${key}" style="flex:1 1 220px;min-width:0;padding-right:10px"><strong>${escapeHtml(title)}</strong><span class="res-desc">${escapeHtml(desc)}</span></label>${switchMarkup(`${prefix}_${key}`,Boolean(features && features[key]),`data-policy-feature="${key}"`)}</div>${key==='buildIdentity'?buildPropsBlock:''}`).join('');const globalWarning=`<div id="${prefix}_global_identity_warning" class="ct-global-identity-warning" role="note" ${globalOn?'':'hidden'}><span data-i18n="Global Identity changes system-wide properties. It can cause incompatibilities and, on older ROMs, bootloops. Changes may require a reboot. Prefer app-scoped Identity with Zygisk.">Global Identity changes system-wide properties. It can cause incompatibilities and, on older ROMs, bootloops. Changes may require a reboot. Prefer app-scoped Identity with Zygisk.</span></div>`;const zygiskNote=zygiskAvailable===false?`<div id="${prefix}_zygisk_note" class="scope-note ct-zygisk-warning" role="note" data-i18n="Zygisk recommended">Zygisk recommended</div>`:'';const conflictNote=identityProviderWarningMarkup();const core=`<div class="ct-feature-card"><div class="row"><label for="${prefix}_master" style="flex:1 1 220px;min-width:0;padding-right:12px"><strong data-i18n="Identity Engine">Identity Engine</strong><span class="res-desc" data-i18n="All Identity enable/disable controls live on Dashboard. Turn Identity on to reveal its child switches.">All Identity enable/disable controls live on Dashboard. Turn Identity on to reveal its child switches.</span></label>${switchMarkup(`${prefix}_master`,identityOn,`${zygiskAvailable===false?`aria-describedby="${prefix}_zygisk_note"`:''}`)}</div>${zygiskNote}${conflictNote}<div class="ct-subcontrols" id="${prefix}_children" ${identityOn ? '' : 'hidden'}>${profileRow}<div class="row"><label for="${prefix}_global_identity" style="flex:1 1 220px;min-width:0;padding-right:10px"><strong data-i18n="Global Identity">Global Identity</strong><span id="${prefix}_global_identity_note" class="res-desc" data-i18n="Global Identity is optional. Turning it off preserves system-wide Identity properties even without Zygisk.">Global Identity is optional. Turning it off preserves system-wide Identity properties even without Zygisk.</span></label>${switchMarkup(`${prefix}_global_identity`,globalOn,`aria-describedby="${prefix}_global_identity_note${globalOn?` ${prefix}_global_identity_warning`:""}"`)}</div>${globalWarning}${children}${telephonyScopeBlock}${attestationScopeBlock}<button type="button" data-open-tab="spoof" class="primary" style="width:100%;margin-top:10px">Open Identity settings</button></div>${helpMarkup('Turning Identity on enables Build and Attestation Identity. Global Identity starts off. Enable it only if you need device-wide changes.')}</div>`;const camera=cardMarkup(`${prefix}_camera_visibility`,'Camera visibility','Filters camera discovery for selected apps. Disabled means no cameraserver interceptor is started.',cameraOn,helpMarkup('This only reduces discoverable real camera IDs; it does not create cameras or block direct access.'));return`${core}${camera}`;}function identityControlsMarkup(prefix){return`<div class="ct-feature-grid">${identityFeatureCardsMarkup(prefix)}</div>`+systemPropsExplorerMarkup(prefix);}function filterSystemProps(rows,query){const needle=String(query||'').trim().toLowerCase();if(!needle)return rows;return rows.filter((entry)=>String(entry[0]).toLowerCase().includes(needle)||String(entry[1]).toLowerCase().includes(needle));}function systemPropsRowMarkup(key,value){const text=String(value);const short=text.length>48?escapeHtml(text.slice(0,48))+'…':escapeHtml(text);return `<div class="ct-prop-row" data-expanded="false"><code>${escapeHtml(key)}</code><span class="ct-prop-value">${short}</span><span class="ct-prop-full" hidden>${escapeHtml(text)}</span></div>`;}function systemPropsExplorerMarkup(prefix){return `<div class="ct-feature-card"><div class="row"><label for="${prefix}_system_props_load" style="flex:1 1 220px;min-width:0;padding-right:10px"><strong data-i18n="system_props_title">${escapeHtml(pickerText('system_props_title','View system properties'))}</strong><span class="res-desc" data-i18n="system_props_desc">${escapeHtml(pickerText('system_props_desc','Read-only list of Android system properties on this device.'))}</span></label><button id="${prefix}_system_props_load" type="button">${escapeHtml(pickerText('system_props_load','Load system properties'))}</button></div><div id="${prefix}_system_props_body" hidden><div class="row" style="margin-top:10px"><label for="${prefix}_system_props_search" style="flex:1 1 220px;min-width:0;padding-right:10px"><span data-i18n="system_props_search">${escapeHtml(pickerText('system_props_search','Search properties'))}</span></label><input id="${prefix}_system_props_search" autocomplete="off" spellcheck="false"><span id="${prefix}_system_props_count"></span></div><div id="${prefix}_system_props_list"></div><span id="${prefix}_system_props_empty" class="res-desc" data-i18n="system_props_empty">${escapeHtml(pickerText('system_props_empty','No properties match the search.'))}</span></div></div>`;}function bindSystemPropsExplorer(panel,prefix){const load=panel.querySelector(`#${prefix}_system_props_load`);const body=panel.querySelector(`#${prefix}_system_props_body`);const search=panel.querySelector(`#${prefix}_system_props_search`);const list=panel.querySelector(`#${prefix}_system_props_list`);const count=panel.querySelector(`#${prefix}_system_props_count`);const empty=panel.querySelector(`#${prefix}_system_props_empty`);if(!load||!body||!search||!list)return;let rows=[];const render=()=>{const filtered=filterSystemProps(rows,search.value);list.innerHTML=filtered.map(([key,value])=>systemPropsRowMarkup(key,value)).join('');if(count)count.textContent=`${filtered.length} / ${rows.length}`;if(empty)empty.hidden=filtered.length>0;};list.onclick=(event)=>{const row=event.target&&event.target.closest?event.target.closest('.ct-prop-row'):null;if(!row)return;const full=row.querySelector('.ct-prop-full');const expanded=row.getAttribute('data-expanded')==='true';row.setAttribute('data-expanded',expanded?'false':'true');if(full)full.hidden=expanded;};load.onclick=()=>{request('/api/system_props').then((json)=>{const props=json&&json.props?json.props:{};rows=Object.entries(props);body.hidden=false;render();}).catch((error)=>{notify(error.message||'Could not load system properties','error');});};search.oninput=()=>{render();};}function bindIdentityControls(panel,prefix){const buildProps=panel.querySelector(`#${prefix}_spoof_props`);if(buildProps){buildProps.disabled=!policyState.features.buildIdentity;buildProps.onchange=()=>{const view=policyViewState();if(!view.features.buildIdentity){buildProps.checked=view.spoofProps!==false;return;}const enabled=buildProps.checked;return setPolicyToggle('spoofProps',next=>{next.spoofProps=enabled;},pickerText('Build property spoofing updated','Build property spoofing updated'));};}const globalIdentity=panel.querySelector(`#${prefix}_global_identity`);if(globalIdentity){globalIdentity.disabled=false;globalIdentity.onchange=()=>{const enabled=globalIdentity.checked;return setPolicyToggle('globalIdentity',next=>{next.globalIdentity=enabled;},pickerText('Global Identity updated','Global Identity updated'));};}const master=panel.querySelector(`#${prefix}_master`);const children=panel.querySelector(`#${prefix}_children`);const cameraToggle=panel.querySelector(`#${prefix}_camera_visibility`);if(cameraToggle)cameraToggle.onchange=()=>setLegacyToggle('camera_visibility',cameraToggle.checked);const telephonyScopeToggle=panel.querySelector(`#${prefix}_global_telephony`);if(telephonyScopeToggle)telephonyScopeToggle.onchange=()=>setLegacyToggle('global_telephony_mode',telephonyScopeToggle.checked);const attestationScopeToggle=panel.querySelector(`#${prefix}_global_attestation`);if(attestationScopeToggle)attestationScopeToggle.onchange=()=>setLegacyToggle('global_attestation_mode',attestationScopeToggle.checked);if(master)master.onchange=()=>{const enabled=master.checked;if(children)children.hidden=!enabled;if(globalIdentity)globalIdentity.checked=false;return setPolicyToggle('identityMaster',next=>{if(enabled)next.globalIdentity=false;const safeDefaults=new Set(['buildIdentity','attestationIdentity']);FEATURE_KEYS.forEach(([key])=>{next.features[key]=enabled&&safeDefaults.has(key);});if(!enabled)next.features.securityPatch=false;},enabled?'Identity enabled':'Identity disabled');};panel.querySelectorAll('[data-policy-feature]').forEach(toggle=>{toggle.onchange=()=>{const key=toggle.dataset.policyFeature;const enabled=toggle.checked;return setPolicyToggle(key,next=>{next.features[key]=enabled;},`${toggle.closest('.row').querySelector('strong').textContent} updated`);};});bindSystemPropsExplorer(panel,prefix);}function installIdentityControls(){const stale=document.getElementById('ct_identity_controls');if(stale)stale.remove();}function renderIdentityControls(){installIdentityControls();}function installIdentityBanner(){const stale=document.getElementById('ct_identity_disabled_banner');if(stale)stale.remove();}function validateCustomPropsText(text){const value=String(text||'');if(new TextEncoder().encode(value).length>64*1024)throw new Error('Custom properties are too large');let count=0;value.split(/\r?\n/).forEach((raw,index)=>{const line=raw.trim();if(!line||line.startsWith('#'))return;if(++count>256)throw new Error('Use no more than 256 custom properties');const separator=line.indexOf('=');if(separator<=0)throw new Error('Line '+(index+1)+' must use KEY=VALUE');const name=line.slice(0,separator).trim();const propValue=line.slice(separator+1).trim();if(name.length<1||name.length>127||name.startsWith('.')||name.endsWith('.')||name.includes('..')||name.startsWith('ctl.')||!/^[A-Za-z0-9._:@-]+$/.test(name))throw new Error('Line '+(index+1)+' has an invalid property name');if(!propValue||propValue.length>91||/[^\x20-\x7e]/.test(propValue))throw new Error('Line '+(index+1)+' has an invalid value');});return count;}function refreshCustomPropsEditorState(){const panel=document.getElementById('ct_custom_props_panel');if(!panel)return;const enabled=Boolean(policyState&&policyState.features&&policyState.features.customProps);const status=document.getElementById('ct_custom_props_status');if(status){status.className='ct-badge '+(enabled?'ct-badge-valid':'ct-badge-unknown');status.textContent=enabled?'Enabled':'Disabled';}const hint=document.getElementById('ct_custom_props_state_hint');if(hint)hint.textContent=enabled?'Saved changes apply after restart.':'Enable Custom properties on Dashboard to apply saved values.';}function installCustomPropsEditor(){const spoof=document.getElementById('spoof');if(!spoof||document.getElementById('ct_custom_props_panel'))return;const identityTitle=document.getElementById('ct_identity_manager_title');const identityPanel=identityTitle?identityTitle.closest('.panel'):null;if(!identityPanel)return;const panel=document.createElement('div');panel.id='ct_custom_props_panel';panel.className='panel';panel.innerHTML='<h3>Custom Properties</h3><div class="scope-note">Use one KEY=VALUE line per property. Save, then restart.</div><div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><span id="ct_custom_props_status" class="ct-badge ct-badge-unknown">Disabled</span><span id="ct_custom_props_state_hint" class="res-desc" style="margin:0"></span></div><label for="ct_custom_props_editor">Custom Properties</label><textarea id="ct_custom_props_editor" rows="8" maxlength="65536" placeholder="persist.example=value" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="off" style="font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace"></textarea><div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;flex-wrap:wrap"><span id="ct_custom_props_count" class="res-desc" style="margin:0">Loading...</span><button id="ct_custom_props_save" type="button" class="primary" disabled>Save Properties</button></div>';identityPanel.insertAdjacentElement('afterend',panel);const editor=panel.querySelector('#ct_custom_props_editor');const count=panel.querySelector('#ct_custom_props_count');const save=panel.querySelector('#ct_custom_props_save');editor.disabled=true;let saving=false;let loaded=false;let initialValue='';const updateState=()=>{let valid=true;try{const total=validateCustomPropsText(editor.value);count.textContent=total===1?'1 property':total+' properties';count.style.color='';}catch(error){valid=false;count.textContent=error.message||'Invalid properties';count.style.color='var(--danger)';}save.disabled=!loaded||saving||!valid||editor.value===initialValue;};editor.addEventListener('input',updateState);const fetcher=typeof global.fetchAuth==='function'?global.fetchAuth:bridge.fetch;fetcher('/api/file?filename=custom_props').then(async response=>{if(response.ok){initialValue=await response.text();editor.value=initialValue;loaded=true;editor.disabled=false;updateState();return;}if(response.status===404){initialValue='';editor.value='';loaded=true;editor.disabled=false;updateState();return;}const message=await response.text().catch(()=>'');throw new Error(message||'Could not load custom properties');}).catch(error=>{loaded=false;save.disabled=true;count.textContent='Could not load properties';count.style.color='var(--danger)';notify(error.message||'Could not load custom properties','error');});save.onclick=async()=>{if(!loaded||saving||save.disabled)return;const content=editor.value;saving=true;editor.disabled=true;updateState();try{validateCustomPropsText(content);const body=new URLSearchParams();body.set('filename','custom_props');body.set('content',content);await request('/api/save',{method:'POST',body});initialValue=content;}catch(error){notify(error.message||'Could not save custom properties','error');return;}finally{saving=false;editor.disabled=false;updateState();}const enabled=Boolean(policyState&&policyState.features&&policyState.features.customProps);try{if(enabled)markPendingReboot('feature:customProps');refreshCustomPropsEditorState();}catch(error){console.error('[CleveresTricky] Custom properties saved, but status refresh failed',error);}notify(enabled?'Custom properties saved. Restart to apply.':'Custom properties saved. Enable them on Dashboard when ready.');};refreshCustomPropsEditorState();}function installConfigurationActions(){const dashboard=document.getElementById('dashboard');if(!dashboard||document.getElementById('ct_restore_defaults'))return;const panel=document.getElementById('ct_config_management')||document.getElementById('backupPw')?.closest('.panel');if(!panel)return;const note=document.createElement('div');note.className='scope-note';note.style.marginTop='12px';note.textContent='Restores module settings using the built-in default profile and removes configured remote servers. Stored keyboxes and encrypted backups are not deleted.';const button=document.createElement('button');button.id='ct_restore_defaults';button.type='button';button.className='danger';button.style.width='100%';button.textContent='Restore Defaults';button.onclick=async()=>{if(global.confirm&&!global.confirm('Restore module settings to defaults?'))return;const original=button.textContent;button.disabled=true;button.textContent='Restoring...';try{const body=new URLSearchParams();body.set('profile','default');await request('/api/apply_profile',{method:'POST',body});}catch(error){notify(error.message||'Could not restore defaults','error');button.disabled=false;button.textContent=original;return;}notify('Default settings restored');try{await request('/api/reload',{method:'POST'});}catch(error){console.error('[CleveresTricky] Defaults restored, but reload failed',error);}global.setTimeout(()=>global.location.reload(),600);};panel.append(note,button);}const BUILT_IN_TEMPLATE_IDS=new Set(['pixel9proxl','pixel8pro','pixel8','pixel7pro','pixel6pro','pixel6a','pixel6a_beta','pixel9a_beta','s24ultra','s23ultra','xiaomi14','oneplus11','nothing2','pixel9','s24','s23','a54','xiaomi14pro','oneplus12','nothing1','motoedge40pro','sonyxperia1v','asusrog8']);const CUSTOM_TEMPLATE_FIELDS=[['id','Template ID'],['manufacturer','Manufacturer'],['model','Model'],['fingerprint','Fingerprint'],['brand','Brand'],['product','Product'],['device','Device'],['release','Android release'],['buildId','Build ID'],['incremental','Incremental'],['type','Build type'],['tags','Build tags'],['securityPatch','Security patch']];function installCustomTemplateBuilder(){const spoof=document.getElementById('spoof');if(!spoof||document.getElementById('ct_custom_template_panel'))return;const identityTitle=document.getElementById('ct_identity_manager_title');const identityPanel=identityTitle?identityTitle.closest('.panel'):null;if(!identityPanel)return;const panel=document.createElement('div');panel.id='ct_custom_template_panel';panel.className='panel ct-settings-panel';const fields=CUSTOM_TEMPLATE_FIELDS.map(([key,label])=>{const value=key==='type'?'user':(key==='tags'?'release-keys':'');return`<div><label for="ct_template_${key}">${escapeHtml(label)}</label><input id="ct_template_${key}" type="text" maxlength="512" value="${escapeHtml(value)}" autocomplete="off" spellcheck="false"></div>`;}).join('');panel.innerHTML=`<details id="ct_custom_template_details"><summary class="ct-disclosure-row"><span class="ct-disclosure-copy"><strong>Custom Templates</strong></span><span class="ct-disclosure-chevron" aria-hidden="true"></span></summary><div class="ct-settings-body"><div class="scope-note" style="margin-top:0">Create a reusable device identity template. The form stays collapsed until you open it.</div><div class="ct-choice-grid">${fields}</div><button id="ct_template_save" type="button" class="primary" style="width:100%;margin-top:14px">Save custom template</button></div></details>`;const customPropsPanel=document.getElementById('ct_custom_props_panel');(customPropsPanel||identityPanel).insertAdjacentElement('afterend',panel);panel.querySelector('#ct_template_save').onclick=async function(){if(this.disabled)return;this.disabled=true;try{await saveCustomTemplate();}catch(error){notify(error.message||'Could not save custom template','error');}finally{this.disabled=false;}};}async function saveCustomTemplate(){const template={};for(const[key]of CUSTOM_TEMPLATE_FIELDS){const input=document.getElementById(`ct_template_${key}`);template[key]=input?input.value.trim():'';}template.id=template.id.toLowerCase();if(!/^[a-z0-9_-]{1,64}$/.test(template.id))throw new Error('Template ID is invalid');if(BUILT_IN_TEMPLATE_IDS.has(template.id))throw new Error('Built-in template IDs cannot be replaced');if(Object.entries(template).some(([key,value])=>key!=='id'&&(!value||value.length>512||/[\u0000-\u001f\u007f]/.test(value))))throw new Error('All template fields are required');if(!/^\d{4}-\d{2}-\d{2}$/.test(template.securityPatch))throw new Error('Security patch must be YYYY-MM-DD');const currentResponse=await bridge.fetch('/api/file?filename=templates.json');if(!currentResponse.ok)throw new Error('Template catalog is unavailable');const catalogText=(await currentResponse.text()).trim();let current;if(!catalogText){current=[];}else{try{current=JSON.parse(catalogText);}catch(_){throw new Error('Template catalog is unavailable');}}if(!Array.isArray(current))throw new Error('Template catalog is unavailable');const next=current.filter(item=>String(item&&item.id||'').toLowerCase()!==template.id);next.push(template);const body=new URLSearchParams();body.set('filename','templates.json');body.set('content',JSON.stringify(next,null,2));const save=await bridge.fetch('/api/save',{method:'POST',body});if(!save.ok)throw new Error((await save.text())||'Could not save custom template');await loadReferenceData();notify('Custom template saved');global.setTimeout(()=>global.location.reload(),500);}function installKernelIdentityControls(){const spoof=document.getElementById('spoof');if(!spoof||document.getElementById('ct_kernel_identity_panel'))return;const panel=document.createElement('div');panel.id='ct_kernel_identity_panel';panel.className='panel ct-settings-panel';panel.innerHTML=`<details id="ct_kernel_identity_details"><summary class="ct-disclosure-row"><span class="ct-disclosure-copy"><strong>Kernel Identity</strong></span><span class="ct-disclosure-chevron" aria-hidden="true"></span></summary><div class="ct-settings-body"><div class="scope-note" style="margin-top:0">Optionally overrides uname release/version inside the injected Keystore runtime. Official GKI presets use published base kernel versions and remain editable.</div><div class="row"><label for="ct_kernel_enabled" style="flex:1"><strong>Hook kernel name</strong><span class="res-desc">Disabled by default. Core Binder protection is independent from this option.</span></label>${switchMarkup('ct_kernel_enabled',false)}</div><div id="ct_kernel_children" hidden><label for="ct_kernel_preset">GKI preset</label><select id="ct_kernel_preset"></select><div class="ct-choice-grid" style="margin-top:10px"><div><label for="ct_kernel_release">uname release</label><input id="ct_kernel_release" type="text" maxlength="64" autocomplete="off" spellcheck="false"></div><div><label for="ct_kernel_version">uname version</label><input id="ct_kernel_version" type="text" maxlength="64" autocomplete="off" spellcheck="false"></div></div></div><button id="ct_kernel_save" class="primary" type="button" style="width:100%;margin-top:12px">Save kernel identity</button></div></details>`;const customPanel=document.getElementById('ct_custom_template_panel');if(customPanel)customPanel.insertAdjacentElement('afterend',panel);else spoof.append(panel);loadKernelIdentity().catch(error=>notify(error.message||'Could not load kernel identity','error'));}async function loadKernelIdentity(){const state=await request('/api/kernel_identity');const enabled=document.getElementById('ct_kernel_enabled');const children=document.getElementById('ct_kernel_children');const preset=document.getElementById('ct_kernel_preset');const release=document.getElementById('ct_kernel_release');const version=document.getElementById('ct_kernel_version');if(!enabled||!children||!preset||!release||!version)return;preset.innerHTML='<option value="custom">Custom</option>'+(state.presets||[]).map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(item.label)}</option>`).join('');enabled.checked=Boolean(state.enabled);children.hidden=!enabled.checked;preset.value=state.preset||'custom';release.value=state.release||'';version.value=state.version||'';enabled.onchange=()=>{children.hidden=!enabled.checked;};preset.onchange=()=>{const selected=(state.presets||[]).find(item=>item.id===preset.value);if(selected){release.value=selected.release;version.value=selected.version;}};const saveButton=document.getElementById('ct_kernel_save');saveButton.onclick=async()=>{if(saveButton.disabled)return;saveButton.disabled=true;try{const payload={enabled:enabled.checked,preset:preset.value,release:release.value.trim(),version:version.value.trim()};const body=new URLSearchParams();body.set('data',JSON.stringify(payload));const result=await request('/api/kernel_identity',{method:'POST',body});notify(result.applied?'Kernel identity applied':'Kernel identity saved for next native activation');}catch(error){notify(error.message||'Could not save kernel identity','error');}finally{saveButton.disabled=false;}};}function installAppsProfileCard(){const apps=document.getElementById('apps');if(!apps||document.getElementById('ct_apps_profiles_card'))return;const panel=document.createElement('div');panel.id='ct_apps_profiles_card';panel.className='panel';panel.innerHTML='<h3>Profiles</h3><div class="scope-note">Use Profiles for app assignments, identity template, custom keybox, DRM identifier privacy, per-feature overrides and per-app Security Patch rules in one place.</div><button type="button" class="primary" style="width:100%">Open Profiles</button>';panel.querySelector('button').onclick=()=>global.switchTab&&global.switchTab('profiles');apps.prepend(panel);}function staticPages(){const tabs=document.querySelector('.tabs');const dashboardTab=document.getElementById('tab_dashboard');const keyboxTab=document.getElementById('tab_keys');if(tabs&&dashboardTab&&keyboxTab&&dashboardTab.nextElementSibling!==keyboxTab)tabs.insertBefore(keyboxTab,dashboardTab.nextSibling);const staleEffectiveTab=document.getElementById('tab_effective');if(staleEffectiveTab)staleEffectiveTab.remove();makeTab('profiles','Profiles','spoof');const spoofPage=document.getElementById('spoof');let banner=document.getElementById('ct_identity_scope_banner');if(!banner&&spoofPage){banner=document.createElement('div');banner.id='ct_identity_scope_banner';spoofPage.prepend(banner);}const stalePatchTab=document.getElementById('tab_patch');if(stalePatchTab)stalePatchTab.remove();const stalePatchPage=document.getElementById('patch');if(stalePatchPage)stalePatchPage.remove();const stalePatchCard=document.getElementById('ct_identity_patch');if(stalePatchCard)stalePatchCard.remove();const profilesPage=makePage('profiles','spoof');if(!profilesPage.innerHTML){profilesPage.innerHTML=`<div class="panel"><h3>Profiles</h3><div class="scope-note">App-centric configuration. Assign installed apps or wildcards, then choose privacy, identity, keybox and feature overrides.</div><div class="ct-toolbar"><button id="ct_profile_new" type="button" class="primary">New profile</button><button id="ct_profile_export" type="button">Export</button><button id="ct_profile_import" type="button">Import</button><input id="ct_profile_import_file" type="file" accept="application/json,.json" hidden></div><div id="ct_profile_list" style="margin-top:12px"></div></div><div class="panel" id="ct_profile_editor_panel" hidden><fieldset id="ct_profile_editor_fields" style="min-width:0;border:0;padding:0;margin:0"><h3>Profile Editor</h3><div class="ct-choice-grid"><div><label for="ct_profile_name">Name</label><input id="ct_profile_name" type="text" maxlength="64"></div><div><label for="ct_profile_privacy">DRM / privacy mode</label><select id="ct_profile_privacy"><option value="inherit">Inherit</option><option value="isolate">Isolate - app-scoped pseudonymous DRM ID</option><option value="redact">Redact</option></select></div></div><div style="margin-top:12px"><label for="ct_profile_app_picker">Add installed app</label><div class="ct-toolbar"><input id="ct_profile_app_picker" type="search" maxlength="16384" placeholder="com.example.app" autocomplete="off"><button id="ct_profile_add_app" type="button">Add app</button></div><label for="ct_profile_apps" style="display:block;margin-top:10px">Assignments (one package or wildcard per line)</label><textarea id="ct_profile_apps" rows="4" maxlength="16384" placeholder="com.example.app&#10;com.example.*"></textarea><div id="ct_profile_app_chips" class="ct-chip-wrap"></div></div><div class="ct-choice-grid" style="margin-top:12px"><div><label for="ct_profile_template">Identity template</label><select id="ct_profile_template"><option value="">Inherit / none</option></select></div><div><label for="ct_profile_keybox">Keybox</label><select id="ct_profile_keybox"><option value="">Inherit / none</option></select></div></div><div class="section-header">Feature overrides</div><div id="ct_profile_features"></div><div class="ct-toolbar" style="margin-top:16px"><button id="ct_profile_save" type="button" class="primary">Save profile</button><button id="ct_profile_clone" type="button">Clone</button><button id="ct_profile_delete" type="button" class="danger">Delete</button></div></fieldset></div>`;}const appsPage=document.getElementById('apps');let effective=document.getElementById('ct_effective_apps_host');if(appsPage&&!effective){effective=document.createElement('div');effective.id='ct_effective_apps_host';appsPage.appendChild(effective);}if(effective)effective.innerHTML='<div class="panel"><h3>Effective State</h3><div class="scope-note">Inspect the exact resolver output for an installed application without exposing private key material.</div><label for="ct_effective_package">Package to inspect</label><input id="ct_effective_package" type="search" placeholder="com.example.app" autocomplete="off"><button id="ct_effective_load" class="primary" type="button" style="width:100%;margin-top:10px">Inspect</button></div><div class="panel"><h3>Resolved Configuration</h3><div id="ct_effective_result" class="scope-note">Select an app.</div></div>';}function renderIdentityScopeBanner(){const view=policyViewState();const banner=document.getElementById('ct_identity_scope_banner');if(!banner)return;const identityOn=policyIdentityEnabled();if(!identityOn){banner.innerHTML=`<div class="scope-note" style="border-left:4px solid #ef4444;background:rgba(239,68,68,0.1);padding:12px 14px;margin-bottom:14px;border-radius:6px;"><strong style="color:#ef4444;font-size:1.05em;">Identity: Disabled</strong><div style="margin-top:4px;color:#bbb">Optional Identity is disabled on Dashboard. Core module behavior is independent.</div></div>`;}else if(view&&view.globalIdentity===false){banner.innerHTML=`<div class="scope-note ct-identity-scope-app"><strong data-i18n="Identity: App-scoped Mode">Identity: App-scoped Mode</strong><div data-i18n="Global Identity properties are off. App-visible Build changes require optional Zygisk; Attestation Identity is independent.">Global Identity properties are off. App-visible Build changes require optional Zygisk; Attestation Identity is independent.</div></div>`;}else{banner.innerHTML=`<div class="scope-note" style="border-left:4px solid #10b981;background:rgba(16,185,129,0.1);padding:12px 14px;margin-bottom:14px;border-radius:6px;"><strong style="color:#34d399;font-size:1.05em;">Identity: Global Mode Active</strong><div style="margin-top:4px;color:#bbb"><span data-i18n="Global Identity is active. Enabled Build and Region properties apply device-wide.">Global Identity is active. Enabled Build and Region properties apply device-wide.</span></div></div>`;}if(identityOn)banner.innerHTML+=identityProviderWarningMarkup();}function patchEditor(prefix,component,title,value,allowInherit){const options=(allowInherit?[['inherit','Inherit']]:[]).concat(PATCH_MODES);const selected=value&&value.mode?value.mode:(allowInherit?'inherit':'device_default');return`<div class="ct-patch-component"><label for="${prefix}_${component}_mode"><strong style="color:#fff">${escapeHtml(title)}</strong></label><select id="${prefix}_${component}_mode">${options.map(([optionValue,label]) => `<option value="${optionValue}" ${optionValue===selected?'selected':''}>${escapeHtml(label)}</option>`).join('')}</select><input id="${prefix}_${component}_value" type="text" maxlength="10" inputmode="numeric" placeholder="YYYY-MM-DD" value="${escapeHtml(value && value.value ? value.value : '')}" style="margin-top:8px;${selected==='manual'?'':'display:none'}"></div>`;}function bindPatchEditor(prefix,component){const select=document.getElementById(`${prefix}_${component}_mode`);const manual=document.getElementById(`${prefix}_${component}_value`);if(!select||!manual)return;select.onchange=()=>{manual.style.display=select.value==='manual'?'block':'none';};}function readPatchEditor(prefix,component,allowInherit){const select=document.getElementById(`${prefix}_${component}_mode`);if(!select)return null;const mode=select.value;if(allowInherit&&mode==='inherit')return null;const result={mode};if(mode==='manual'){const value=document.getElementById(`${prefix}_${component}_value`).value.trim();if(!/^\d{4}-\d{2}-\d{2}$/.test(value))throw new Error(`${component} manual date must be YYYY-MM-DD`);result.value=value;}return result;}function renderPatchPage(){const stale=document.getElementById('ct_identity_patch');if(stale)stale.remove();}async function inspectPatch(){const input=document.getElementById('ct_patch_package');const result=document.getElementById('ct_patch_result');const pkg=input?input.value.trim():'';if(!pkg||!result)return;if(patchInspectionController)patchInspectionController.abort();const controller=new AbortController();patchInspectionController=controller;try{const data=await request(`/api/effective_state?package=${encodeURIComponent(pkg)}`,{signal:controller.signal});if(controller.signal.aborted)return;const patch=data.securityPatch||{};result.innerHTML=PATCH_COMPONENTS.map(([key,title])=>{const item=patch[key]||{};return`<div class="ct-patch-component"><strong>${escapeHtml(title)}</strong><div class="ct-inline-note">Captured: ${escapeHtml(String(item.captured ?? '-'))}<br>Configured: ${escapeHtml(String(item.configured ?? '-'))}<br>Effective: ${escapeHtml(String(item.effective ?? '-'))}</div></div>`;}).join('');}catch(error){if(controller.signal.aborted||(error&&error.name==='AbortError'))return;if(patchInspectionController===controller)result.textContent=error.message||'Could not resolve patch state';}finally{if(patchInspectionController===controller)patchInspectionController=null;}}function renderProfiles(){if(!policyState)return;const list=document.getElementById('ct_profile_list');if(!list)return;const profiles=Array.isArray(policyState.profiles)?policyState.profiles:[];list.innerHTML=profiles.length?profiles.map((profile,index)=>`<div class="ct-profile-item"><div class="ct-profile-copy"><strong translate="no">${escapeHtml(profile.name)}</strong><small><span translate="no">${escapeHtml((profile.applications||[]).join(', '))}</span>${(profile.applications||[]).length?'':'<span>No app assignments</span>'} · <span>Privacy</span>: <span>${escapeHtml({inherit:'Inherit',isolate:'Isolate',redact:'Redact'}[profile.privacy]||'Inherit')}</span></small></div><button type="button" data-edit-profile="${index}">Edit</button></div>`).join(''):'<div class="scope-note">No custom profiles yet.</div>';list.querySelectorAll('[data-edit-profile]').forEach(button=>{button.onclick=()=>openProfile(Number(button.dataset.editProfile));});document.getElementById('ct_profile_new').onclick=()=>openProfile(-1);document.getElementById('ct_profile_export').onclick=exportProfiles;document.getElementById('ct_profile_import').onclick=()=>document.getElementById('ct_profile_import_file').click();document.getElementById('ct_profile_import_file').onchange=importProfiles;}function emptyProfile(){return{name:'',applications:[],template:null,keybox:null,privacy:'inherit',features:{},securityPatch:{},rkpPassthrough:null,drmPassthrough:null};}function fillSelect(select,values,selected,emptyLabel){if(!select)return;select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=emptyLabel;select.appendChild(empty);[...new Set(values)].sort().forEach(value=>{const option=document.createElement('option');option.value=value;option.textContent=value;select.appendChild(option);});select.value=selected;if(selected&&select.value!==selected){const option=document.createElement('option');option.value=selected;option.textContent=`${selected} (current)`;select.appendChild(option);select.value=selected;}}function profileAppsFromEditor(){const source=document.getElementById('ct_profile_apps');return source?[...new Set(source.value.split(/\r?\n/).map(value=>value.trim()).filter(value=>value))]:[];}function renderAppChips(){const host=document.getElementById('ct_profile_app_chips');if(!host)return;const apps=profileAppsFromEditor();host.innerHTML=apps.slice(0,64).map((app,index)=>`<span class="ct-chip">${escapeHtml(app)}<button type="button" data-remove-app="${index}" aria-label="Remove ${escapeHtml(app)}">×</button></span>`).join('');host.querySelectorAll('[data-remove-app]').forEach(button=>{button.onclick=()=>{const next=profileAppsFromEditor();next.splice(Number(button.dataset.removeApp),1);document.getElementById('ct_profile_apps').value=next.join('\n');renderAppChips();};});}function addProfileApp(){const picker=document.getElementById('ct_profile_app_picker');if(!picker)return;const value=picker.value.trim();if(!value)return;const apps=profileAppsFromEditor();if(!apps.includes(value)){if(apps.length>=MAX_PROFILE_APPLICATIONS){notify(`A profile supports at most ${MAX_PROFILE_APPLICATIONS} application assignments`,'error');return;}apps.push(value);}document.getElementById('ct_profile_apps').value=apps.join('\n');picker.value='';renderAppChips();}function boolOrInherit(id){const node=document.getElementById(id);if(!node)return null;return node.value==='inherit'?null:node.value==='true';}function openProfile(index){selectedProfileIndex=index;profileEditorRevision++;const profile=normalizeProfile(index>=0?policyState.profiles[index]:emptyProfile());const panel=document.getElementById('ct_profile_editor_panel');if(!panel)return;panel.hidden=false;document.getElementById('ct_profile_name').value=profile.name;document.getElementById('ct_profile_privacy').value=profile.privacy;document.getElementById('ct_profile_apps').value=profile.applications.join('\n');const templateValues=templates.map(value=>typeof value==='string'?value:(value&&value.id)||'').filter(Boolean);fillSelect(document.getElementById('ct_profile_template'),templateValues,profile.template||'','Inherit / none');fillSelect(document.getElementById('ct_profile_keybox'),keyboxes,profile.keybox||'','Inherit / none');const featureHost=document.getElementById('ct_profile_features');const profileFeatureList=PROFILE_FEATURES.filter(([key])=>key!=='securityPatch');featureHost.innerHTML=profileFeatureList.map(([key,title,desc])=>{const current=typeof profile.features[key]==='boolean'?String(profile.features[key]):'inherit';return`<div class="row"><label for="ct_pf_${key}" style="flex:1 1 220px;min-width:0;padding-right:10px"><strong style="color:#fff">${escapeHtml(title)}</strong><span class="res-desc">${escapeHtml(desc)}</span></label><select id="ct_pf_${key}" style="max-width:180px"><option value="inherit" ${current==='inherit'?'selected':''}>Inherit</option><option value="true" ${current==='true'?'selected':''}>Enabled</option><option value="false" ${current==='false'?'selected':''}>Disabled</option></select></div>`;}).join('');renderAppChips();document.getElementById('ct_profile_add_app').onclick=addProfileApp;document.getElementById('ct_profile_apps').oninput=renderAppChips;document.getElementById('ct_profile_save').onclick=saveProfile;document.getElementById('ct_profile_clone').onclick=cloneProfile;document.getElementById('ct_profile_delete').onclick=deleteProfile;document.getElementById('ct_profile_delete').hidden=index<0;panel.scrollIntoView({behavior:'smooth',block:'start'});}function collectProfile(){const existing=selectedProfileIndex>=0?normalizeProfile(policyState.profiles[selectedProfileIndex]):emptyProfile();const name=document.getElementById('ct_profile_name').value.trim();if(!/^[A-Za-z0-9][A-Za-z0-9 _.-]{0,63}$/.test(name))throw new Error('Profile name is invalid');const applications=profileAppsFromEditor();if(applications.length>MAX_PROFILE_APPLICATIONS){throw new Error(`A profile supports at most ${MAX_PROFILE_APPLICATIONS} application assignments`);}const features={...existing.features};PROFILE_FEATURES.forEach(([key])=>{const value=boolOrInherit(`ct_pf_${key}`);if(value===null)delete features[key];else features[key]=value;});const patch=existing.securityPatch||{};return{name,enabled:existing.enabled,applications,template:document.getElementById('ct_profile_template').value||null,keybox:document.getElementById('ct_profile_keybox').value||null,privacy:document.getElementById('ct_profile_privacy').value,features,securityPatch:patch,rkpPassthrough:existing.rkpPassthrough,drmPassthrough:existing.drmPassthrough};}async function saveProfileChange(mutator,successMessage){
    if(saving)return false;
    const revision=profileEditorRevision;
    const policyRevision=profilePolicyRevision;
    lockProfileEditor();
    try{
        if(!await savePolicy(mutator,successMessage,()=>profilePolicyRevision===policyRevision))return false;
        if(profileEditorRevision===revision){
            selectedProfileIndex=-1;
            const panel=document.getElementById('ct_profile_editor_panel');
            if(panel)panel.hidden=true;
        }
        return true;
    }finally{
        unlockProfileEditor();
    }
}
function saveProfile(){
    let profile;
    try{profile=collectProfile();}catch(error){notify(error.message,'error');return false;}
    const targetName=selectedProfileIndex>=0?policyState.profiles[selectedProfileIndex].name:null;
    if(targetName===null&&Array.isArray(policyState.profiles)&&policyState.profiles.length>=MAX_POLICY_PROFILES){
        notify(`Policy supports at most ${MAX_POLICY_PROFILES} profiles`,'error');
        return false;
    }
    return saveProfileChange(next=>{
        const profiles=Array.isArray(next.profiles)?next.profiles:(next.profiles=[]);
        const index=targetName===null?-1:profileIndexByName(next,targetName);
        if(targetName!==null&&index<0)throw new Error('Could not save policy');
        const conflict=profiles.findIndex((item,itemIndex)=>itemIndex!==index&&String(item.name).toLowerCase()===profile.name.toLowerCase());
        if(conflict>=0)throw new Error('Profile name already exists');
        if(index>=0){
            const current=profiles[index];
            const oldName=current.name;
            profiles[index]={...profile,enabled:current.enabled};
            if(next.activeProfile&&String(next.activeProfile).toLowerCase()===String(oldName).toLowerCase())next.activeProfile=profile.name;
        }else profiles.push(profile);
    },'Profile saved');
}
/** The editor is captured at click time; clone names are reserved against the policy owned by the queued mutation. */
function cloneProfile(){
    let profile;
    try{profile=collectProfile();}catch(error){notify(error.message,'error');return false;}
    if(Array.isArray(policyState.profiles)&&policyState.profiles.length>=MAX_POLICY_PROFILES){
        notify(`Policy supports at most ${MAX_POLICY_PROFILES} profiles`,'error');
        return false;
    }
    const base=profile.name||'Profile';
    profile.applications=[];
    return saveProfileChange(next=>{
        const names=new Set((next.profiles||[]).map(item=>String(item.name).toLowerCase()));
        let name;
        let number=1;
        do{
            const suffix=number===1?' Copy':` Copy ${number}`;
            name=base.slice(0,64-suffix.length).trimEnd()+suffix;
            number++;
        }while(names.has(name.toLowerCase()));
        profile.name=name;
        next.profiles.push(profile);
    },'Profile cloned');
}
function deleteProfile(){
    if(selectedProfileIndex<0)return false;
    const profile=policyState.profiles[selectedProfileIndex];
    const targetName=profile.name;
    if(!global.confirm||global.confirm(`Delete profile "${targetName}"?`)){
        return saveProfileChange(next=>{
            const index=profileIndexByName(next,targetName);
            if(index<0)throw new Error('Could not save policy');
            const removed=next.profiles.splice(index,1)[0];
            if(next.activeProfile&&String(next.activeProfile).toLowerCase()===String(removed.name).toLowerCase())next.activeProfile=null;
        },'Profile deleted');
    }
    return false;
}
async function exportProfiles() {
    const nativeExport = typeof bridge.exportBlob === 'function';
    try {
        const payload = JSON.stringify(stateForSave(policyState), null, 2);
        if (nativeExport) {
            await bridge.exportBlob(new Blob([payload], {type: 'application/json'}), 'cleverestricky-profiles.json');
        } else {
            if (!navigator.clipboard) throw new Error('Profile export is unavailable');
            await navigator.clipboard.writeText(payload);
        }
    } catch (error) {
        console.error('[CleveresTricky] Profile export failed', error);
        notify('Could not export profiles', 'error');
        return false;
    }
    if (!nativeExport) {
        try {
            notify('Profile policy copied/exported');
        } catch (error) {
            console.error('[CleveresTricky] Profiles exported, but notification failed', error);
        }
    }
    return true;
}
async function importProfiles(event){const file=event.target.files&&event.target.files[0];event.target.value='';if(!file)return false;lockProfileEditor();try{return await enqueueMutation(async()=>{let imported;try{if(file.size>512*1024)throw new Error('Policy file is too large');imported=validateImportedPolicy(JSON.parse(await file.text()));}catch(error){notify(error.message||'Could not import profile policy','error');return false;}return performPolicySave(()=>{},'Profile policy imported',renderAll,()=>{profilePolicyRevision++;selectedProfileIndex=-1;profileEditorRevision++;const panel=document.getElementById('ct_profile_editor_panel');if(panel)panel.hidden=true;},imported);});}finally{unlockProfileEditor();}}
async function inspectEffective(){const input=document.getElementById('ct_effective_package');const host=document.getElementById('ct_effective_result');const pkg=input?input.value.trim():'';if(!pkg||!host)return;if(effectiveInspectionController)effectiveInspectionController.abort();const controller=new AbortController();effectiveInspectionController=controller;try{const data=await request(`/api/effective_state?package=${encodeURIComponent(pkg)}`,{signal:controller.signal});if(controller.signal.aborted)return;const rows=[['Scope',data.scope],['Matched profile',data.matchedProfile],['Matched rule',data.matchedApplicationRule],['Identity template',data.identityTemplate],['Keybox',data.keyboxReference],['DRM privacy',data.privacy],['Build identity',data.buildIdentity],['Attestation identity',data.attestationIdentity],['Telephony identity',data.telephonyIdentity],['Region identity',data.regionIdentity],['Identity refresh',data.identityRefresh],['Security Patch',data.securityPatchOverride],['Keystore core',data.keystoreCore],['KeyMint',data.keyMint],['Reboot required',data.rebootRequired]];host.innerHTML=rows.map(([key,value])=>`<div class="row"><span>${escapeHtml(key)}</span><span class="tag">${escapeHtml(String(value ?? '-'))}</span></div>`).join('');}catch(error){if(controller.signal.aborted||(error&&error.name==='AbortError'))return;if(effectiveInspectionController===controller)host.textContent=error.message||'Could not inspect effective state';}finally{if(effectiveInspectionController===controller)effectiveInspectionController=null;}}function parseSavedBuildIdentity(text){const values={};if(typeof text!=='string'||text.length>512*1024)return Object.freeze(values);text.split(/\r?\n/).forEach(rawLine=>{const line=rawLine.trim();if(!line||line.startsWith('#'))return;const separator=line.indexOf('=');if(separator<=0)return;const key=line.slice(0,separator).trim();const value=line.slice(separator+1).trim();if(SAVED_BUILD_IDENTITY_KEYS.has(key)&&value&&value.length<=512&&!/[\u0000-\u001f\u007f]/.test(value)){values[key]=value;}});return Object.freeze(values);}function ensureSavedBuildIdentityView(){const preview=document.getElementById('templatePreview');if(!preview||document.getElementById('ct_saved_build_identity'))return;const host=document.createElement('div');host.id='ct_saved_build_identity';host.style.marginTop='14px';host.style.paddingTop='12px';host.style.borderTop='1px solid var(--border)';const heading=document.createElement('div');heading.className='section-header';heading.textContent='Saved build identity';const grid=document.createElement('div');grid.className='grid-2';SAVED_BUILD_IDENTITY_FIELDS.forEach(([key,label])=>{const item=document.createElement('div');const title=document.createElement('div');title.className='section-header';title.textContent=label;const value=document.createElement('div');value.id=`ct_saved_${key.toLowerCase()}`;value.style.overflowWrap='anywhere';item.append(title,value);grid.appendChild(item);});host.append(heading,grid);preview.appendChild(host);}function renderSavedBuildIdentity(){ensureSavedBuildIdentityView();SAVED_BUILD_IDENTITY_FIELDS.forEach(([key])=>{const node=document.getElementById(`ct_saved_${key.toLowerCase()}`);if(node)node.textContent=savedBuildIdentity[key]||'Not configured';});const select=document.getElementById('templateSelect');const selected=select&&select.selectedOptions&&select.selectedOptions[0];if(selected&&selected.dataset&&selected.dataset.json)return;const model=document.getElementById('pModel');const manufacturer=document.getElementById('pManuf');const fingerprint=document.getElementById('pFing');if(model)model.textContent=savedBuildIdentity.MODEL||'Current device';if(manufacturer)manufacturer.textContent=savedBuildIdentity.MANUFACTURER||'Current device';if(fingerprint)fingerprint.textContent=savedBuildIdentity.FINGERPRINT||'No saved build identity';}async function loadSavedBuildIdentity(){const response=await bridge.fetch('/api/file?filename=spoof_build_vars');if(!response.ok)throw new Error('Saved build identity is unavailable');savedBuildIdentity=parseSavedBuildIdentity(await response.text());renderSavedBuildIdentity();}async function refreshSavedBuildIdentityBestEffort(){
    try{
        await loadSavedBuildIdentity();
        return null;
    }catch(error){
        console.error(error);
        try{renderSavedBuildIdentity();}catch(renderError){console.error(renderError);}
        return error;
    }
}

async function identityPresentation(step){
    try{
        await step();
        return false;
    }catch(error){
        console.error('[CleveresTricky] Identity presentation failed',error);
        return true;
    }
}

async function identityNotice(message,type){
    await identityPresentation(()=>notify(
        typeof bridge.translateExtension==='function'?bridge.translateExtension(message):message,
        type
    ));
}

function renderAutoIdentityPreview(data){
    const fields={pFing:data.fingerprint||'',pModel:String(data.model||'Pixel Beta')+' (Auto Identity)',
        pManuf:data.manufacturer||'Google',pRelease:data.release||'',pPatch:data.security_patch||''};
    Object.entries(fields).forEach(([id,value])=>{
        const node=document.getElementById(id);
        if(node)node.innerText=String(value);
    });
    const template=document.getElementById('templateSelect');
    if(template)template.value='';
    if(typeof bridge.updateIdentityHealthBadge==='function'){
        bridge.updateIdentityHealthBadge(data.degradation,data.servingSource);
    }
}

async function afterIdentitySave(autoIdentity=null){
    let current=null;
    let runtime=null;
    try{
        current=publishPolicyState(await request('/api/policy_state'));
        if(current.features.buildIdentity||current.features.regionIdentity){
            runtime=await bridge.applyIdentityLive();
        }
    }catch(error){
        console.error('[CleveresTricky] Identity saved, but live apply is unavailable',error);
    }

    // Persistence is committed. Every presentation step is isolated from the runtime step above.
    let refreshFailed=false;
    if(autoIdentity&&typeof global.loadIdentity==='function'){
        refreshFailed=await identityPresentation(()=>global.loadIdentity());
    }
    const refreshError=await refreshSavedBuildIdentityBestEffort();
    refreshFailed=Boolean(refreshError)||refreshFailed;
    const pendingFeatures=[];
    if(current&&current.features.buildIdentity&&(!runtime||runtime.rebootRequired))pendingFeatures.push('buildIdentity');
    if(current&&current.features.regionIdentity&&(!runtime||runtime.rebootRequired))pendingFeatures.push('regionIdentity');
    const rebootPending=!current||pendingFeatures.length>0;
    for(const feature of pendingFeatures){
        refreshFailed=await identityPresentation(()=>markPendingReboot('feature:'+feature))||refreshFailed;
    }
    refreshFailed=await identityPresentation(()=>renderFeatureCenter())||refreshFailed;
    if(autoIdentity){
        refreshFailed=await identityPresentation(()=>renderAutoIdentityPreview(autoIdentity))||refreshFailed;
    }
    return {refreshFailed,rebootPending,runtime};
}

function saveIdentity(identity){
    const captured=safeClone(identity);
    return enqueueMutation(async()=>{
        await request('/api/identity',{method:'POST',body:new URLSearchParams({data:JSON.stringify(captured)})});
        const result=await afterIdentitySave();
        await identityNotice('Configuration Saved');
        if(result.refreshFailed){
            await identityNotice('Identity was applied. Warning: the saved identity view could not be refreshed. Reload to retry.');
        }
        if(result.rebootPending&&(!result.runtime||result.runtime.rebootRequired)){
            await identityNotice('Live Identity apply is unavailable. Reboot is required for these Build/region property changes.','warning');
        }
        return true;
    });
}

function fetchAutoIdentity(targetDevice=''){
    const target=String(targetDevice||'').trim();
    return enqueueMutation(async()=>{
        const endpoint=target?'/api/auto_identity?device='+encodeURIComponent(target):'/api/auto_identity';
        const data=await request(endpoint,{method:'POST',timeoutMs:120000});
        const result=await afterIdentitySave(data);
        const success=`Identity ready: ${data.model||data.device||'Pixel'} · ${data.build_id||data.buildId||'current build'}`;
        if(result.refreshFailed){
            await identityNotice(`${success}. Warning: the Identity Manager view could not be fully refreshed. Reload to retry.`);
        }else if(result.rebootPending&&(!result.runtime||result.runtime.rebootRequired)){
            await identityNotice(`${success}. Reboot required for Build Identity to take effect.`,'warning');
        }else{
            await identityNotice(success);
        }
        return data;
    });
}

function installIdentityManagerState(){
    try{ensureSavedBuildIdentityView();}catch(error){console.error(error);}
    void refreshSavedBuildIdentityBestEffort();
}

function nextUiPaint(){return new Promise(resolve=>{let completed=false;const finish=()=>{if(completed)return;completed=true;resolve();};const fallback=global.setTimeout(finish,80);if(typeof global.requestAnimationFrame!=='function')return;global.requestAnimationFrame(()=>global.requestAnimationFrame(()=>{global.clearTimeout(fallback);finish();}));});}function showLoadingButton(button){const spinner=document.createElement('span');spinner.className='inline-spinner';spinner.setAttribute('aria-hidden','true');button.replaceChildren(spinner,document.createTextNode('Loading...'));}function installAutoIdentityOverride(){
    const spoof=document.getElementById('spoof');
    if(!spoof)return;
    const feedButton=document.getElementById('feedFetchBtn');
    const autoButton=(typeof spoof.querySelector==='function'?spoof.querySelector('button[data-action="auto-identity"]'):null)||
        [...(typeof spoof.querySelectorAll==='function'?spoof.querySelectorAll('button'):[])].find(node=>
            (typeof node.getAttribute==='function'&&node.getAttribute('data-action')==='auto-identity')||
            (node.textContent||'').toUpperCase().includes('AUTO IDENTITY'));
    for(const [button,marker] of [[feedButton,'ctFeedFetch'],[autoButton,'ctAutoIdentity']]){
        if(!button||(button.dataset&&button.dataset[marker]==='1'))continue;
        if(button.dataset)button.dataset[marker]='1';
        button.onclick=null;
        button.removeAttribute('onclick');
        button.addEventListener('click',async event=>{
            event.preventDefault();
            if(button.disabled)return;
            const original=button.textContent;
            button.disabled=true;
            try{
                await identityPresentation(()=>{
                    button.setAttribute('aria-busy','true');
                    showLoadingButton(button);
                });
                await identityNotice('Loading...','working');
                await nextUiPaint();
                const select=document.getElementById('feedDeviceSelect');
                await fetchAutoIdentity(select&&select.value?select.value:'');
            }catch(error){
                await identityNotice(/unavailable|timeout|timed out|network/i.test(error.message||'')?
                    'Auto Identity source is temporarily unavailable. Try again later or choose a local template.':
                    (error.message||'Auto Identity failed'),'error');
            }finally{
                button.disabled=false;
                await identityPresentation(()=>{
                    button.removeAttribute('aria-busy');
                    button.textContent=original;
                });
            }
        });
    }
}

function normalizedPackageNames(){return[...new Set(packages.map(value=>typeof value==='string'?value:(value&&(value.packageName||value.name))||'').filter(value=>typeof value==='string'&&value.length>0&&value.length<=255&&/^[A-Za-z0-9_.]+$/.test(value)))].slice(0,MAX_REFERENCE_PACKAGES).sort();}const packageLabelCache=new Map();
const MAX_PACKAGE_LABEL_CACHE=MAX_REFERENCE_PACKAGES;
const PACKAGE_LABEL_BATCH_SIZE=120;
let packageLabelSource=null;
let packageLabelHost=null;
let packageLabelProvider=null;
let packageLabelGeneration=0;
let packageLabelLoad=null;
let packageOptionUid=0;
function pickerText(key,fallback){try{const i18n=global.CleveresI18n;if(i18n&&typeof i18n.translate==='function'){const value=i18n.translate(key);if(typeof value==='string'&&value&&value!==key)return value;}}catch(_){}return fallback;}
function packageDisplayName(name){const cached=packageLabelCache.get(name);if(cached&&typeof cached.label==='string'&&cached.label)return cached.label;return name;}
function packageIsSystem(name){const cached=packageLabelCache.get(name);return cached?cached.isSystem:null;}
function hostSupportsPackageInfo(){const api=global.ksu;return Boolean(api&&typeof api.getPackagesInfo==='function');}
function requestPackageLabels(names){
    const source=packages;
    const api=global.ksu;
    const provider=api&&api.getPackagesInfo;
    if(packageLabelSource!==source||packageLabelHost!==api||packageLabelProvider!==provider){
        packageLabelGeneration++;
        packageLabelCache.clear();
        packageLabelSource=source;
        packageLabelHost=api;
        packageLabelProvider=provider;
        packageLabelLoad=null;
    }
    if(!hostSupportsPackageInfo())return null;
    if(packageLabelLoad)return packageLabelLoad;
    const missing=names.filter(name=>!packageLabelCache.has(name)).slice(0,MAX_PACKAGE_LABEL_CACHE);
    if(!missing.length)return null;
    const generation=packageLabelGeneration;
    const load={source,api,provider,generation,pending:true,promise:null};
    packageLabelLoad=load;
    const isCurrent=()=>generation===packageLabelGeneration&&packages===source&&global.ksu===api&&api.getPackagesInfo===provider;
    load.promise=(async()=>{
        for(let offset=0;offset<missing.length;offset+=PACKAGE_LABEL_BATCH_SIZE){
            // The native bridge is synchronous; yield between bounded catalogue batches.
            await new Promise(resolve=>global.setTimeout(resolve,0));
            if(!isCurrent())return;
            const batch=missing.slice(offset,offset+PACKAGE_LABEL_BATCH_SIZE);
            const requested=new Set(batch);
            let parsed;
            try{
                const raw=provider.call(api,JSON.stringify(batch));
                if(typeof raw==='string'&&raw.length>1024*1024)continue;
                parsed=typeof raw==='string'?JSON.parse(raw):raw;
            }catch(_){continue;}
            if(!isCurrent())return;
            if(!Array.isArray(parsed))continue;
            for(const entry of parsed.slice(0,batch.length)){
                if(!entry||typeof entry.packageName!=='string'||!requested.has(entry.packageName)||entry.error)continue;
                if(typeof entry.appLabel!=='string'&&typeof entry.isSystem!=='boolean')continue;
                const label=typeof entry.appLabel==='string'&&entry.appLabel?entry.appLabel.slice(0,128):entry.packageName;
                packageLabelCache.set(entry.packageName,{
                    label,
                    isSystem:typeof entry.isSystem==='boolean'?entry.isSystem:null
                });
            }
        }
    })().finally(()=>{
        load.pending=false;
        if(packageLabelLoad===load)packageLabelLoad=null;
    });
    return load;
}
function packageIconNode(name){const initials=packageDisplayName(name).trim().charAt(0).toUpperCase()||'•';const fallback=document.createElement('span');fallback.className='ct-appicon-fallback';fallback.setAttribute('aria-hidden','true');fallback.textContent=initials;if(!hostSupportsPackageInfo())return fallback;const icon=document.createElement('img');icon.className='ct-appicon';icon.alt='';icon.setAttribute('aria-hidden','true');icon.loading='lazy';icon.decoding='async';icon.src='ksu://icon/'+encodeURIComponent(name);icon.addEventListener('error',()=>{if(icon.parentElement)icon.replaceWith(fallback);},{once:true});return icon;}
function installPackagePicker(inputId){
    const input=document.getElementById(inputId);
    if(!input||input.dataset.ctPackagePicker==='1')return;
    const parent=input.parentElement;
    if(!parent)return;
    input.dataset.ctPackagePicker='1';
    input.removeAttribute('list');
    const wrapper=document.createElement('div');
    wrapper.className='ct-package-picker';
    parent.insertBefore(wrapper,input);
    wrapper.appendChild(input);
    const chips=document.createElement('div');
    chips.className='ct-cluster';
    chips.style.cssText='margin-top:8px;';
    chips.hidden=true;
    const filters=[['all','app_filter_all','All'],['user','app_filter_user','User'],['system','app_filter_system','System']];
    let activeFilter='all';
    let activeIndex=-1;
    let activeName=null;
    let isOpen=false;
    let labelRequest=null;
    filters.forEach(([value,key,fallback])=>{
        const chip=document.createElement('button');
        chip.type='button';
        chip.className='ct-chip';
        chip.dataset.ctPackageFilter=value;
        chip.setAttribute('aria-pressed',value==='all'?'true':'false');
        chip.setAttribute('data-i18n',key);
        chip.setAttribute('data-i18n-source',fallback);
        chip.textContent=pickerText(key,fallback);
        chip.addEventListener('pointerdown',event=>event.preventDefault());
        chip.addEventListener('click',()=>{
            activeFilter=value;
            isOpen=true;
            chips.querySelectorAll('[data-ct-package-filter]').forEach(node=>{
                node.setAttribute('aria-pressed',node===chip?'true':'false');
            });
            render();
            input.focus();
        });
        chips.appendChild(chip);
    });
    wrapper.appendChild(chips);
    const suggestions=document.createElement('div');
    suggestions.className='ct-package-suggestions';
    suggestions.setAttribute('role','listbox');
    suggestions.hidden=true;
    wrapper.appendChild(suggestions);
    input.setAttribute('role','combobox');
    input.setAttribute('aria-expanded','false');
    input.setAttribute('aria-autocomplete','list');
    const clearActiveDescendant=()=>input.removeAttribute('aria-activedescendant');
    const close=()=>{
        suggestions.hidden=true;
        input.setAttribute('aria-expanded','false');
        activeIndex=-1;
        activeName=null;
        clearActiveDescendant();
    };
    const pick=name=>{
        input.value=name;
        isOpen=false;
        close();
        input.dispatchEvent(new Event('change',{bubbles:true}));
    };
    const render=(loadLabels=true)=>{
        const query=input.value.trim().toLowerCase();
        const names=normalizedPackageNames();
        const metadata=loadLabels?requestPackageLabels(names):null;
        const pending=Boolean(packageLabelLoad&&packageLabelLoad.pending);
        input.setAttribute('aria-busy',pending?'true':'false');
        if(metadata&&metadata!==labelRequest){
            labelRequest=metadata;
            metadata.promise.then(()=>{
                if(labelRequest!==metadata)return;
                labelRequest=null;
                if(metadata.generation!==packageLabelGeneration||metadata.source!==packages||metadata.api!==global.ksu||metadata.api.getPackagesInfo!==metadata.provider)return;
                input.setAttribute('aria-busy','false');
                if(isOpen)render(false);
            });
        }
        const knownFlags=names.some(name=>packageIsSystem(name)!==null);
        chips.hidden=!hostSupportsPackageInfo()||!knownFlags;
        if(chips.hidden&&!pending){
            activeFilter='all';
            chips.querySelectorAll('[data-ct-package-filter]').forEach(node=>{
                node.setAttribute('aria-pressed',node.dataset.ctPackageFilter==='all'?'true':'false');
            });
        }
        if(loadLabels)activeName=null;
        clearActiveDescendant();
        const matches=names.filter(name=>{
            if(query&&!name.toLowerCase().includes(query)&&!packageDisplayName(name).toLowerCase().includes(query))return false;
            return activeFilter==='all'||packageIsSystem(name)===(activeFilter==='system');
        }).slice(0,24);
        activeIndex=activeName===null?-1:matches.indexOf(activeName);
        if(activeIndex<0)activeName=null;
        suggestions.replaceChildren();
        matches.forEach((name,index)=>{
            const button=document.createElement('button');
            button.type='button';
            button.className='ct-package-option';
            button.id='ct-pkg-opt-'+(++packageOptionUid);
            button.setAttribute('role','option');
            button.dataset.ctPackageName=name;
            button.setAttribute('aria-selected',index===activeIndex?'true':'false');
            if(index===activeIndex)input.setAttribute('aria-activedescendant',button.id);
            const icon=packageIconNode(name);
            const text=document.createElement('span');
            text.className='ct-pkg-text';
            const label=document.createElement('span');
            label.className='ct-pkg-name';
            label.setAttribute('translate','no');
            label.textContent=packageDisplayName(name);
            const sub=document.createElement('span');
            sub.className='ct-pkg-sub';
            sub.setAttribute('translate','no');
            sub.textContent=name;
            text.append(label,sub);
            const chevron=document.createElement('span');
            chevron.className='ct-pkg-chevron';
            chevron.setAttribute('aria-hidden','true');
            chevron.textContent='›';
            button.append(icon,text,chevron);
            button.setAttribute('aria-label',packageDisplayName(name)+', '+name);
            button.addEventListener('pointerdown',event=>event.preventDefault());
            button.onclick=()=>pick(name);
            suggestions.appendChild(button);
        });
        if(!matches.length&&(query||pending)){
            const note=document.createElement('div');
            note.className='ct-pkg-empty';
            note.setAttribute('aria-hidden','true');
            note.textContent=pending?pickerText('Loading...','Loading...'):pickerText('no_matching_apps','No matching apps. Press Enter to use the typed value.');
            suggestions.appendChild(note);
        }
        suggestions.hidden=matches.length===0&&!query&&!pending;
        input.setAttribute('aria-expanded',suggestions.hidden?'false':'true');
    };
    const moveActive=delta=>{
        const options=Array.from(suggestions.querySelectorAll('[role="option"]'));
        if(!options.length)return;
        activeIndex=activeIndex<0?(delta<0?options.length-1:0):(activeIndex+delta+options.length)%options.length;
        activeName=options[activeIndex].dataset.ctPackageName;
        options.forEach((option,index)=>{
            const active=index===activeIndex;
            option.setAttribute('aria-selected',active?'true':'false');
            if(active){
                input.setAttribute('aria-activedescendant',option.id);
                if(typeof option.scrollIntoView==='function')option.scrollIntoView({block:'nearest'});
            }
        });
    };
    const open=()=>{isOpen=true;render();};
    input.addEventListener('focus',open);
    input.addEventListener('input',open);
    input.addEventListener('keydown',event=>{
        if(suggestions.hidden&&event.key!=='ArrowDown'&&event.key!=='ArrowUp')return;
        if(event.key==='ArrowDown'||event.key==='ArrowUp'){
            event.preventDefault();
            if(suggestions.hidden)open();
            moveActive(event.key==='ArrowDown'?1:-1);
        }else if(event.key==='Enter'){
            const options=suggestions.querySelectorAll('[role="option"]');
            if(!suggestions.hidden&&options.length&&activeIndex>=0&&options[activeIndex]){
                event.preventDefault();
                options[activeIndex].click();
            }
        }else if(event.key==='Escape'){
            event.preventDefault();
            isOpen=false;
            close();
        }
    });
    input.addEventListener('blur',()=>{
        isOpen=false;
        global.setTimeout(()=>{if(!isOpen)close();},100);
    });
}
function installPackagePickers(){['ct_profile_app_picker','ct_effective_package'].forEach(installPackagePicker);}function sanitizeErrors(){const original=global.notify;if(typeof original!=='function'||original.ctPolicyWrapped)return;const wrapped=function(message,type){let text=String(message||'');if(type==='error'&&/^[a-f0-9]{24,128}$/i.test(text.trim()))text='The operation failed. Open Logs for details.';return original(text,type);};wrapped.ctPolicyWrapped=true;global.notify=wrapped;}async function loadLegacyConfig(){try{legacyConfig=await request('/api/config');}catch(_){legacyConfig=legacyConfig||{};}}async function loadReferenceData(){if(referenceDataController)referenceDataController.abort();const controller=new AbortController();referenceDataController=controller;const requestOptions={signal:controller.signal};const tasks=[];tasks.push(request('/api/packages',requestOptions).then(value=>{if(controller.signal.aborted)return;packages=Array.isArray(value)?value.slice(0,MAX_REFERENCE_PACKAGES):[];if(!packages.length&&typeof bridge.listPackages==='function'){const fallback=bridge.listPackages();packages=Array.isArray(fallback)?fallback.slice(0,MAX_REFERENCE_PACKAGES):[];}}).catch(()=>{if(controller.signal.aborted)return;if(typeof bridge.listPackages==='function'){const fallback=bridge.listPackages();packages=Array.isArray(fallback)?fallback.slice(0,MAX_REFERENCE_PACKAGES):[];}else packages=[];}));tasks.push(request('/api/keyboxes',requestOptions).then(value=>{if(controller.signal.aborted)return;keyboxes=Array.isArray(value)?Array.from(new Set(value.filter(item=>typeof item==='string'&&item.length>0&&item.length<=256))).slice(0,MAX_REFERENCE_KEYBOXES):[];}).catch(()=>{}));tasks.push(request('/api/config',requestOptions).then(value=>{if(controller.signal.aborted)return;legacyConfig=value||{};if(Array.isArray(value.templates))templates=value.templates.slice(0,MAX_REFERENCE_TEMPLATES);}).catch(()=>{}));try{await Promise.all(tasks);}finally{if(referenceDataController===controller)referenceDataController=null;}}function renderAll(){if(!policyState)return;policyRenderWithoutI18n=!i18nReady();renderFeatureCenter();renderIdentityControls();renderIdentityScopeBanner();installIdentityBanner();renderPatchPage();renderProfiles();const inspect=document.getElementById('ct_effective_load');if(inspect)inspect.onclick=inspectEffective;removeLegacySurfaces();refreshDynamicVisibility();refreshPresentation();}let policyRenderWithoutI18n=false;function i18nReady(){return Boolean(global.CleveresI18n&&typeof global.CleveresI18n.translate==='function');}function handleI18nReady(){if(policyState&&policyRenderWithoutI18n&&i18nReady())renderAll();}if(!global.ctPolicyI18nRetranslate&&typeof global.addEventListener==='function'){global.ctPolicyI18nRetranslate=true;global.addEventListener('ct_retranslate',handleI18nReady);}function applyExternalPolicyState(event){const state=event&&event.detail;if(!state||typeof state!=='object'||!state.features||!Array.isArray(state.profiles))return;publishPolicyState(state);renderAll();}function escapeHtml(value){return String(value==null?'':value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}async function initialize(){refreshZygiskStatus();injectStyles();staticPages();installTabNavigationOwner();retireLegacyLocalization();installFeatureCenter();installIdentityControls();installConfigurationActions();installCustomPropsEditor();installCustomTemplateBuilder();installKernelIdentityControls();installAppsProfileCard();removeLegacySurfaces();markIdentityActionGroups();installAutoIdentityOverride();try{await enqueueMutation(async()=>publishPolicyState(await request('/api/policy_state')));}catch(error){if(typeof global.setTimeout==='function'){const retryDelays=[500,1500,3000,6000];const attemptRetry=async(index)=>{if(policyState||index>=retryDelays.length)return;try{await enqueueMutation(async()=>publishPolicyState(await request('/api/policy_state')));await loadReferenceData();installIdentityManagerState();renderAll();sanitizeErrors();installPackagePickers();}catch(retryError){if(!policyState){if(index+1<retryDelays.length){global.setTimeout(()=>attemptRetry(index+1),retryDelays[index+1]);}else{notify(`Policy controls unavailable: ${retryError && retryError.message || error.message}`,'error');}}}};global.setTimeout(()=>attemptRetry(0),retryDelays[0]);}else{notify(`Policy controls unavailable: ${error.message}`,'error');}return;}await loadReferenceData();installIdentityManagerState();renderAll();sanitizeErrors();installPackagePickers();}if(typeof global.addEventListener==='function')global.addEventListener('ct-policy-state',applyExternalPolicyState);async function applyAiChanges(changes,isCurrent=()=>true){
    if(!changes||typeof changes!=='object'||Array.isArray(changes)||saving)throw new Error('Policy update unavailable');
    const entries=Object.entries(changes);if(!entries.length||entries.length>10)throw new Error('Invalid policy update');
    const top=new Set(['globalIdentity','spoofProps','blockInvalidKeyboxes']);
    const features=new Set(['buildIdentity','attestationIdentity','telephonyIdentity','regionIdentity','identityRefresh','securityPatch','customProps']);
    for(const [key,value] of entries){
        if(top.has(key)){if(typeof value!=='boolean')throw new Error('Invalid policy update');continue;}
        if(key!=='features'||!value||typeof value!=='object'||Array.isArray(value))throw new Error('Invalid policy update');
        const items=Object.entries(value);if(!items.length||items.length>features.size||items.some(([name,enabled])=>!features.has(name)||typeof enabled!=='boolean'))throw new Error('Invalid policy update');
    }
    const captured=safeClone(changes);saving=true;document.documentElement.classList.add('ct-saving');
    try{return await enqueueMutation(async()=>{
        if(!isCurrent())return false;
        const fresh=await request('/api/policy_state');if(!isCurrent())return false;publishPolicyState(fresh);
        return performPolicySave(next=>{for(const [key,value] of Object.entries(captured)){if(key==='features')Object.assign(next.features,value);else next[key]=value;}},'Saved');
    });}finally{saving=false;document.documentElement.classList.remove('ct-saving');}
}
global.CleveresPolicy=Object.freeze({readKeyboxPriorityOrder,saveKeyboxPriorityOrder,applyAiChanges});global.CleveresIdentity=Object.freeze({save:saveIdentity,fetch:fetchAutoIdentity});onReady(initialize);})(window);

