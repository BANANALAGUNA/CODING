# Licensing

CleveresTricky uses **component-specific licenses**. From October 9, 2026, original first-party material created after revision `2c636dd336b26c0add7553ecca98ec71f8a3ecfe` is subject to the prospective **all-rights-reserved** terms in [LICENSE](LICENSE) if it can lawfully be licensed independently and tryigit controls the necessary rights. This is **not** a blanket relicensing of older code, GPL-covered derivatives, or third-party components. Restricted access to the development repository does not change the license of any delivered component.

- **GPL-covered software:** Existing code previously licensed under GPLv3, modifications of GPL-covered code, and any combined work the applicable GPL requires to be licensed as a whole remain subject to that license, including corresponding-source obligations when binaries are distributed. Any valid **GPLv3-or-later** grant remains valid and is not reduced to GPLv3-only by the name of our archived [GNU GPLv3 text](https://cleverestricky-52bf07.gitlab.io/licenses/GPL-3.0-only.txt). This includes the integrated module, service, native code and WebUI unless a properly documented, legally separable exception is established.
- **Third-party material:** Upstream contributions, dependencies, fonts and other third-party material retain their original licenses and notices.
- **Independent proprietary material:** New original first-party material created after the cutoff is reserved-rights by default **only where** tryigit owns the required rights and that material is legally separable from existing GPL-covered works. Specific file-level licensing identifiers are encouraged to make the boundary clear; neither a file label nor this project-wide notice overrides any GPL obligation. See [Reserved Rights](OWNER_ONLY_LICENSE.md). This does not claim that existing integrated software has been relicensed.

Previously granted open-source rights remain in force. GPL-covered material may be used, modified and commercially redistributed in compliance with its license; no blanket prohibition on commercial use, redistribution or modification applies to it.

The original GPLv3 legal text is retained at `module/template/GPL-3.0-only.txt`, included in the module ZIP as `GPL-3.0-only.txt`, and published at the GitLab Pages GPL URL above. The module ZIP also carries the project-wide `LICENSE`, `LICENSING.md` and `NOTICE` in English, each with its own `.sha256` checksum. A project-wide notice is not a blanket relicensing of the integrated module. Distributors of GPL-covered binaries must make the matching corresponding source available as the applicable GPL terms require. If the source for a distributed build is unavailable or incomplete, request it at [info@tryigit.dev](mailto:info@tryigit.dev). The GPL text is also [available here](https://www.gnu.org/licenses/gpl-3.0.html).

The source-access rationale is explained in [Source Policy](SOURCE_POLICY.md). Qualified developers may request access for collaboration; any access agreement is subject to the rights already granted under applicable open-source licenses.

*These notices describe intended licensing boundaries, not a retroactive relicensing of earlier releases.*

## Warranty and liability

Root-level modifications can cause boot loops, data loss or device damage. See [LICENSE](LICENSE) for the relevant no-warranty and limitation-of-liability language and non-waivable legal exceptions. GPL-covered components retain their own license's no-warranty and liability rules (GNU GPLv3 sections 15-17 where applicable); proprietary terms do not override them. No attestation or DRM outcome is guaranteed.
