# CleveresTricky
**Language:** **English** | [Türkçe](README.tr.md) | [简体中文](README.zh-CN.md) | [Español](README.es.md) | [Deutsch](README.de.md) | [Русский](README.ru.md) | [Bahasa Indonesia](README.id.md) | [हिन्दी](README.hi.md) | [العربية](README.ar.md)

[![Release](https://gitlab.com/tryigitx/cleverestricky/-/badges/release.svg)](https://gitlab.com/tryigitx/cleverestricky/-/releases)
![Android](https://img.shields.io/badge/Android-12--17-3DDC84?logo=android&logoColor=white)
![Module](https://img.shields.io/badge/Module-KernelSU%20%7C%20APatch%20%7C%20Magisk-6f42c1)

CleveresTricky is a KernelSU, APatch, and Magisk module for Android 12-17. It brings Android keystore and attestation compatibility, Keybox/CBOX management, application targeting, optional identity controls, patch-level controls, and privacy tools into one mobile WebUI.

ARM64 and x86-64. Check the [installation requirements](docs/system/Installer.md) before installing.

## Quick start

1. Download the ZIP from [GitLab Releases](https://gitlab.com/tryigitx/cleverestricky/-/releases).
2. Install it through KernelSU, APatch or **Magisk** while Android is running.
3. Open the module WebUI. On Magisk, use the module Action button.
4. Add a Keybox/CBOX you own or are authorized to test. Start with the defaults.

## Guides

- [Installation](docs/system/Installer.md) · [WebUI](docs/system/WebInterface.md)
- [Keybox management](docs/security/KeyboxManager.md) · [Application scope](docs/identity/ApplicationScope.md)
- [Build Identity](docs/identity/BuildIdentity.md) · [Custom properties](docs/identity/CustomProps.md)
- [Backup and restore](docs/system/BackupRestore.md) · [Diagnostics](docs/system/Diagnostics.md)
- [All guides](docs/README.md)

## Support

Use **Device Checks** for tests. For support, open **Logs & Support > Share Basic Report**. See [Diagnostics](docs/system/Diagnostics.md) for `emergency-report.sh`. [CleveresTech Telegram](https://t.me/cleverestech)

Device Checks also shows AICore package state, the cached Magic Compose flag and an RCS signal relevant to Gemini in Google Messages.

Root changes can cause boot loops or data loss. GPL, third-party and independent materials retain their respective terms; see [Licensing](LICENSING.md), [LICENSE](LICENSE) and [Source Policy](SOURCE_POLICY.md).

[Changelog](CHANGELOG.md) · [Contributing](CONTRIBUTING.md)
