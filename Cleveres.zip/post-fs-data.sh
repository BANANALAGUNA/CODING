#!/system/bin/sh
MODDIR=${0%/*}
CONFIG_DIR="${CLEVERES_TRICKY_CONFIG_DIR:-/data/adb/cleverestricky}"
CONFIG_ROOT_SAFE=false

# BEGIN FACTORY RESET
FACTORY_RESET_MARKER="${CONFIG_DIR}.factory_reset_pending"

factory_reset_paths_safe() {
  [ "$(id -u)" = 0 ] || return 1
  [ -d "$MODDIR" ] && [ ! -L "$MODDIR" ] || return 1
  [ "$(readlink -f "$MODDIR")" = "$MODDIR" ] || return 1
  [ "$(stat -c %u "$MODDIR")" = 0 ] || return 1
  [ -n "$CONFIG_DIR" ] && [ "$CONFIG_DIR" != / ] || return 1
  [ ! -L "$CONFIG_DIR" ] || return 1
  [ "$(readlink -f "$CONFIG_DIR")" = "$CONFIG_DIR" ] || return 1
  if [ -e "$CONFIG_DIR" ]; then
    [ -d "$CONFIG_DIR" ] && [ "$(stat -c %u "$CONFIG_DIR")" = 0 ] || return 1
  fi
  for reset_path in "$MODDIR/keyboxes" "$MODDIR/Encrypted"; do
    [ ! -L "$reset_path" ] || return 1
    if [ -e "$reset_path" ]; then [ -d "$reset_path" ] || return 1; fi
  done
  if [ -e "$FACTORY_RESET_MARKER" ] || [ -L "$FACTORY_RESET_MARKER" ]; then
    [ -f "$FACTORY_RESET_MARKER" ] && [ ! -L "$FACTORY_RESET_MARKER" ] || return 1
    [ "$(stat -c %u "$FACTORY_RESET_MARKER")" = 0 ] || return 1
  fi
  # Never traverse a bind mount into data outside the module's own folders.
  awk -v config="$CONFIG_DIR" -v keys="$MODDIR/keyboxes" -v encrypted="$MODDIR/Encrypted" '
    $5 == config || index($5, config "/") == 1 ||
    $5 == keys || index($5, keys "/") == 1 ||
    $5 == encrypted || index($5, encrypted "/") == 1 { unsafe = 1 }
    END { exit unsafe ? 1 : 0 }
  ' /proc/self/mountinfo || return 1
}

factory_reset_owner_paths() {
  case "$MODDIR" in
    /data/adb/modules/cleverestricky|/data/adb/ksu/modules/cleverestricky|/data/adb/ap/modules/cleverestricky) ;;
    *) return 1 ;;
  esac
  [ "$CONFIG_DIR" = /data/adb/cleverestricky ]
}

factory_reset_boot_id_valid() {
  printf '%s\n' "$1" | grep -Eq '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
}

read_factory_reset_boot_id() {
  [ -f "$FACTORY_RESET_MARKER" ] && [ ! -L "$FACTORY_RESET_MARKER" ] || return 1
  reset_marker_size=$(stat -c %s "$FACTORY_RESET_MARKER" 2>/dev/null) || return 1
  case "$reset_marker_size" in 36|37) ;; *) return 1 ;; esac
  reset_marker_boot=$(dd if="$FACTORY_RESET_MARKER" bs=38 count=1 2>/dev/null) || return 1
  factory_reset_boot_id_valid "$reset_marker_boot" || return 1
  printf '%s\n' "$reset_marker_boot"
}

write_factory_reset_boot_id() (
  reset_marker_tmp=$(mktemp "${FACTORY_RESET_MARKER}.XXXXXX" 2>/dev/null) || exit 1
  trap 'rm -f "$reset_marker_tmp"' EXIT
  chmod 600 "$reset_marker_tmp" || exit 1
  printf '%s\n' "$1" > "$reset_marker_tmp" || exit 1
  mv -f "$reset_marker_tmp" "$FACTORY_RESET_MARKER" || exit 1
)

request_factory_reset() {
  factory_reset_paths_safe || return 1
  factory_reset_owner_paths || return 1
  helper_packages=$(pm list packages --user all cleveres.tricky.webuiauth 2>/dev/null) || return 1
  if printf '%s\n' "$helper_packages" | grep -qx 'package:cleveres.tricky.webuiauth'; then
    helper_result=$(pm uninstall cleveres.tricky.webuiauth 2>&1) || return 1
    printf '%s\n' "$helper_result" | grep -qx Success || return 1
    helper_packages=$(pm list packages --user all cleveres.tricky.webuiauth 2>/dev/null) || return 1
    if printf '%s\n' "$helper_packages" | grep -qx 'package:cleveres.tricky.webuiauth'; then return 1; fi
  fi
  reset_boot=$(current_boot_id) || return 1
  factory_reset_boot_id_valid "$reset_boot" || return 1
  if ! read_factory_reset_boot_id >/dev/null; then
    write_factory_reset_boot_id "$reset_boot" || return 1
  fi
  chmod 600 "$FACTORY_RESET_MARKER" || return 1
  printf '%s\n' factory-reset-ready
}

apply_factory_reset() {
  factory_reset_paths_safe && factory_reset_owner_paths || return 1
  reset_boot=$(read_factory_reset_boot_id) || return 1
  this_boot=$(current_boot_id) || return 1
  factory_reset_boot_id_valid "$this_boot" || return 1
  [ "$this_boot" != "$reset_boot" ] || return 1
  # Region uses resetprop -n, which owns only the runtime view. A legacy marker
  # cannot authorize deleting a genuine property from persistent storage.
  rm -rf "$CONFIG_DIR" "$MODDIR/keyboxes" "$MODDIR/Encrypted" || return 1
  for reset_keybox in "$MODDIR"/*.xml "$MODDIR"/*.cbox; do
    [ -e "$reset_keybox" ] || [ -L "$reset_keybox" ] || continue
    [ -f "$reset_keybox" ] || [ -L "$reset_keybox" ] || return 1
    rm -f "$reset_keybox" || return 1
  done
  [ ! -e "$CONFIG_DIR" ] && [ ! -L "$CONFIG_DIR" ] || return 1
  (umask 077; mkdir "$CONFIG_DIR" && : > "$CONFIG_DIR/recommended_defaults_pending") || return 1
  chown 0:0 "$CONFIG_DIR" "$CONFIG_DIR/recommended_defaults_pending" || return 1
  chmod 700 "$CONFIG_DIR" || return 1
  chmod 600 "$CONFIG_DIR/recommended_defaults_pending" || return 1
  rm -f "$FACTORY_RESET_MARKER" || return 1
}

# END FACTORY RESET


if [ -d "$CONFIG_DIR" ] && [ ! -L "$CONFIG_DIR" ]; then
  if chown 0:0 "$CONFIG_DIR" 2>/dev/null && chmod 700 "$CONFIG_DIR"; then
    CONFIG_ROOT_SAFE=true
  else
    log -t CleveresTricky "Config root permissions could not be secured; early config processing was skipped"
  fi
  chcon u:object_r:system_file:s0 "$CONFIG_DIR" 2>/dev/null
fi

# BEGIN BOOT EPOCH HELPERS
current_boot_id() {
  boot_id=$(dd if=/proc/sys/kernel/random/boot_id bs=65 count=1 2>/dev/null) || return 1
  boot_id=$(printf '%s' "$boot_id" | tr -d '\r\n')
  [ "${#boot_id}" -eq 36 ] || return 1
  case "$boot_id" in
    *[!0-9a-f-]*) return 1 ;;
  esac
  printf '%s' "$boot_id"
}

clear_persisted_runtime_pids() {
  rm -f \
    "$CONFIG_DIR/supervisor.pid" \
    "$CONFIG_DIR/daemon.pid" \
    "$CONFIG_DIR/adapter.pid" \
    "$CONFIG_DIR/backend.pid" \
    "$MODDIR/supervisor.pid" \
    2>/dev/null || true
}

prepare_runtime_boot_epoch() {
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  marker="$CONFIG_DIR/runtime.boot_id"
  if [ -L "$marker" ] || { [ -e "$marker" ] && [ ! -f "$marker" ]; }; then
    clear_persisted_runtime_pids
    rm -f "$marker" 2>/dev/null || true
  fi

  current_id=$(current_boot_id) || {
    clear_persisted_runtime_pids
    log -t CleveresTricky "Kernel boot identity is unavailable; stale runtime PID records were discarded"
    return 0
  }

  previous_id=
  if [ -f "$marker" ] && [ ! -L "$marker" ]; then
    previous_id=$(dd if="$marker" bs=65 count=1 2>/dev/null) || previous_id=
    previous_id=$(printf '%s' "$previous_id" | tr -d '\r\n')
  fi
  if [ "$previous_id" != "$current_id" ]; then
    clear_persisted_runtime_pids
    snapshot="$CONFIG_DIR/original_props"
    if [ -f "$snapshot" ] && [ ! -L "$snapshot" ]; then
      if snapshot_prefix=$(dd if="$snapshot" bs=96 count=1 2>/dev/null); then
        snapshot_header=${snapshot_prefix%%'
'*}
        if [ "$snapshot_header" != "# CT_ORIGINAL_PROPS_V2 $current_id" ]; then
          rm -f "$snapshot" 2>/dev/null || true
        fi
      fi
    elif [ -e "$snapshot" ] || [ -L "$snapshot" ]; then
      rm -f "$snapshot" 2>/dev/null || true
    fi
  fi

  tmp="$CONFIG_DIR/.runtime.boot_id.$$"
  rm -f "$tmp" 2>/dev/null || return 0
  umask 077
  if ! printf '%s\n' "$current_id" > "$tmp" 2>/dev/null; then
    rm -f "$tmp" 2>/dev/null || true
    return 0
  fi
  chown 0:0 "$tmp" 2>/dev/null || { rm -f "$tmp"; return 0; }
  chmod 600 "$tmp" 2>/dev/null || { rm -f "$tmp"; return 0; }
  chcon u:object_r:system_file:s0 "$tmp" 2>/dev/null
  mv -f "$tmp" "$marker" 2>/dev/null || rm -f "$tmp" 2>/dev/null || true
}
# END BOOT EPOCH HELPERS

# BEGIN FACTORY RESET DISPATCH
if [ "${1:-}" = --request-factory-reset ]; then
  request_factory_reset
  exit $?
fi
if [ -e "$FACTORY_RESET_MARKER" ] || [ -L "$FACTORY_RESET_MARKER" ]; then
  if [ "${CLEVERES_TRICKY_IDENTITY_ONLY:-0}" = 1 ] || ! apply_factory_reset; then
    log -t CleveresTricky "Factory reset remains pending; refusing configuration startup"
    exit 1
  fi
  CONFIG_ROOT_SAFE=true
fi
# END FACTORY RESET DISPATCH

if [ "${CLEVERES_TRICKY_IDENTITY_ONLY:-0}" != 1 ]; then
  prepare_runtime_boot_epoch
fi

# Repair the boot layout before the managed adapter starts. Setting changes
# already prepare provider discovery on disk before the requested reboot.
# The same signed owner is used by the installer and live setting changes.
if [ "$CONFIG_ROOT_SAFE" = true ] && [ "${CLEVERES_TRICKY_IDENTITY_ONLY:-0}" != 1 ]; then
  if [ -f "$MODDIR/identity-zygisk.sh" ] && [ ! -L "$MODDIR/identity-zygisk.sh" ]; then
    # shellcheck disable=SC1091
    . "$MODDIR/identity-zygisk.sh"
    if ct_zygisk_reconcile "$MODDIR" "$CONFIG_DIR" auto; then
      if [ -d "$MODDIR/zygisk" ] && [ ! -L "$MODDIR/zygisk" ]; then
        rm -f "$CONFIG_DIR/zygisk_boot_enabled"
        (umask 077; set -C; : > "$CONFIG_DIR/zygisk_boot_enabled")
      else
        rm -f "$CONFIG_DIR/zygisk_boot_enabled"
      fi
    else
      log -t CleveresTricky "Optional Identity payload reconciliation failed"
    fi
  fi
fi

boot_policy_feature_enabled() {
  feature=$1
  state="$CONFIG_DIR/boot_policy_state"

  if [ ! -e "$state" ] && [ ! -L "$state" ]; then
    legacy_state="$CONFIG_DIR/policy_state_v2.json"
    if [ -e "$legacy_state" ] || [ -L "$legacy_state" ]; then
      return 1
    fi
    return 2
  fi
  [ -f "$state" ] && [ ! -L "$state" ] || return 1

  state_size=$(wc -c < "$state" 2>/dev/null) || return 1
  case "$state_size" in ''|*[!0-9]*) return 1 ;; esac
  [ "$state_size" -ge 1 ] && [ "$state_size" -le 128 ] || return 1

  projection_version=
  projection_build=
  projection_region=
  projection_refresh=
  projection_custom=
  projection_global=
  projection_props=
  while IFS= read -r line || [ -n "$line" ]; do
    [ "${#line}" -le 32 ] || return 1
    key=${line%%=*}
    [ "$key" != "$line" ] || return 1
    value=${line#*=}
    case "$value" in 0|1) ;; *)
      case "$key:$value" in
        version:1|version:2|version:3|version:4) ;;
        *) return 1 ;;
      esac
      ;;
    esac
    case "$key" in
      version)
        [ -z "$projection_version" ] || return 1
        projection_version=$value
        ;;
      build)
        [ -z "$projection_build" ] || return 1
        projection_build=$value
        ;;
      region)
        [ -z "$projection_region" ] || return 1
        projection_region=$value
        ;;
      refresh)
        [ -z "$projection_refresh" ] || return 1
        projection_refresh=$value
        ;;
      custom)
        [ -z "$projection_custom" ] || return 1
        projection_custom=$value
        ;;
      global)
        [ -z "$projection_global" ] || return 1
        projection_global=$value
        ;;
      props)
        [ -z "$projection_props" ] || return 1
        projection_props=$value
        ;;
      *) return 1 ;;
    esac
  done < "$state"

  case "$projection_version" in
    1)
      [ -z "$projection_custom" ] && [ -z "$projection_global" ] && [ -z "$projection_props" ] || return 1
      case "$projection_build:$projection_region:$projection_refresh" in
        [01]:[01]:[01]) ;;
        *) return 1 ;;
      esac
      ;;
    2)
      [ -z "$projection_global" ] && [ -z "$projection_props" ] || return 1
      case "$projection_build:$projection_region:$projection_refresh:$projection_custom" in
        [01]:[01]:[01]:[01]) ;;
        *) return 1 ;;
      esac
      ;;
    3)
      [ -z "$projection_props" ] || return 1
      case "$projection_build:$projection_region:$projection_refresh:$projection_custom:$projection_global" in
        [01]:[01]:[01]:[01]:[01]) ;;
        *) return 1 ;;
      esac
      ;;
    4)
      case "$projection_build:$projection_region:$projection_refresh:$projection_custom:$projection_global:$projection_props" in
        [01]:[01]:[01]:[01]:[01]:[01]) ;;
        *) return 1 ;;
      esac
      ;;
    *) return 1 ;;
  esac

  case "$feature" in
    buildIdentity) [ "$projection_build" = 1 ] ;;
    regionIdentity) [ "$projection_region" = 1 ] ;;
    identityRefresh) [ "$projection_refresh" = 1 ] ;;
    customProps) [ "$projection_version" != 1 ] && [ "$projection_custom" = 1 ] ;;
    globalIdentity) { [ "$projection_version" != 3 ] && [ "$projection_version" != 4 ]; } || [ "$projection_global" = 1 ] ;;
    spoofProps) [ "$projection_version" != 4 ] || [ "$projection_props" = 1 ] ;;
    projectionValid) return 0 ;;
    *) return 1 ;;
  esac
}

optional_marker_enabled() {
  feature=$1
  marker=$2
  [ -f "$CONFIG_DIR/$marker" ] && [ ! -L "$CONFIG_DIR/$marker" ] || return 1

  boot_policy_feature_enabled "$feature"
  policy_status=$?
  [ "$policy_status" -eq 2 ] && return 0
  [ "$policy_status" -eq 0 ]
}

promote_staged_identity() {
  staged_file="$CONFIG_DIR/spoof_build_vars.next"
  active_file="$CONFIG_DIR/spoof_build_vars"

  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  if [ ! -e "$staged_file" ] && [ ! -L "$staged_file" ]; then
    return 0
  fi
  if [ -L "$staged_file" ]; then
    rm -f "$staged_file"
    log -t CleveresTricky "Removed an unsafe staged identity link"
    return 0
  fi
  if [ ! -f "$staged_file" ]; then
    log -t CleveresTricky "Non-regular staged identity was ignored"
    return 0
  fi

  if [ ! -f "$CONFIG_DIR/spoof_enabled" ] || [ -L "$CONFIG_DIR/spoof_enabled" ] ||
    ! optional_marker_enabled identityRefresh random_on_boot; then
    rm -f "$staged_file"
    return 0
  fi
  if [ -L "$active_file" ] || { [ -e "$active_file" ] && [ ! -f "$active_file" ]; }; then
    log -t CleveresTricky "Unsafe active identity path; staged identity was ignored"
    return 0
  fi

  staged_size=$(wc -c < "$staged_file" 2>/dev/null) || return 0
  if [ "$staged_size" -lt 1 ] || [ "$staged_size" -gt 1048576 ]; then
    rm -f "$staged_file"
    log -t CleveresTricky "Invalid staged identity size; staged identity was removed"
    return 0
  fi

  if ! chown 0:0 "$staged_file" 2>/dev/null || ! chmod 600 "$staged_file"; then
    log -t CleveresTricky "Staged identity permissions could not be secured"
    return 0
  fi
  chcon u:object_r:system_file:s0 "$staged_file" 2>/dev/null
  if mv -f "$staged_file" "$active_file"; then
    log -t CleveresTricky "Activated the prepared identity snapshot"
  else
    log -t CleveresTricky "Could not activate the prepared identity snapshot"
  fi
}

# A missing property and a present empty value both print empty with getprop NAME.
# Keep the typed snapshot contract (A / Vvalue) using the enumerated property set.
read_prop_state() {
  case "$1" in ''|*[!A-Za-z0-9._:@-]*) return 1 ;; esac
  [ "${#1}" -le 127 ] || return 1
  property_listing=$(
    { getprop 2>/dev/null; printf '\nCT_GETPROP_STATUS=%s' "$?"; } | head -c 1048577
  ) || return 1
  property_listing_bytes=$(printf '%s' "$property_listing" | wc -c) || return 1
  [ "$property_listing_bytes" -le 1048576 ] || return 1
  case "$property_listing" in *'
CT_GETPROP_STATUS=0') ;; *) return 1 ;; esac
  printf '%s\n' "$property_listing" | awk -v name="$1" '
    BEGIN { prefix = "[" name "]: [" }
    index($0, prefix) == 1 {
      if (found || substr($0, length($0), 1) != "]" || length($0) > 65536) { invalid = 1; next }
      found = 1
      value = substr($0, length(prefix) + 1, length($0) - length(prefix) - 1)
      if (value ~ /[^[:print:]]/) invalid = 1
    }
    END {
      if (invalid) exit 1
      if (found) printf "V%s", value
      else printf "A"
    }
  '
}

apply_prop() {
  if [ "${RECORDING_ORIGINAL_PROPS:-0}" = 1 ]; then
    if ! record_original_prop "$1"; then
      IDENTITY_APPLY_FAILED=1
      log -t CleveresTricky "Failed to record original property for $1; skipping override to prevent state loss"
      return 1
    fi
    # Newline-delimited keys prevent partial-name matches during reconciliation.
    IDENTITY_SELECTED_PROPS="${IDENTITY_SELECTED_PROPS:-}
$1
"
  fi
  if current_state=$(read_prop_state "$1") && [ "$current_state" = "V$2" ]; then
    return 0
  fi
  resetprop -n "$1" "$2" >/dev/null 2>&1 || {
    IDENTITY_APPLY_FAILED=1
    log -t CleveresTricky "Failed to apply an app-visible boot property: $1"
    return 1
  }
  if [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" = 1 ]; then
    if ! current_state=$(read_prop_state "$1") || [ "$current_state" != "V$2" ]; then
      IDENTITY_APPLY_FAILED=1
      log -t CleveresTricky "Failed to verify a live Identity property: $1"
      return 1
    fi
  fi
}

remove_prop() {
  if current_state=$(read_prop_state "$1") && [ "$current_state" = A ]; then
    return 0
  fi
  resetprop --delete "$1" >/dev/null 2>&1 || {
    log -t CleveresTricky "Failed to remove a legacy boot property: $1"
    return 1
  }
}

original_props_header() {
  original_boot_id=$(current_boot_id) || return 1
  factory_reset_boot_id_valid "$original_boot_id" || return 1
  printf '# CT_ORIGINAL_PROPS_V2 %s' "$original_boot_id"
}

validate_original_props_snapshot() {
  snap_file="$CONFIG_DIR/original_props"
  [ -f "$snap_file" ] && [ ! -L "$snap_file" ] && [ -r "$snap_file" ] || return 1
  original_size=$(wc -c < "$snap_file" 2>/dev/null) || return 1
  case "$original_size" in ''|*[!0-9]*) return 1 ;; esac
  [ "$original_size" -ge 1 ] && [ "$original_size" -le 65536 ] || return 1
  ORIGINAL_PROPS_CONTENT=$(dd if="$snap_file" bs=65537 count=1 2>/dev/null) || return 1
  original_read_size=$(printf '%s' "$ORIGINAL_PROPS_CONTENT" | wc -c) || return 1
  [ "$original_size" -eq "$((original_read_size + 1))" ] || return 1
  original_expected_header=$(original_props_header) || return 1
  original_first=true
  original_seen='
'
  while IFS= read -r original_line || [ -n "$original_line" ]; do
    if [ "$original_first" = true ]; then
      [ "$original_line" = "$original_expected_header" ] || return 1
      original_first=false
      continue
    fi
    case "$original_line" in ''|'#'*) continue ;; esac
    original_key=${original_line%%=*}
    original_encoded=${original_line#*=}
    [ "$original_key" != "$original_line" ] && [ "${#original_key}" -le 127 ] || return 1
    case "$original_key" in ''|*[!A-Za-z0-9._:@-]*) return 1 ;; esac
    case "$original_encoded" in A|V*) ;; *) return 1 ;; esac
    case "$original_encoded" in *[![:print:]]*) return 1 ;; esac
    case "$original_seen" in *"
$original_key
"*) return 1 ;; esac
    original_seen="${original_seen}${original_key}
"
  done <<EOF
$ORIGINAL_PROPS_CONTENT
EOF
}

write_original_props_snapshot() {
  snapshot_payload=$1
  snapshot_bytes=$(printf '%s\n' "$snapshot_payload" | wc -c) || return 1
  [ "$snapshot_bytes" -le 65536 ] || return 1
  snap_file="$CONFIG_DIR/original_props"
  [ ! -L "$snap_file" ] || return 1
  tmp_snap=$(mktemp "${snap_file}.XXXXXX") || return 1
  if ! chmod 600 "$tmp_snap" ||
     ! printf '%s\n' "$snapshot_payload" > "$tmp_snap" ||
     ! mv -f "$tmp_snap" "$snap_file"; then
    rm -f "$tmp_snap" 2>/dev/null
    return 1
  fi
}

record_original_prop() {
  prop_name=$1
  [ "${#prop_name}" -le 127 ] || return 1
  case "$prop_name" in ''|*[!A-Za-z0-9._:@-]*) return 1 ;; esac
  snap_file="$CONFIG_DIR/original_props"
  original_expected_header=$(original_props_header) || return 1
  [ ! -L "$snap_file" ] || return 1
  snap_size=0
  if [ -e "$snap_file" ]; then
    validate_original_props_snapshot || return 1
    snap_size=$original_size
    while IFS= read -r existing_line || [ -n "$existing_line" ]; do
      case "$existing_line" in "${prop_name}="*) return 0 ;; esac
    done <<EOF
$ORIGINAL_PROPS_CONTENT
EOF
  fi
  current_state=$(read_prop_state "$prop_name") || return 1
  line="${prop_name}=${current_state}"
  line_bytes=$(printf '%s\n' "$line" | wc -c) || return 1
  if [ "$snap_size" -eq 0 ]; then
    header_bytes=$(printf '%s\n' "$original_expected_header" | wc -c) || return 1
    snap_size=$header_bytes
  fi
  [ "$((snap_size + line_bytes))" -le 65536 ] || return 1
  if [ ! -e "$snap_file" ]; then ORIGINAL_PROPS_CONTENT=$original_expected_header; fi
  write_original_props_snapshot "$ORIGINAL_PROPS_CONTENT
$line"
}

rollback_original_props() {
  snap_file="$CONFIG_DIR/original_props"
  [ -e "$snap_file" ] || [ -L "$snap_file" ] || return 0
  validate_original_props_snapshot || return 1
  failed_props=
  while IFS= read -r rollback_line || [ -n "$rollback_line" ]; do
    case "$rollback_line" in ''|'#'*) continue ;; esac
    rollback_key=${rollback_line%%=*}
    rollback_encoded=${rollback_line#*=}
    success=0
    if [ "$rollback_encoded" = A ]; then
      if remove_prop "$rollback_key"; then success=1; fi
    else
      if apply_prop "$rollback_key" "${rollback_encoded#V}"; then success=1; fi
    fi
    if [ "$success" -ne 1 ]; then failed_props="${failed_props}${rollback_line}
"; fi
  done <<EOF
$ORIGINAL_PROPS_CONTENT
EOF
  if [ -n "$failed_props" ]; then
    write_original_props_snapshot "$original_expected_header
${failed_props%?}" || return 1
    return 1
  fi
  rm -f "$snap_file"
}

# Restore only snapshot entries no longer selected by this pass.
# Keep the original baseline for keys still owned by Build, Region or Custom.
reconcile_inactive_original_props() {
  snap_file="$CONFIG_DIR/original_props"
  [ -e "$snap_file" ] || [ -L "$snap_file" ] || return 0
  validate_original_props_snapshot || return 1
  remaining_props=
  RECORDING_ORIGINAL_PROPS=0
  while IFS= read -r rollback_line || [ -n "$rollback_line" ]; do
    case "$rollback_line" in ''|'#'*) continue ;; esac
    rollback_key=${rollback_line%%=*}
    case "${IDENTITY_SELECTED_PROPS:-}" in
      *"
$rollback_key
"*) remaining_props="${remaining_props}${rollback_line}
"; continue ;;
    esac
    rollback_encoded=${rollback_line#*=}
    restored=0
    if [ "$rollback_encoded" = A ]; then
      if remove_prop "$rollback_key"; then restored=1; fi
    else
      if apply_prop "$rollback_key" "${rollback_encoded#V}"; then restored=1; fi
    fi
    if [ "$restored" -ne 1 ]; then remaining_props="${remaining_props}${rollback_line}
"; fi
  done <<EOF
$ORIGINAL_PROPS_CONTENT
EOF
  if [ -n "$remaining_props" ]; then
    write_original_props_snapshot "$original_expected_header
${remaining_props%?}" || return 1
  else
    rm -f "$snap_file" || return 1
  fi
}

hide_boot_mode() {
  current_value=$(getprop "$1")
  case "$current_value" in
    *recovery*|*RECOVERY*) apply_prop "$1" unknown || return 1 ;;
  esac
}

apply_core_boot_properties() {
  apply_prop ro.boot.vbmeta.device_state locked || true
  apply_prop ro.boot.verifiedbootstate green || true
  apply_prop ro.boot.flash.locked 1 || true
  apply_prop ro.boot.veritymode enforcing || true
  apply_prop ro.boot.warranty_bit 0 || true
  apply_prop ro.warranty_bit 0 || true
  apply_prop ro.debuggable 0 || true
  apply_prop ro.force.debuggable 0 || true
  apply_prop ro.secure 1 || true
  apply_prop ro.adb.secure 1 || true
  if [ ! -e "$CONFIG_DIR/build_identity_conflict" ] && [ ! -L "$CONFIG_DIR/build_identity_conflict" ]; then
    apply_prop ro.build.type user || true
    apply_prop ro.build.tags release-keys || true
  fi
  apply_prop ro.vendor.boot.warranty_bit 0 || true
  apply_prop ro.vendor.warranty_bit 0 || true
  android_sdk=$(getprop ro.build.version.sdk)
  case "$android_sdk" in ''|*[!0-9]*) android_sdk=0 ;; esac
  if [ "$android_sdk" -ge 36 ]; then
    remove_prop sys.oem_unlock_allowed || true
  else
    apply_prop sys.oem_unlock_allowed 0 || true
  fi
  apply_prop ro.secureboot.lockstate locked || true
  apply_prop ro.secureboot.devicelock 1 || true
  apply_prop ro.boot.secureboot 1 || true
  apply_prop ro.boot.device_state locked || true
  apply_prop ro.boot.realmebootstate green || true
  apply_prop ro.boot.realme.lockstate 1 || true
  apply_prop vendor.boot.vbmeta.device_state locked || true
  apply_prop vendor.boot.verifiedbootstate green || true
  apply_prop vendor.boot.flash.locked 1 || true
  apply_prop vendor.boot.device_state locked || true
  hide_boot_mode ro.bootmode || true
  hide_boot_mode ro.boot.bootmode || true
  hide_boot_mode vendor.boot.bootmode || true
}

# Provider conflicts pause Build and Custom property Identity, including optional Zygisk.
build_identity_provider_active() {
  [ "$#" -gt 0 ] || set -- /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules
  scanned=0
  for module_root in "$@"; do
    [ ! -L "$module_root" ] || return 2
    [ -e "$module_root" ] || continue
    [ -d "$module_root" ] && [ -r "$module_root" ] && [ -x "$module_root" ] || return 2
    for candidate in "$module_root"/*; do
      scanned=$((scanned + 1))
      [ "$scanned" -le 4096 ] || return 2
      [ -d "$candidate" ] && [ ! -L "$candidate" ] || continue
      [ ! -e "$candidate/disable" ] && [ ! -L "$candidate/disable" ] || continue
      [ ! -e "$candidate/remove" ] && [ ! -L "$candidate/remove" ] || continue
      module_id=${candidate##*/}
      module_id=$(printf '%s' "$module_id" | tr '[:upper:]' '[:lower:]')
      case "$module_id" in *playintegrity*|*autopif*|*auto_pif*|pif|pif_*|*playcurl*|ih8sn*|*safetynet-fix*|*safetynet_fix*|*safetynetfix*) return 0 ;; esac
    done
  done
  return 1
}

refresh_build_identity_conflict() {
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  conflict_marker="$CONFIG_DIR/build_identity_conflict"
  build_identity_provider_active
  provider_status=$?
  if [ "$provider_status" != 1 ]; then
    provider_state=conflict
    [ "$provider_status" != 2 ] || provider_state=unavailable
    # Never follow an existing marker; an unsafe marker also keeps Build paused.
    if [ ! -L "$conflict_marker" ] && { [ ! -e "$conflict_marker" ] || [ -f "$conflict_marker" ]; }; then
      (umask 077; printf '%s\n' "$provider_state" > "$conflict_marker") || return 0
      chmod 600 "$conflict_marker" 2>/dev/null || true
      chown 0:0 "$conflict_marker" 2>/dev/null || true
    fi
    log -t CleveresTricky "Build and Custom property Identity are paused by the provider compatibility policy ($provider_state)"
  elif [ ! -L "$conflict_marker" ] && [ -f "$conflict_marker" ]; then
    rm -f "$conflict_marker"
  fi
}

is_global_identity_active() {
  boot_mode=auto
  boot_mode_file="$CONFIG_DIR/boot_props_mode"
  if [ -f "$boot_mode_file" ] && [ ! -L "$boot_mode_file" ]; then
    # Bound the consumed byte snapshot, not a separate stat; protect trailing
    # LF and NUL from being discarded by shell command substitution.
    boot_mode_raw=$(dd if="$boot_mode_file" bs=17 count=1 2>/dev/null |
      tr '\000\r\n\t' '!   ')
    boot_mode_bytes=$(printf '%s' "$boot_mode_raw" | wc -c)
    if [ "$boot_mode_bytes" -ge 1 ] 2>/dev/null && [ "$boot_mode_bytes" -le 16 ] 2>/dev/null; then
      # Only ASCII space, tab, CR and LF are trim characters; VT/FF remain invalid.
      boot_mode=$(printf '%s' "$boot_mode_raw" |
        tr '[:upper:]' '[:lower:]' | sed 's/^ *//; s/ *$//')
    fi
  fi
  case "$boot_mode" in force|disable|auto) ;; *) boot_mode=auto ;; esac
  [ "$boot_mode" != disable ] || return 1
  boot_policy_feature_enabled projectionValid
  projection_status=$?
  case "$projection_status" in
    0) boot_policy_feature_enabled globalIdentity; return $? ;;
    1) return 1 ;;
  esac
  # Only installations without a canonical policy retain legacy marker scope.
  [ "$boot_mode" = force ] && return 0
  for marker in global_build_identity global_attestation_mode global_telephony_mode; do
    if [ -f "$CONFIG_DIR/$marker" ] && [ ! -L "$CONFIG_DIR/$marker" ]; then return 0; fi
  done
  optional_marker_enabled buildIdentity spoof_build_identity ||
    optional_marker_enabled regionIdentity spoof_region_cn ||
    optional_marker_enabled identityRefresh random_on_boot ||
    optional_marker_enabled customProps spoof_custom_props
}

reconcile_stale_region_persist_props() {
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  applied_marker="$CONFIG_DIR/region_props_applied"
  [ -f "$applied_marker" ] || return 0
  [ ! -L "$applied_marker" ] || return 0
  if optional_marker_enabled regionIdentity spoof_region_cn && is_global_identity_active; then
    return 0
  fi
  # Retire legacy bookkeeping without claiming ownership of persistent values.
  rm -f "$applied_marker"
}

apply_optional_identity_properties() {
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  command -v resetprop >/dev/null 2>&1 || {
    IDENTITY_APPLY_FAILED=1
    log -t CleveresTricky "resetprop is unavailable; identity properties were skipped"
    return 0
  }

  [ -f "$CONFIG_DIR/spoof_enabled" ] || return 0
  [ ! -L "$CONFIG_DIR/spoof_enabled" ] || return 0

  # Only explicit Global Identity authorizes device-wide optional properties.
  # Do not use global_mode (which governs Global Keybox attestation scope).
  if ! is_global_identity_active; then
    rollback_original_props
    log -t CleveresTricky "Global Identity is off; optional device-wide Identity properties remain untouched"
    return 0
  fi

  RECORDING_ORIGINAL_PROPS=1

  if optional_marker_enabled regionIdentity spoof_region_cn &&
    { [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" != 1 ] || [ "${CLEVERES_TRICKY_IDENTITY_VERIFY_REGION:-0}" = 1 ]; }; then
    apply_prop ro.boot.hwc CN || true
    apply_prop gsm.operator.iso-country cn || true
    apply_prop gsm.sim.operator.iso-country cn || true
    apply_prop ro.boot.hwlevel MP || true
    apply_prop persist.radio.skhwc_matchres MATCH || true
    IDENTITY_REGION_APPLIED=1
  fi

  if [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" = 1 ] && [ "${CLEVERES_TRICKY_IDENTITY_VERIFY_BUILD:-0}" != 1 ]; then return 0; fi
  optional_marker_enabled buildIdentity spoof_build_identity || return 0
  boot_policy_feature_enabled spoofProps
  props_status=$?
  [ "$props_status" = 0 ] || [ "$props_status" = 2 ] || return 0
  vars_file="$CONFIG_DIR/spoof_build_vars"
  [ -f "$vars_file" ] && [ ! -L "$vars_file" ] || return 0
  vars_size=$(wc -c < "$vars_file" 2>/dev/null) || return 0
  case "$vars_size" in ''|*[!0-9]*) return 0 ;; esac
  [ "$vars_size" -ge 1 ] && [ "$vars_size" -le 1048576 ] || return 0

  build_identity_provider_active
  provider_status=$?
  if [ -e "$CONFIG_DIR/build_identity_conflict" ] || [ -L "$CONFIG_DIR/build_identity_conflict" ] || [ "$provider_status" != 1 ]; then
    log -t CleveresTricky "CleveresTricky Build properties were skipped by the provider compatibility policy"
    return 0
  fi

  CT_FINGERPRINT=
  CT_BRAND=
  CT_DEVICE=
  CT_PRODUCT=
  CT_MANUFACTURER=
  CT_MODEL=
  CT_BUILD_ID=
  CT_RELEASE=
  CT_INCREMENTAL=
  CT_TYPE=
  CT_TAGS=
  CT_SECURITY_PATCH=
  CT_SERIAL=
  CT_ATTESTATION_SERIAL=
  CT_FIRST_API_LEVEL=
  CT_DEVICE_INITIAL_SDK_INT=
  CT_AUTO_IDENTITY=
  CT_AUTO_LAUNCH_API=
  CT_AUTO_FIRST_API_LEVEL=
  CT_AUTO_BOARD_API_CAP=
  CT_TEMPLATE=
  while IFS= read -r line || [ -n "$line" ]; do
    line=${line#"${line%%[![:space:]]*}"}
    line=${line%"${line##*[![:space:]]}"}
    case "$line" in ''|'#'*) continue ;; esac
    key=${line%%=*}
    [ "$key" != "$line" ] || continue
    value=${line#*=}
    key=${key#"${key%%[![:space:]]*}"}
    key=${key%"${key##*[![:space:]]}"}
    value=${value#"${value%%[![:space:]]*}"}
    value=${value%"${value##*[![:space:]]}"}
    [ "${#value}" -le 512 ] || continue
    case "$value" in *[![:print:]]*) continue ;; esac
    case "$key" in
      FINGERPRINT) CT_FINGERPRINT=$value ;;
      BRAND) CT_BRAND=$value ;;
      DEVICE) CT_DEVICE=$value ;;
      PRODUCT) CT_PRODUCT=$value ;;
      MANUFACTURER) CT_MANUFACTURER=$value ;;
      MODEL) CT_MODEL=$value ;;
      BUILD_ID) CT_BUILD_ID=$value ;;
      RELEASE) CT_RELEASE=$value ;;
      INCREMENTAL) CT_INCREMENTAL=$value ;;
      TYPE) CT_TYPE=$value ;;
      TAGS) CT_TAGS=$value ;;
      SECURITY_PATCH) CT_SECURITY_PATCH=$value ;;
      SERIAL) CT_SERIAL=$value ;;
      ATTESTATION_ID_SERIAL) CT_ATTESTATION_SERIAL=$value ;;
      FIRST_API_LEVEL) CT_FIRST_API_LEVEL=$value ;;
      DEVICE_INITIAL_SDK_INT) CT_DEVICE_INITIAL_SDK_INT=$value ;;
      AUTO_IDENTITY) CT_AUTO_IDENTITY=$value ;;
      AUTO_LAUNCH_API) CT_AUTO_LAUNCH_API=$value ;;
      AUTO_FIRST_API_LEVEL) CT_AUTO_FIRST_API_LEVEL=$value ;;
      AUTO_BOARD_API_CAP) CT_AUTO_BOARD_API_CAP=$value ;;
      TEMPLATE) CT_TEMPLATE=$value ;;
    esac
  done < "$vars_file"

  if [ -z "$CT_SERIAL" ]; then
    CT_SERIAL=$CT_ATTESTATION_SERIAL
  fi
  if [ -z "$CT_FIRST_API_LEVEL" ] && [ -n "$CT_DEVICE_INITIAL_SDK_INT" ]; then
    CT_FIRST_API_LEVEL=$CT_DEVICE_INITIAL_SDK_INT
  fi

  [ -n "$CT_FINGERPRINT" ] || {
    log -t CleveresTricky "Build identity is enabled, but no persisted fingerprint is available"
    return 0
  }
  case "$CT_FINGERPRINT" in *[!A-Za-z0-9._:/+-]*) return 0 ;; esac

  apply_prop ro.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.bootimage.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.system.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.system_ext.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.product.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.vendor.build.fingerprint "$CT_FINGERPRINT" || true
  apply_prop ro.odm.build.fingerprint "$CT_FINGERPRINT" || true
  if [ "$CT_AUTO_IDENTITY" = 1 ] && [ -z "$CT_TEMPLATE" ] && { [ -z "$CT_AUTO_LAUNCH_API" ] || [ "$CT_AUTO_LAUNCH_API" = 1 ]; }; then
    [ -z "$CT_AUTO_FIRST_API_LEVEL" ] || CT_FIRST_API_LEVEL=$CT_AUTO_FIRST_API_LEVEL
    board_cap=${CT_AUTO_BOARD_API_CAP:-32}
    host_api=$(getprop ro.build.version.sdk 2>/dev/null)
    case "$CT_FIRST_API_LEVEL" in
      [0-9]|[0-9][0-9])
        case "$host_api" in
          [0-9]|[0-9][0-9])
            if [ "$CT_FIRST_API_LEVEL" -gt "$host_api" ]; then
              CT_FIRST_API_LEVEL=$host_api
            fi
            case "$CT_FIRST_API_LEVEL" in 0[0-9]) CT_FIRST_API_LEVEL=${CT_FIRST_API_LEVEL#0} ;; esac
            if [ "$host_api" -gt 0 ] && [ "$CT_FIRST_API_LEVEL" -gt 0 ]; then
              apply_prop ro.product.first_api_level "$CT_FIRST_API_LEVEL" || true
              case "$board_cap" in
                [0-9]|[0-9][0-9])
                  case "$board_cap" in 0[0-9]) board_cap=${board_cap#0} ;; esac
                  if [ "$board_cap" -gt 0 ]; then
                    [ "$board_cap" -le "$CT_FIRST_API_LEVEL" ] || board_cap=$CT_FIRST_API_LEVEL
                    apply_prop ro.board.first_api_level "$board_cap" || true
                  fi
                  ;;
              esac
            fi
            ;;
        esac
        ;;
    esac
  fi

  if [ -n "$CT_BRAND" ]; then
    apply_prop ro.product.brand "$CT_BRAND" || true
    apply_prop ro.product.system.brand "$CT_BRAND" || true
    apply_prop ro.product.system_ext.brand "$CT_BRAND" || true
    apply_prop ro.product.vendor.brand "$CT_BRAND" || true
    apply_prop ro.product.product.brand "$CT_BRAND" || true
    apply_prop ro.product.odm.brand "$CT_BRAND" || true
  fi
  if [ -n "$CT_DEVICE" ]; then
    apply_prop ro.product.device "$CT_DEVICE" || true
    apply_prop ro.product.system.device "$CT_DEVICE" || true
    apply_prop ro.product.system_ext.device "$CT_DEVICE" || true
    apply_prop ro.product.vendor.device "$CT_DEVICE" || true
    apply_prop ro.product.product.device "$CT_DEVICE" || true
    apply_prop ro.product.odm.device "$CT_DEVICE" || true
  fi
  if [ -n "$CT_PRODUCT" ]; then
    apply_prop ro.product.name "$CT_PRODUCT" || true
    apply_prop ro.product.system.name "$CT_PRODUCT" || true
    apply_prop ro.product.system_ext.name "$CT_PRODUCT" || true
    apply_prop ro.product.vendor.name "$CT_PRODUCT" || true
    apply_prop ro.product.product.name "$CT_PRODUCT" || true
    apply_prop ro.product.odm.name "$CT_PRODUCT" || true
  fi
  if [ -n "$CT_MANUFACTURER" ]; then
    apply_prop ro.product.manufacturer "$CT_MANUFACTURER" || true
    apply_prop ro.product.system.manufacturer "$CT_MANUFACTURER" || true
    apply_prop ro.product.system_ext.manufacturer "$CT_MANUFACTURER" || true
    apply_prop ro.product.vendor.manufacturer "$CT_MANUFACTURER" || true
    apply_prop ro.product.product.manufacturer "$CT_MANUFACTURER" || true
    apply_prop ro.product.odm.manufacturer "$CT_MANUFACTURER" || true
  fi
  if [ -n "$CT_MODEL" ]; then
    apply_prop ro.product.model "$CT_MODEL" || true
    apply_prop ro.product.system.model "$CT_MODEL" || true
    apply_prop ro.product.system_ext.model "$CT_MODEL" || true
    apply_prop ro.product.vendor.model "$CT_MODEL" || true
    apply_prop ro.product.product.model "$CT_MODEL" || true
    apply_prop ro.product.odm.model "$CT_MODEL" || true
  fi
  if [ -n "$CT_BUILD_ID" ]; then
    apply_prop ro.build.id "$CT_BUILD_ID" || true
    apply_prop ro.system.build.id "$CT_BUILD_ID" || true
    apply_prop ro.system_ext.build.id "$CT_BUILD_ID" || true
    apply_prop ro.product.build.id "$CT_BUILD_ID" || true
    apply_prop ro.vendor.build.id "$CT_BUILD_ID" || true
    apply_prop ro.odm.build.id "$CT_BUILD_ID" || true
    apply_prop ro.bootimage.build.id "$CT_BUILD_ID" || true
  fi
  if [ -n "$CT_RELEASE" ]; then
    apply_prop ro.build.version.release "$CT_RELEASE" || true
    apply_prop ro.build.version.release_or_codename "$CT_RELEASE" || true
    apply_prop ro.build.version.release_or_preview_display "$CT_RELEASE" || true
    apply_prop ro.system.build.version.release "$CT_RELEASE" || true
    apply_prop ro.system_ext.build.version.release "$CT_RELEASE" || true
    apply_prop ro.product.build.version.release "$CT_RELEASE" || true
    apply_prop ro.vendor.build.version.release "$CT_RELEASE" || true
    apply_prop ro.odm.build.version.release "$CT_RELEASE" || true
    apply_prop ro.bootimage.build.version.release "$CT_RELEASE" || true
  fi
  if [ -n "$CT_INCREMENTAL" ]; then
    apply_prop ro.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.system.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.system_ext.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.product.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.vendor.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.odm.build.version.incremental "$CT_INCREMENTAL" || true
    apply_prop ro.bootimage.build.version.incremental "$CT_INCREMENTAL" || true
  fi
  if [ -n "$CT_TYPE" ]; then
    apply_prop ro.build.type "$CT_TYPE" || true
    apply_prop ro.system.build.type "$CT_TYPE" || true
    apply_prop ro.system_ext.build.type "$CT_TYPE" || true
    apply_prop ro.product.build.type "$CT_TYPE" || true
    apply_prop ro.vendor.build.type "$CT_TYPE" || true
    apply_prop ro.odm.build.type "$CT_TYPE" || true
    apply_prop ro.bootimage.build.type "$CT_TYPE" || true
  fi
  if [ -n "$CT_TAGS" ]; then
    apply_prop ro.build.tags "$CT_TAGS" || true
    apply_prop ro.system.build.tags "$CT_TAGS" || true
    apply_prop ro.system_ext.build.tags "$CT_TAGS" || true
    apply_prop ro.product.build.tags "$CT_TAGS" || true
    apply_prop ro.vendor.build.tags "$CT_TAGS" || true
    apply_prop ro.odm.build.tags "$CT_TAGS" || true
    apply_prop ro.bootimage.build.tags "$CT_TAGS" || true
  fi
  if [ -n "$CT_SECURITY_PATCH" ]; then
    case "$CT_SECURITY_PATCH" in
      [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9])
        apply_prop ro.build.version.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.system.build.version.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.system_ext.build.version.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.product.build.version.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.vendor.build.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.vendor.build.version.security_patch "$CT_SECURITY_PATCH" || true
        apply_prop ro.odm.build.version.security_patch "$CT_SECURITY_PATCH" || true
        ;;
    esac
  fi
  if [ -n "$CT_SERIAL" ]; then
    apply_prop ro.serialno "$CT_SERIAL" || true
    apply_prop ro.boot.serialno "$CT_SERIAL" || true
    apply_prop ro.vendor.serialno "$CT_SERIAL" || true
    apply_prop ro.odm.serialno "$CT_SERIAL" || true
    apply_prop vendor.serialno "$CT_SERIAL" || true
    apply_prop vendor.boot.serialno "$CT_SERIAL" || true
    apply_prop persist.sys.serialno "$CT_SERIAL" || true
    apply_prop ro.ril.oem.sno "$CT_SERIAL" || true
    apply_prop ro.ril.oem.psno "$CT_SERIAL" || true
    apply_prop sys.serialno "$CT_SERIAL" || true
    apply_prop gsm.serial "$CT_SERIAL" || true
  fi
  IDENTITY_BUILD_APPLIED=1
}

is_valid_custom_prop_name() {
  name=$1
  [ -n "$name" ] || return 1
  [ "${#name}" -le 127 ] || return 1
  case "$name" in
    .*|*.) return 1 ;;
    *..*) return 1 ;;
    ctl.*) return 1 ;;
  esac
  case "$name" in
    *[!A-Za-z0-9._:@-]*) return 1 ;;
  esac
  return 0
}

is_valid_custom_prop_value() {
  value=$1
  [ -n "$value" ] || return 1
  [ "${#value}" -le 91 ] || return 1
  case "$value" in
    *[![:print:]]*) return 1 ;;
  esac
  return 0
}

apply_custom_props() {
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  command -v resetprop >/dev/null 2>&1 || {
    log -t CleveresTricky "resetprop is unavailable; custom properties were skipped"
    return 0
  }

  [ -f "$CONFIG_DIR/spoof_enabled" ] || return 0
  [ ! -L "$CONFIG_DIR/spoof_enabled" ] || return 0

  if ! is_global_identity_active; then
    rollback_original_props
    return 0
  fi

  RECORDING_ORIGINAL_PROPS=1

  optional_marker_enabled customProps spoof_custom_props || return 0
  build_identity_provider_active
  provider_status=$?
  if [ -e "$CONFIG_DIR/build_identity_conflict" ] || [ -L "$CONFIG_DIR/build_identity_conflict" ] || [ "$provider_status" != 1 ]; then
    log -t CleveresTricky "Custom property Identity is paused to avoid competing with another identity provider"
    return 0
  fi
  props_file="$CONFIG_DIR/custom_props"
  [ -f "$props_file" ] && [ ! -L "$props_file" ] || return 0
  props_size=$(wc -c < "$props_file" 2>/dev/null) || return 0
  case "$props_size" in ''|*[!0-9]*) return 0 ;; esac
  [ "$props_size" -ge 1 ] && [ "$props_size" -le 65536 ] || return 0

  # Two passes so one invalid line cannot leave a partially applied view.
  # Surrounding whitespace is trimmed with expansions only (no forks at boot).
  entry_count=0
  while IFS= read -r line || [ -n "$line" ]; do
    line=${line#"${line%%[![:space:]]*}"}
    case "$line" in ''|'#'*) continue ;; esac
    key=${line%%=*}
    [ "$key" != "$line" ] || return 0
    value=${line#*=}
    key=${key#"${key%%[![:space:]]*}"}
    key=${key%"${key##*[![:space:]]}"}
    value=${value#"${value%%[![:space:]]*}"}
    value=${value%"${value##*[![:space:]]}"}
    is_valid_custom_prop_name "$key" || return 0
    is_valid_custom_prop_value "$value" || return 0
    entry_count=$((entry_count + 1))
    [ "$entry_count" -le 256 ] || return 0
  done < "$props_file"
  [ "$entry_count" -ge 1 ] || return 0

  while IFS= read -r line || [ -n "$line" ]; do
    line=${line#"${line%%[![:space:]]*}"}
    case "$line" in ''|'#'*) continue ;; esac
    key=${line%%=*}
    value=${line#*=}
    key=${key#"${key%%[![:space:]]*}"}
    key=${key%"${key##*[![:space:]]}"}
    value=${value#"${value%%[![:space:]]*}"}
    value=${value%"${value##*[![:space:]]}"}
    apply_prop "$key" "$value" || true
  done < "$props_file"
}

apply_early_properties() {
  refresh_build_identity_conflict
  [ "$CONFIG_ROOT_SAFE" = true ] || return 0
  command -v resetprop >/dev/null 2>&1 || {
    log -t CleveresTricky "resetprop is unavailable; boot property protection was skipped"
    return 0
  }
  apply_core_boot_properties
  reconcile_stale_region_persist_props
  apply_optional_identity_properties
  apply_custom_props
  reconcile_inactive_original_props || IDENTITY_APPLY_FAILED=1
}

if [ "${CLEVERES_TRICKY_IDENTITY_ONLY:-0}" = "1" ]; then
  # post-mount shares this path; only managed live actions request strict verification.
  IDENTITY_APPLY_FAILED=0
  IDENTITY_BUILD_APPLIED=0
  IDENTITY_REGION_APPLIED=0
  if [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" = 1 ]; then
    case "${CLEVERES_TRICKY_IDENTITY_VERIFY_BUILD:-}:${CLEVERES_TRICKY_IDENTITY_VERIFY_REGION:-}" in
      [01]:[01]) ;;
      *) exit 1 ;;
    esac
  fi
  apply_optional_identity_properties
  apply_custom_props
  # Verification applies only requested subsets; do not roll back skipped layers.
  if [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" != 1 ]; then
    reconcile_inactive_original_props || IDENTITY_APPLY_FAILED=1
  fi
  if [ "${CLEVERES_TRICKY_IDENTITY_VERIFY:-0}" = 1 ]; then
    [ "$IDENTITY_APPLY_FAILED" = 0 ] || exit 1
    [ "$CLEVERES_TRICKY_IDENTITY_VERIFY_BUILD" = 0 ] || [ "$IDENTITY_BUILD_APPLIED" = 1 ] || exit 1
    [ "$CLEVERES_TRICKY_IDENTITY_VERIFY_REGION" = 0 ] || [ "$IDENTITY_REGION_APPLIED" = 1 ] || exit 1
  fi
else
  promote_staged_identity
  apply_early_properties
fi
